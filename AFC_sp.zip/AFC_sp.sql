-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 06, 2018 at 10:20 AM
-- Server version: 5.6.40
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pointnin_afc`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_ATTRIBUTE_VALUE` (IN `p_warehouse_id` INT(11), IN `p_attribute_id` INT(11), IN `p_value` VARCHAR(50), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR sqlexception
BEGIN
ROLLBACK;
END;
START TRANSACTION;
  SELECT COUNT(attribute_value_id) INTO IsFound FROM pointnin_afc.attribute_value WHERE value=p_value;
  IF IsFound=0 THEN
    INSERT INTO pointnin_afc.attribute_value
    (attribute_id,
    value,
    status,
    createdby,
    createdon)
    VALUES
    (p_attribute_id,
    p_value,
    p_status,
    p_createdby,
    NOW());
    SELECT LAST_INSERT_ID() INTO p_id;
  ELSE
    SELECT 0 INTO p_id;
  END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_AUDIT` (IN `p_referenceid` CHAR(36), IN `p_referencetypecode` TINYINT(2), IN `p_value` TEXT, IN `p_type` TINYINT(2), IN `p_method` VARCHAR(100), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_auditid` CHAR(36))  BEGIN
DECLARE newAuditid CHAR(36);
DECLARE EXIT HANDLER FOR sqlexception
BEGIN
ROLLBACK;
END;
START TRANSACTION;
SET newAuditid=UUID();
INSERT INTO pointnin_afc.audit
(auditid,
referenceid,
referencetypecode,
value,
type,
method,
status,
createdby,
createdon
)
values
(newAuditid,
p_referenceid,
p_referencetypecode,
p_value,
p_type,
p_method,
p_status,
p_createdby,
NOW());
SELECT newAuditid INTO p_auditid;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_CATEGORY` (IN `p_warehouse_id` INT(11), IN `p_category_name` VARCHAR(150), IN `p_category_desc` VARCHAR(255), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR sqlexception
BEGIN
ROLLBACK;
END;
START TRANSACTION;
	SELECT COUNT(category_id) INTO IsFound FROM pointnin_afc.category WHERE category_name=p_category_name;
	IF IsFound=0 THEN
		INSERT INTO pointnin_afc.category
		(warehouse_id,
        category_name,
        category_desc,
        status,
        createdby,
		modifiedby,
        createdon,
        modifiedon)
		VALUES
		(p_warehouse_id,
        p_category_name,
		p_category_desc,
        p_status,
        p_createdby,
        p_createdby,
        NOW(),
		NOW());
		SELECT LAST_INSERT_ID() INTO p_id;
	ELSE
		SELECT 0 INTO p_id;
	END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_CITY` (IN `p_country_id` INT(11), IN `p_state_id` INT(11), IN `p_city_name` VARCHAR(200), IN `p_latitude` FLOAT(10,6), IN `p_longitude` FLOAT(10,6), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
ROLLBACK;
END;
START TRANSACTION;
	SELECT COUNT(city_id) INTO IsFound FROM pointnin_afc.city WHERE city_name=p_city_name AND country_id=p_country_id;
	IF IsFound=0 THEN
		INSERT INTO pointnin_afc.city
		(country_id,
        state_id,
        city_name,
        latitude,
        longitude,
        status,
        createdby,
        createdon,
        modifiedon)
		VALUES
		(p_country_id,
		p_state_id,
        p_city_name,
        p_latitude,
        p_longitude,
        p_status,
        p_createdby,
		NOW(),
        NOW());
		SELECT LAST_INSERT_ID() INTO p_id;
	ELSE
		SELECT 0 INTO p_id;
	END IF;
COMMIT;    
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_COMPANY` (IN `p_name` VARCHAR(255), IN `p_phone` VARCHAR(15), IN `p_email` VARCHAR(150), IN `p_address` VARCHAR(255), IN `p_description` VARCHAR(255), IN `p_image` VARCHAR(100), IN `p_outstandingamount` DOUBLE, IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR sqlexception
BEGIN
ROLLBACK;
END;
START TRANSACTION;
	SELECT COUNT(company_id) INTO IsFound FROM pointnin_afc.company WHERE name=p_name;
	IF IsFound=0 THEN
		INSERT INTO pointnin_afc.company
		(name,
        phone,
        email,
        address,
        description,
        image,
        outstandingamount,
        status,
        createdby,
		modifiedby,
        createdon,
        modifiedon
		)
		VALUES
		(p_name,
        p_phone,
        p_email,
        p_address,
		p_description,
        p_image,
        p_outstandingamount,
        p_status,
        p_createdby,
        p_createdby,
        NOW(),
		NOW());
		SELECT LAST_INSERT_ID() INTO p_id;
	ELSE
		SELECT 0 INTO p_id;
	END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_COMPANY_LOCATION` (IN `p_company_id` INT(11), IN `p_location_id` INT(11), IN `p_route_id` INT(11), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE EXIT HANDLER FOR sqlexception
BEGIN
ROLLBACK;
END;
START TRANSACTION;
INSERT INTO pointnin_afc.company_location
(company_id,
location_id,
route_id,
createdby,
createdon
)
VALUES
(p_company_id,
p_location_id,
p_route_id,
p_createdby,
NOW());
SELECT LAST_INSERT_ID() INTO p_id;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_COUNTRY` (IN `p_iso` CHAR(2), IN `p_name` VARCHAR(80), IN `p_currency_code` CHAR(3), IN `p_phonecode` INT(5), IN `p_zone_name` VARCHAR(35), IN `p_createdby` INT(11), IN `p_status` TINYINT(2), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
ROLLBACK;
END;
START TRANSACTION;
	SELECT COUNT(country_id) INTO IsFound FROM pointnin_afc.country WHERE name=p_name;
	IF IsFound=0 THEN
		INSERT INTO pointnin_afc.country
		(iso,
        name,
        currency_code,
        phonecode,
        zone_name,
        status,
        createdby,
        createdon,
        modifiedon)
		VALUES
		(p_iso,
		p_name,
        p_currency_code,
        p_phonecode,
        p_zone_name,
        p_status,
        p_createdby,
		NOW(),
        NOW());
		SELECT LAST_INSERT_ID() INTO p_id;
	ELSE
		SELECT 0 INTO p_id;
	END IF;
COMMIT;    
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_LOCATION` (IN `p_country_id` INT(11), IN `p_city_id` INT(11), IN `p_route_id` INT(11), IN `p_location_name` VARCHAR(150), IN `p_address` VARCHAR(255), IN `p_latitude` VARCHAR(15), IN `p_longitude` VARCHAR(15), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
ROLLBACK;
END;
START TRANSACTION;
  SELECT COUNT(location_id) INTO IsFound FROM pointnin_afc.location WHERE location_name=p_location_name AND country_id=p_country_id AND city_id=p_city_id;
  IF IsFound=0 THEN
    INSERT INTO pointnin_afc.location
    (route_id,
    country_id,
    city_id,
    location_name,
    address,
    latitude,
    longitude,
    status,
    createdby,
    modifiedby,
    createdon,
    modifiedon)
    VALUES
    (p_route_id,
    p_country_id,
    p_city_id,
    p_location_name,
    p_address,
    p_latitude,
    p_longitude,
    p_status,
    p_createdby,
    p_createdby,
    NOW(),
    NOW());
    SELECT LAST_INSERT_ID() INTO p_id;
  ELSE
    SELECT 0 INTO p_id;
  END IF;
COMMIT;    
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_PRODUCT` (IN `p_warehouse_id` INT(11), IN `p_category_id` INT(11), IN `p_product_name` VARCHAR(255), IN `p_configuration` VARCHAR(255), IN `p_short_desc` VARCHAR(255), IN `p_qty` DOUBLE, IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
SELECT COUNT(product_id) INTO IsFound FROM pointnin_afc.product WHERE product_name=p_product_name;
IF IsFound=0 THEN
    INSERT INTO pointnin_afc.product
    (warehouse_id,
    category_id,
    product_name,
    configuration,
    short_desc,
    qty,
    status,
    createdby,
    modifiedby,
    createdon,
    modifiedon)
    VALUES
    (p_warehouse_id,
    p_category_id,
    p_product_name,
    p_configuration,
    p_short_desc,
    p_qty,
    p_status,
    p_createdby,
    p_createdby,
    NOW(),
    NOW());
    SELECT LAST_INSERT_ID() INTO p_id;
ELSE
    SELECT 0 INTO p_id;
END IF;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_PRODUCT_PRICE` (IN `p_warehouse_id` INT(11), IN `p_product_id` BIGINT(11), IN `p_attribute_value_id` INT(11), IN `p_price` DOUBLE, IN `p_barcode` VARCHAR(13), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
INSERT INTO pointnin_afc.product_price
(warehouse_id,
product_id,
attribute_value_id,
price,
barcode,
status,
createdby,
modifiedby,
createdon,
modifiedon)
VALUES
(p_warehouse_id,
p_product_id,
p_attribute_value_id,
p_price,
p_barcode,
p_status,
p_createdby,
p_createdby,
NOW(),
NOW());
SELECT LAST_INSERT_ID() INTO p_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_PURCHASE` (IN `p_order_code` VARCHAR(50), IN `p_supplier_id` INT(11), IN `p_product_id` INT(11), IN `p_attribute_value_id` INT(11), IN `p_units` INT(11), IN `p_unit_price` DOUBLE, IN `p_sales_price` DOUBLE, IN `p_bulk_price` DOUBLE, IN `p_bagging_price` DOUBLE, IN `p_config_id` INT(11), IN `p_packing_id` INT(11), IN `p_purchase_date` DATE, IN `p_description` VARCHAR(250), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
  SELECT COUNT(purchase_id) INTO IsFound FROM pointnin_afc.purchase WHERE order_code=p_order_code;
  IF IsFound=0 THEN
    INSERT INTO pointnin_afc.purchase
    (order_code,
	supplier_id,
    product_id,
    attribute_value_id,
    units,
    unit_price,
    sales_price,
    bulk_price,
    bagging_price,
    config_id,
    packing_id,
    purchase_date,
    description,
    status,
    createdby,
    modifiedby,
    createdon,
    modifiedon)
    VALUES
    (p_order_code,
	p_supplier_id,
    p_product_id,
    p_attribute_value_id,
    p_units,
    p_unit_price,
    p_sales_price,
    p_bulk_price,
    p_bagging_price,
    p_config_id,
    p_packing_id,
    p_purchase_date,
    p_description,
    p_status,
    p_createdby,
    p_createdby,
    NOW(),
    NOW());
    SELECT LAST_INSERT_ID() INTO p_id;
  ELSE
    SELECT 0 INTO p_id;
  END IF;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_PURCHASE_DETAILS` (IN `p_purchase_id` INT(11), IN `p_warehouse_id` INT(11), IN `p_product_id` INT(11), IN `p_attribute_value_id` INT(11), IN `p_qty` INT(11), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
  INSERT INTO pointnin_afc.purchase_details
  (purchase_id,
  warehouse_id,
  qty,
  status,
  createdby,
  modifiedby,
  createdon,
  modifiedon)
  VALUES
  (p_purchase_id,
  p_warehouse_id,
  p_qty,
  p_status,
  p_createdby,
  p_createdby,
  NOW(),
  NOW());

  IF NOT EXISTS (SELECT S.id FROM pointnin_afc.warehouse_products_stock AS S WHERE S.warehouse_id=p_warehouse_id AND S.product_id=p_product_id AND S.attribute_value_id=p_attribute_value_id) THEN
    INSERT INTO pointnin_afc.warehouse_products_stock
    (warehouse_id,
    product_id,
    attribute_value_id,
    qty,
    status,
    createdby,
    modifiedby,
    createdon,
    modifiedon)
    VALUES
    (p_warehouse_id,
    p_product_id,
    p_attribute_value_id,
    p_qty,
    p_status,
    p_createdby,
    p_createdby,
    NOW(),
    NOW());
  ELSE
    UPDATE pointnin_afc.warehouse_products_stock
    SET
    qty=qty+p_qty,
    modifiedby=p_createdby,
    modifiedon=NOW()
    WHERE warehouse_id=p_warehouse_id AND product_id=p_product_id AND attribute_value_id=p_attribute_value_id;
  END IF;
  SELECT LAST_INSERT_ID() INTO p_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_REQUEST_PRODUCT_STOCK` (IN `p_upd_id` CHAR(36), IN `p_user_id` INT(11), IN `p_warehouse_id` INT(11), IN `p_product_id` INT(11), IN `p_attribute_value_id` INT(11), IN `p_qty` INT(11), IN `p_price` DOUBLE, IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_id` INT(11))  BEGIN
	DECLARE IsFound INT(1);
	SELECT COUNT(S.id) INTO IsFound FROM pointnin_afc.warehouse_products_stock AS S WHERE S.warehouse_id=p_warehouse_id AND S.product_id=p_product_id AND S.attribute_value_id=p_attribute_value_id AND S.qty >= p_qty;
	IF IsFound>0 THEN
		IF NOT EXISTS (SELECT S.id FROM pointnin_afc.user_products_stock AS S WHERE S.user_id=p_user_id AND S.product_id=p_product_id AND S.attribute_value_id=p_attribute_value_id) THEN
		  INSERT INTO pointnin_afc.user_products_stock
		  (user_id,
		  product_id,
		  attribute_value_id,
		  qty,
		  status,
		  createdby,
		  modifiedby,
		  createdon,
		  modifiedon)
		  VALUES
		  (p_user_id,
		  p_product_id,
		  p_attribute_value_id,
		  p_qty,
		  p_status,
		  p_modifiedby,
		  p_modifiedby,
		  NOW(),
		  NOW());
		ELSE
		  UPDATE pointnin_afc.user_products_stock
		  SET
		  status=p_status,
		  qty=qty+p_qty,
		  modifiedby=p_modifiedby,
		  modifiedon=NOW()
		  WHERE user_id=p_user_id AND product_id=p_product_id AND attribute_value_id=p_attribute_value_id;
		END IF;
		
		UPDATE pointnin_afc.warehouse_products_stock AS V 
		SET V.qty=V.qty-p_qty
		WHERE V.warehouse_id=p_warehouse_id AND V.product_id=p_product_id AND V.attribute_value_id=p_attribute_value_id;
		
		UPDATE pointnin_afc.user_products_details
		SET
		status=p_status,
		modifiedby=p_modifiedby,
		modifiedon=NOW()
		WHERE upd_id=p_upd_id;	
		
		SELECT 1 INTO p_id;
	ELSE	
		SELECT 0 INTO p_id;
	END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_ROUTE` (IN `p_name` VARCHAR(150), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR sqlexception
BEGIN
ROLLBACK;
END;
START TRANSACTION;
  SELECT COUNT(route_id) INTO IsFound FROM pointnin_afc.route WHERE name=p_name;
  IF IsFound=0 THEN
    INSERT INTO pointnin_afc.route
    (name,
    status,
    createdby,
    modifiedby,
    createdon,
    modifiedon
    )
    VALUES
    (p_name,
    p_status,
    p_createdby,
    p_createdby,
    NOW(),
    NOW());
    SELECT LAST_INSERT_ID() INTO p_id;
  ELSE
    SELECT 0 INTO p_id;
  END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_RUN_SHEET` (IN `p_company_name` VARCHAR(255), IN `p_address` VARCHAR(255), IN `p_location_name` VARCHAR(255), IN `p_country_id` INT(11), IN `p_city_id` INT(11), IN `p_route_id` INT(11), IN `p_barcode` VARCHAR(13), IN `p_barcode_original` VARCHAR(5), IN `p_stand_type_name` VARCHAR(255), IN `p_warehouse_id` INT(11), IN `p_service_notes` VARCHAR(255), IN `p_order_amount` DOUBLE, IN `p_sale_amount` DOUBLE, IN `p_serviced_every` INT(11), IN `p_position` INT(11), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(2))  BEGIN
DECLARE standIsFound INT(1);
DECLARE standTypeIsFound INT(1);
DECLARE companyIsFound INT(1);
DECLARE locationIsFound INT(1);
DECLARE newUuid CHAR(36);
DECLARE i_company_id INT(11);
DECLARE i_location_id INT(11);
DECLARE i_stand_id INT(11);
DECLARE i_stand_type_id INT(11);

	SELECT COUNT(stand_id) INTO standIsFound FROM pointnin_afc.stand WHERE barcode=p_barcode;
	IF standIsFound=0 THEN
		SELECT COUNT(stand_type_id), stand_type_id INTO standTypeIsFound, i_stand_type_id FROM pointnin_afc.stand_type WHERE name=p_stand_type_name;
		IF standTypeIsFound > 0 THEN
			SELECT COUNT(company_id), company_id INTO companyIsFound, i_company_id FROM pointnin_afc.company WHERE name=p_company_name;
			IF companyIsFound=0 THEN
				INSERT INTO pointnin_afc.company
				(name,
				address,
				outstandingamount,
				status,
				createdby,
				modifiedby,
				createdon,
				modifiedon)
				VALUES
				(p_company_name,
				p_address,
				0,
				p_status,
				p_createdby,
				p_createdby,
				NOW(),
				NOW());
				SET i_company_id = LAST_INSERT_ID();
			END IF;
			
			SELECT COUNT(location_id), location_id INTO locationIsFound, i_location_id FROM pointnin_afc.location WHERE location_name=p_location_name AND country_id=p_country_id AND city_id=p_city_id;
			IF locationIsFound=0 THEN
				INSERT INTO pointnin_afc.location
				(route_id,
				country_id,
				city_id,
				location_name,
				address,
				status,
				createdby,
				modifiedby,
				createdon,
				modifiedon)
				VALUES
				(p_route_id,
				p_country_id,
				p_city_id,
				p_location_name,
				p_address,
				p_status,
				p_createdby,
				p_createdby,
				NOW(),
				NOW());
				SET i_location_id = LAST_INSERT_ID();
			END IF;

			IF NOT EXISTS (SELECT company_location_id FROM pointnin_afc.company_location WHERE company_id=i_company_id AND location_id=i_location_id) THEN
				INSERT INTO pointnin_afc.company_location
				(company_id,
				location_id,
				route_id,
				createdby,
				createdon
				)
				VALUES
				(i_company_id,
				i_location_id,
				p_route_id,
				p_createdby,
				NOW());
			END IF;

			INSERT INTO pointnin_afc.stand
			(name,
			barcode,
			stand_type_id,
			from_warehouse_id,
			to_warehouse_id,
			company_id,
			location_id,
			route_id,
			service_notes,
			usage_status,
			status,
			placedon,
			position,
			serviced_every,
			createdby,
			modifiedby,
			createdon,
			modifiedon
			)
			VALUES
			(p_barcode,
			p_barcode,
			i_stand_type_id,
			p_warehouse_id,
			p_warehouse_id,
			i_company_id,
			i_location_id,
			p_route_id,
			p_service_notes,
			0,
			p_status,
			NOW(),
			p_position,
			p_serviced_every,
			p_createdby,
			p_createdby,
			NOW(),
			NOW());
			SET i_stand_id = LAST_INSERT_ID();
		
			SET newUuid = UUID();
			INSERT INTO pointnin_afc.receipt
			(receipt_id,
			user_id,
			warehouse_id,
			route_id,
			company_id,
			location_id,
			stand_id,
			order_amount,
			sale_amount,
			service_date,
			notes,
			status,
			createdby,
			modifiedby,
			createdon,
			modifiedon)
			VALUES
			(newUuid,
			p_createdby,
			p_warehouse_id,
			p_route_id,
			i_company_id,
			i_location_id,
			i_stand_id,
			p_order_amount,
			p_sale_amount,
			NOW(),
			p_service_notes,
			p_status,
			p_createdby,
			p_createdby,
			NOW(),
			NOW());
			SELECT i_stand_id INTO p_id;
		ELSE
			SELECT -1 INTO p_id;
		END IF;
	ELSE
		SELECT 0 INTO p_id;		
	END IF;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_SLAB` (IN `p_type` TINYINT(2), IN `p_name` VARCHAR(150), IN `p_description` VARCHAR(150), IN `p_start_time` TIME, IN `p_end_time` TIME, IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
SELECT COUNT(id) INTO IsFound FROM pointnin_afc.slab WHERE type=p_type AND start_time=p_start_time AND end_time=p_end_time;
IF IsFound=0 THEN
    INSERT INTO pointnin_afc.slab
    (type,
    name,
    description,
    start_time,
    end_time,
    status,
    createdby,
    modifiedby,
    createdon,
    modifiedon
    )
    VALUES
    (p_type,
    p_name,
    p_description,
    p_start_time,
    p_end_time,
    p_status,
    p_createdby,
    p_createdby,
    NOW(),
    NOW());
    SELECT LAST_INSERT_ID() INTO p_id;
ELSE
    SELECT 0 INTO p_id;
END IF;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_SPECIAL_REQUEST` (IN `p_type` TINYINT(2), IN `p_user_id` INT(11), IN `p_route_id` INT(11), IN `p_company_id` INT(11), IN `p_location_id` INT(11), IN `p_stand_id` INT(11), IN `p_notes` VARCHAR(255), IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_id` INT(11))  BEGIN
    INSERT INTO pointnin_afc.special_request
    (type,
    user_id,
    route_id,
    company_id,
    location_id,
	stand_id,
    notes,
    status,
	modifiedby,
    createdon,
	modifiedon)
    VALUES
    (p_type,
    p_user_id,
    p_route_id,
    p_company_id,
    p_location_id,
	p_stand_id,
    p_notes,
    p_status,
	p_modifiedby,
	NOW(),
    NOW());
    SELECT LAST_INSERT_ID() INTO p_id;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_STAND` (IN `p_name` VARCHAR(255), IN `p_code` VARCHAR(100), IN `p_barcode` VARCHAR(100), IN `p_stand_type_id` INT(11), IN `p_from_warehouse_id` INT(11), IN `p_to_warehouse_id` INT(11), IN `p_company_id` INT(11), IN `p_location_id` INT(11), IN `p_route_id` INT(11), IN `p_service_notes` VARCHAR(255), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR sqlexception
BEGIN
ROLLBACK;
END;
START TRANSACTION;
	SELECT COUNT(stand_id) INTO IsFound FROM pointnin_afc.stand WHERE name=p_name;
	IF IsFound=0 THEN
		INSERT INTO pointnin_afc.stand
		(name,
        code,
        barcode,
        stand_type_id,
        from_warehouse_id,
        to_warehouse_id,
        company_id,
        location_id,
        route_id,
        service_notes,
        usage_status,
        status,
        createdby,
		modifiedby,
        createdon,
        modifiedon
		)
		VALUES
		(p_name,
		p_code,
        p_barcode,
        p_stand_type_id,
        p_from_warehouse_id,
        p_to_warehouse_id,
        p_company_id,
        p_location_id,
        p_route_id,
        p_service_notes,
        0,
        p_status,
        p_createdby,
        p_createdby,
        NOW(),
		NOW());
		SELECT LAST_INSERT_ID() INTO p_id;
	ELSE
		SELECT 0 INTO p_id;
	END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_STANDTYPE` (IN `p_name` VARCHAR(150), IN `p_description` VARCHAR(255), IN `p_capacity` DOUBLE, IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR sqlexception
BEGIN
ROLLBACK;
END;
START TRANSACTION;
	SELECT COUNT(stand_type_id) INTO IsFound FROM pointnin_afc.stand_type WHERE name=p_name;
	IF IsFound=0 THEN
		INSERT INTO pointnin_afc.stand_type
		(name,
        description,
        capacity,
        status,
        createdby,
		modifiedby,
        createdon,
        modifiedon
		)
		VALUES
		(p_name,
		p_description,
        p_capacity,
        p_status,
        p_createdby,
        p_createdby,
        NOW(),
		NOW());
		SELECT LAST_INSERT_ID() INTO p_id;
	ELSE
		SELECT 0 INTO p_id;
	END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_STOCK_TRANSFER` (IN `p_type` TINYINT(2), IN `p_code` VARCHAR(50), IN `p_from_warehouse_id` INT(11), IN `p_product_id` INT(11), IN `p_attribute_value_id` INT(11), IN `p_from_units` INT(11), IN `p_units` INT(11), IN `p_transfer_date` DATE, IN `p_description` VARCHAR(250), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
SELECT COUNT(stock_transfer_id) INTO IsFound FROM pointnin_afc.stock_transfer WHERE code=p_code;
IF IsFound=0 THEN
	INSERT INTO pointnin_afc.stock_transfer
	(code,
	type,
	from_warehouse_id,
	product_id,
	attribute_value_id,
	from_units,
	units,
	transfer_date,
	description,
	status,
	createdby,
	modifiedby,
	createdon,
	modifiedon
	)
	VALUES
	(p_code,
	p_type,
	p_from_warehouse_id,
	p_product_id,
	p_attribute_value_id,
	p_from_units,
	p_units,
	p_transfer_date,
	p_description,
	p_status,
	p_createdby,
	p_createdby,
	NOW(),
	NOW());
	SELECT LAST_INSERT_ID() INTO p_id;
ELSE
    SELECT 0 INTO p_id;
END IF;	
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_STOCK_TRANSFER_DETAILS` (IN `p_stock_transfer_id` INT(11), IN `p_from_warehouse_id` INT(11), IN `p_to_warehouse_id` INT(11), IN `p_product_id` INT(11), IN `p_attribute_value_id` INT(11), IN `p_qty` INT(11), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
  INSERT INTO pointnin_afc.stock_transfer_details
  (stock_transfer_id,
  warehouse_id,
  qty,
  status,
  createdby,
  modifiedby,
  createdon,
  modifiedon)
  VALUES
  (p_stock_transfer_id,
  p_to_warehouse_id,
  p_qty,
  p_status,
  p_createdby,
  p_createdby,
  NOW(),
  NOW());

	UPDATE pointnin_afc.warehouse_products_stock
	SET
	qty=qty-p_qty,
	modifiedby=p_createdby,
	modifiedon=NOW()
	WHERE warehouse_id=p_from_warehouse_id AND product_id=p_product_id AND attribute_value_id=p_attribute_value_id;
  
	IF NOT EXISTS (SELECT S.id FROM pointnin_afc.warehouse_products_stock AS S WHERE S.warehouse_id=p_to_warehouse_id AND S.product_id=p_product_id AND S.attribute_value_id=p_attribute_value_id) THEN
		INSERT INTO pointnin_afc.warehouse_products_stock
		(warehouse_id,
		product_id,
		attribute_value_id,
		qty,
		status,
		createdby,
		modifiedby,
		createdon,
		modifiedon)
		VALUES
		(p_to_warehouse_id,
		p_product_id,
		p_attribute_value_id,
		p_qty,
		p_status,
		p_createdby,
		p_createdby,
		NOW(),
		NOW());
	ELSE
		UPDATE pointnin_afc.warehouse_products_stock
		SET
		qty=qty+p_qty,
		modifiedby=p_createdby,
		modifiedon=NOW()
		WHERE warehouse_id=p_to_warehouse_id AND product_id=p_product_id AND attribute_value_id=p_attribute_value_id;
	END IF;
  
  SELECT LAST_INSERT_ID() INTO p_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_SUPPLIER` (IN `p_name` VARCHAR(100), IN `p_phone` VARCHAR(15), IN `p_email` VARCHAR(150), IN `p_address` VARCHAR(255), IN `p_location_id` INT(11), IN `p_description` VARCHAR(255), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
  SELECT COUNT(supplier_id) INTO IsFound FROM pointnin_afc.supplier WHERE name=p_name;
  IF IsFound=0 THEN
    INSERT INTO pointnin_afc.supplier
    (name,
    phone,
    email,
    address,
    location_id,
    description,
    status,
    createdby,
    modifiedby,
    createdon,
    modifiedon
    )
    VALUES
    (p_name,
    p_phone,
    p_email,
    p_address,
    p_location_id,
    p_description,
    p_status,
    p_createdby,
    p_createdby,
    NOW(),
    NOW());
    SELECT LAST_INSERT_ID() INTO p_id;
  ELSE
    SELECT 0 INTO p_id;
  END IF;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_UPDATE_ATTANDENCE` (IN `p_warehouse_id` INT(11), IN `p_retailer_id` INT(11), IN `p_location_id` INT(11), IN `p_user_id` INT(11), IN `p_fsm_user_id` INT(11), IN `p_type` TINYINT(2), IN `p_punch_time` DATETIME, IN `p_access` TINYINT(2), IN `p_lat` VARCHAR(25), IN `p_long` VARCHAR(25), IN `p_img` VARCHAR(150), OUT `p_id` CHAR(36))  BEGIN
DECLARE newUuid CHAR(36);
DECLARE i_attendance_id CHAR(36);
DECLARE IsFound INT(1);

IF p_access=1 THEN
    UPDATE pointnin_afc.attendance
    SET
    access=2,
    punch_out=p_punch_time,
    closed=1,
    modifiedby=p_user_id,
    modifiedon=NOW()
    WHERE user_id=p_user_id AND type=1 AND access=1;
    
    SET newUuid = UUID();
    INSERT INTO pointnin_afc.attendance
    (attendance_id,
    wh_id,
    retailer_id,
    location_id,
    user_id,
    fsm_user_id,
    type,
    access,
    punch_in,
    closed,
    in_lat,
    in_long,
    in_img,
    status,
    createdby,
    modifiedby,
    createdon,
    modifiedon)
    VALUES
    (newUuid,
    p_warehouse_id,
    p_retailer_id,
    p_location_id,
    p_user_id,
    p_fsm_user_id,
    p_type,
    1,
    p_punch_time,
    1,
    p_lat,
    p_long,
    in_img,
    1,
    p_user_id,
    p_user_id,
    NOW(),
    NOW());
    SELECT newUuid INTO p_id;
ELSE
    SELECT COUNT(attendance_id),attendance_id INTO IsFound,i_attendance_id FROM pointnin_afc.attendance AS A WHERE A.user_id=p_user_id AND A.type=1 AND A.access=1;
    IF IsFound>0 THEN
        UPDATE pointnin_afc.attendance
        SET
        access=2,
        punch_out=p_punch_time,
        closed=1,
        out_lat=p_lat,
        out_long=p_long,
        out_img=p_img,
        modifiedby=p_user_id,
        modifiedon=NOW()
        WHERE user_id=p_user_id AND type=1 AND access=1;
        SELECT i_attendance_id INTO p_id;
	ELSE
        SELECT 111 INTO p_id;
    END IF;
END IF;
COMMIT;    
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_USER` (IN `p_warehouse_id` INT(11), IN `p_route_id` INT(11), IN `p_username` VARCHAR(50), IN `p_password` VARCHAR(150), IN `p_empcode` INT(11), IN `p_email` VARCHAR(150), IN `p_mobile` VARCHAR(12), IN `p_firstname` VARCHAR(150), IN `p_lastname` VARCHAR(150), IN `p_status` TINYINT(2), IN `p_device` TINYINT(2), IN `p_role` TINYINT(2), IN `p_registered_type` TINYINT(2), IN `p_profile_image` VARCHAR(255), IN `p_profile_image_type` TINYINT(2), IN `p_wh_distance` DOUBLE, IN `p_veh_id` INT(11), IN `p_wage_km` DOUBLE, IN `p_wage_hour` DOUBLE, IN `p_wage_per_stand` DOUBLE, IN `p_wage_new_stand` DOUBLE, IN `p_commission` DOUBLE, IN `p_imei` VARCHAR(255), IN `p_gcmkey` TEXT, IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
SELECT COUNT(user_id) INTO IsFound FROM pointnin_afc.users WHERE username = p_username;
IF IsFound=0 THEN
    INSERT INTO pointnin_afc.users
    (warehouse_id,
    route_id,
    username,
    password,
    empcode,
    email,
    mobile,
    firstname,
    lastname,
    status,
    device,
    role,
    registered_type,
    profile_image,
    profile_image_type,
    wh_distance,
    veh_id,
    wage_km,
    wage_hour,
    wage_per_stand,
    wage_new_stand,
    commission,
    imei,
    gcmkey,
    createdby,
    modifiedby,
    createdon,
    modifiedon)
    VALUES
    (p_warehouse_id,
    p_route_id,
    p_username,
    p_password,
    p_empcode,
    p_email,
    p_mobile,
    p_firstname,
    p_lastname,
    p_status,
    p_device,
    p_role,
    p_registered_type,
    p_profile_image,
    p_profile_image_type,
    p_wh_distance,
    p_veh_id,
    p_wage_km,
    p_wage_hour,
    p_wage_per_stand,
    p_wage_new_stand,
    p_commission,
    p_imei,
    p_gcmkey,
    p_createdby,
    p_createdby,
    NOW(),
    NOW());
    SELECT LAST_INSERT_ID() INTO p_id;
ELSE
    SELECT 0 INTO p_id;
END IF;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_USER_ROUTE` (IN `p_user_id` INT(11), IN `p_route_id` INT(11), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
SELECT COUNT(user_route_id) INTO IsFound FROM pointnin_afc.user_route WHERE user_id=p_user_id AND route_id=p_route_id;
  IF IsFound=0 THEN
	  INSERT INTO pointnin_afc.user_route
	  (user_id,
	  route_id,
	  status,
	  createdby,
	  modifiedby,
	  createdon,
	  modifiedon)
	  VALUES
	  (p_user_id,
	  p_route_id,
	  1,
	  p_createdby,
	  p_createdby,
	  NOW(),
	  NOW());
	  
	  SELECT LAST_INSERT_ID() INTO p_id;
  ELSE
	  SELECT 0 INTO p_id;
  END IF;
COMMIT;    
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_USER_ROUTES` (IN `p_user_id` INT(11), IN `p_stand_id` INT(11), IN `p_route_id` INT(11), IN `p_location_id` INT(11), IN `p_company_id` INT(11), IN `p_status` TINYINT(2), IN `p_position` INT(11), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
ROLLBACK;
END;
START TRANSACTION;
  INSERT INTO pointnin_afc.user_routes
  (user_id,
  stand_id,
  route_id,
  location_id,
  company_id,
  status,
  position,
  createdby,
  modifiedby,
  createdon,
  modifiedon)
  VALUES
  (p_user_id,
  p_stand_id,
  p_route_id,
  p_location_id,
  p_company_id,
  p_status,
  p_position,
  p_createdby,
  p_createdby,
  NOW(),
  NOW());
  
  UPDATE pointnin_afc.stand SET usage_status=1, modifiedby=p_createdby, modifiedon=NOW() WHERE stand_id=p_stand_id;
  
  SELECT LAST_INSERT_ID() INTO p_id;
COMMIT;    
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_VEHICLE` (IN `p_name` VARCHAR(100), IN `p_user_id` INT(11), IN `p_type` TINYINT(2), IN `p_capacity` INT(11), IN `p_usage_status` TINYINT(2), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
  SELECT COUNT(vehicle_id) INTO IsFound FROM pointnin_afc.vehicle WHERE name=p_name;
  IF IsFound=0 THEN
    INSERT INTO pointnin_afc.vehicle
    (name,
    user_id,
    type,
    capacity,
    usage_status,
    status,
    createdby,
    modifiedby,
    createdon,
    modifiedon
    )
    VALUES
    (p_name,
    p_user_id,
    p_type,
    p_capacity,
    p_usage_status,
    p_status,
    p_createdby,
    p_createdby,
    NOW(),
    NOW());
    SELECT LAST_INSERT_ID() INTO p_id;
  ELSE
    SELECT 0 INTO p_id;
  END IF;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `CREATE_WAREHOUSE` (IN `p_name` VARCHAR(150), IN `p_barcode` VARCHAR(8), IN `p_description` VARCHAR(255), IN `p_location_id` INT(11), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR sqlexception
BEGIN
ROLLBACK;
END;
START TRANSACTION;
	SELECT COUNT(warehouse_id) INTO IsFound FROM pointnin_afc.warehouse WHERE name=p_name;
	IF IsFound=0 THEN
		INSERT INTO pointnin_afc.warehouse
		(name,
		barcode,
        description,
        location_id,
        status,
        createdby,
		modifiedby,
        createdon,
        modifiedon
		)
		VALUES
		(p_name,
		p_barcode,
		p_description,
        p_location_id,
        p_status,
        p_createdby,
        p_createdby,
        NOW(),
		NOW());
		SELECT LAST_INSERT_ID() INTO p_id;
	ELSE
		SELECT 0 INTO p_id;
	END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `DELETE_COMPANY_LOCATION` (IN `p_company_id` INT(11))  BEGIN
DELETE FROM pointnin_afc.company_location WHERE company_id = p_company_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `DELETE_PRODUCT_PRICE` (IN `p_product_id` INT(11))  BEGIN
	DELETE FROM pointnin_afc.product_price WHERE product_id = p_product_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_ATTENDANCE_USER_WEB` (IN `p_status` TINYINT(2), IN `p_company_id` INT(11), IN `p_retailer_id` INT(11), IN `p_user_id` INT(11), IN `p_fromdate` DATETIME, IN `p_todate` DATETIME)  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery1 = CONCAT(" WHERE A.company_id='",p_company_id,"' AND A.user_id='",p_user_id,"'");
ELSE
	SET @whereQuery1 = CONCAT(" WHERE A.company_id='",p_company_id,"' AND A.user_id='",p_user_id,"' AND A.status='",p_status,"' AND (A.punch_in>='",p_fromdate,"' AND A.punch_in<='",p_todate,"')");
END IF;

IF p_retailer_id IS NULL THEN
    SET @whereQuery2 = CONCAT("");
ELSE
	SET @whereQuery2 = CONCAT(" AND A.retailer_id='",p_retailer_id,"'");
END IF;

SET @whereQuery = CONCAT(@whereQuery1,@whereQuery2);

SET @SQLQuery = "
SELECT
A.attendance_id,
A.user_id,
A.retailer_id,
A.access,
(SELECT AT.title FROM pointnin_connections.configuration as AT WHERE AT.type='LVE_OPT' AND AT.code=A.access AND A.type=2 LIMIT 1) as leavename,
A.type,
A.punch_in,
A.punch_out,
A.closed,
A.in_lat,
A.in_long,
A.out_lat,
A.out_long,
A.in_img,
A.out_img,
A.status,
B.firstname,
B.lastname,
C.retailer_name,
D.location_name,
E.name as country_name,
F.city_name
FROM pointnin_connections.attendance AS A
LEFT JOIN pointnin_connections.users AS B ON B.user_id=A.user_id
LEFT JOIN pointnin_connections.retailer AS C ON C.retailer_id=A.retailer_id
LEFT JOIN pointnin_connections.location AS D ON D.location_id=A.location_id
LEFT JOIN pointnin_connections.country AS E ON E.country_id=D.country_id
LEFT JOIN pointnin_connections.city AS F ON F.city_id=D.city_id";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.punch_in ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_ATTRIBUTE_VALUE` (IN `p_attribute_value_id` INT(11))  BEGIN
SELECT 
B.attribute_value_id,
B.attribute_id,
B.value,
B.title,
B.status,
B.number
FROM pointnin_afc.attribute_value AS B WHERE B.attribute_value_id=p_attribute_value_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_ATTRIBUTE_VALUES` (IN `p_code` VARCHAR(20))  BEGIN
IF p_code IS NULL THEN
    SET @whereQuery = CONCAT("");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.code='",p_code,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.attribute_id,
A.warehouse_id,
A.code,
A.type,
A.category,
A.name,
A.caption,
A.required,
A.status,
A.createdon,
B.attribute_value_id,
B.value,
B.title,
B.number
FROM pointnin_afc.attribute AS A
LEFT JOIN pointnin_afc.attribute_value AS B ON B.attribute_id=A.attribute_id";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.position ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_ATTRIBUTE_VALUES_ONLY` (IN `p_code` VARCHAR(20))  BEGIN
SELECT 
B.attribute_value_id,
B.attribute_id,
B.value,
B.title,
B.status,
B.number
FROM pointnin_afc.attribute_value AS B
WHERE B.attribute_value_id != 1
ORDER BY B.value ASC;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_CATEGORIES` (IN `p_status` TINYINT(2))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery = CONCAT("");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.category_id,
A.warehouse_id,
A.category_name,
A.category_desc,
A.position,
A.status,
A.trash,
A.createdon,
A.modifiedon,
(SELECT COUNT(PR.product_id) FROM pointnin_afc.product AS PR WHERE PR.category_id=A.category_id AND PR.status=1) as totalproducts
FROM pointnin_afc.category AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_CATEGORIES_FILTER` (IN `p_status` TINYINT(2), IN `p_brand_id` INT(11), IN `p_warehouse_id` INT(11))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery1 = CONCAT(" WHERE A.warehouse_id='",p_warehouse_id,"'");
ELSE
	SET @whereQuery1 = CONCAT(" WHERE A.warehouse_id='",p_warehouse_id,"' AND A.status='",p_status,"'");
END IF;

IF p_brand_id IS NULL THEN
    SET @whereQuery2 = CONCAT("");
ELSE
	SET @whereQuery2 = CONCAT(" AND B.brand_id='",p_brand_id,"'");
END IF;

SET @whereQuery = CONCAT(@whereQuery1,@whereQuery2);

SET @SQLQuery = "
SELECT 
A.category_id,
A.category_name,
A.status
FROM pointnin_afc.category AS A
LEFT JOIN pointnin_afc.category_brand AS B ON B.category_id=A.category_id";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.category_name ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_CATEGORIES_ONLY` (IN `p_status` TINYINT(2))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery = CONCAT("");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.category_id,
A.category_name
FROM pointnin_afc.category AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.category_name ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_CATEGORIES_USER` (IN `p_status` TINYINT(2), IN `p_warehouse_id` INT(11), IN `p_user_id` INT(11))  BEGIN
SELECT
B.category_id,
B.category_name,
B.status
FROM pointnin_afc.users_category AS A
LEFT JOIN pointnin_afc.category AS B ON B.category_id=A.category_id
WHERE A.warehouse_id=p_warehouse_id AND A.user_id=p_user_id AND B.status=p_status
ORDER BY B.category_name ASC;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_CATEGORY` (IN `p_category_id` INT(11))  BEGIN
SELECT 
A.category_id,
A.warehouse_id,
A.category_name,
A.category_desc,
A.position,
A.status,
A.trash,
A.createdon,
A.modifiedon
FROM pointnin_afc.category AS A
WHERE A.category_id=p_category_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_CITIES` (IN `p_status` TINYINT(2), IN `p_country_id` INT(11))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery1 = CONCAT(" WHERE A.city_id IS NOT NULL");
ELSE
	SET @whereQuery1 = CONCAT(" WHERE A.status='",p_status,"' AND B.status='",p_status,"'");
END IF;

IF p_country_id IS NULL THEN
    SET @whereQuery2 = CONCAT("");
ELSE
	SET @whereQuery2 = CONCAT(" AND A.country_id='",p_country_id,"'");
END IF;

SET @whereQuery = CONCAT(@whereQuery1,@whereQuery2);

SET @SQLQuery = "
SELECT 
A.city_id,
A.country_id,
A.state_id,
A.city_name,
A.latitude,
A.longitude,
A.status,
A.createdby,
A.createdon,
A.modifiedon,
B.name as country_name
FROM pointnin_afc.city AS A
LEFT JOIN pointnin_afc.country AS B ON B.country_id=A.country_id";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_CITY` (IN `p_city_id` INT(11))  BEGIN
SELECT 
A.city_id,
A.country_id,
A.state_id,
A.city_name,
A.latitude,
A.longitude,
A.status,
A.createdby,
A.createdon,
A.modifiedon,
B.name as country_name
FROM pointnin_afc.city AS A
LEFT JOIN pointnin_afc.country AS B ON B.country_id=A.country_id
WHERE A.city_id=p_city_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_COLLECTIONS` (IN `p_status` TINYINT(2), IN `p_user_id` INT(11), IN `p_fromdate` DATE, IN `p_todate` DATE)  BEGIN

IF p_status IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.id!=0");
ELSE
	SET @where1 = CONCAT(" WHERE A.status='",p_status,"' AND B.status='",p_status,"'");
END IF;

IF p_user_id IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
    SET @where2 = CONCAT(" AND A.user_id='",p_user_id,"'");
END IF;

IF p_fromdate IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
    SET @where3 = CONCAT(" AND A.service_date >='",p_fromdate,"' AND A.service_date <='",p_todate,"'");    
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @SQLQuery = "
SELECT 
A.id,
A.type,
A.user_id,
A.sale_amount,
A.total_amount,
A.eftpos,
A.eft,
A.cheque,
A.format1,
A.format2,
A.format3,
A.format4,
A.format5,
A.format6,
A.format7,
A.service_date,
A.branch_name,
A.notes,
A.status,
A.createdon,
B.firstname,
B.lastname,
B.role,
B.timezone
FROM pointnin_afc.collection AS A
LEFT JOIN pointnin_afc.users AS B ON B.user_id=A.user_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_COMPANIES` (IN `p_status` TINYINT(2), IN `p_route_id` INT(11), IN `p_search` VARCHAR(250), IN `p_limit_from` INT(11), IN `p_limit_to` INT(11))  BEGIN

SET @d_limit_from = p_limit_from;
SET @d_limit_to = p_limit_to;

IF p_route_id IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.company_id IS NOT NULL");
ELSE
	SET @where1 = CONCAT(" WHERE B.route_id='",p_route_id,"'");
END IF;

IF p_status IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
	SET @where2 = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

IF p_search IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
	SET @where3 = CONCAT(" AND (A.name LIKE '",p_search,"')");
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @SQLQuery = "
SELECT 
A.company_id,
A.name,
A.phone,
A.email,
A.address,
A.description,
A.image,
A.outstandingamount,
A.status,
A.trash,
A.createdon,
A.modifiedon,
D.name as route_name,
GROUP_CONCAT(DISTINCT C.location_name) as location_name
FROM pointnin_afc.company AS A
LEFT JOIN pointnin_afc.company_location AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=B.location_id
LEFT JOIN pointnin_afc.route AS D ON D.route_id=B.route_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' GROUP BY A.company_id ORDER BY A.createdon DESC LIMIT ?, ?');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE STMT USING @d_limit_from, @d_limit_to;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_COMPANIES_ROWS` (IN `p_status` TINYINT(2), IN `p_route_id` INT(11), IN `p_search` VARCHAR(250))  BEGIN

IF p_route_id IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.company_id IS NOT NULL");
ELSE
	SET @where1 = CONCAT(" WHERE B.route_id='",p_route_id,"'");
END IF;

IF p_status IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
	SET @where2 = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

IF p_search IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
	SET @where3 = CONCAT(" AND (A.name LIKE '",p_search,"')");
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @SQLQuery = "
SELECT 
A.company_id
FROM pointnin_afc.company AS A
LEFT JOIN pointnin_afc.company_location AS B ON B.company_id=A.company_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' GROUP BY A.company_id');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_COMPANY` (IN `p_id` INT(11))  BEGIN

SELECT 
A.company_id,
A.name,
A.phone,
A.email,
A.address,
A.location_id,
A.description,
A.image,
A.outstandingamount,
A.status,
A.trash,
A.createdon,
A.modifiedon
FROM pointnin_afc.company AS A
WHERE A.company_id=p_id;

END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_COMPANY_LOCATION` (IN `p_company_id` INT(11))  BEGIN
SELECT 
A.company_location_id,
A.company_id,
A.location_id,
A.route_id
FROM pointnin_afc.company_location AS A
WHERE A.company_id=p_company_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_COMPANY_LOCATION_ROOT` (IN `p_status` TINYINT(2))  BEGIN
SELECT 
A.company_location_id,
A.company_id,
A.location_id,
A.route_id,
(SELECT M.name FROM pointnin_afc.route as M WHERE M.route_id=A.route_id) as route_name,
B.name as company_name,
C.location_name
FROM pointnin_afc.company_location AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=A.location_id
WHERE B.status=p_status AND C.status=p_status;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_CONFIG` (IN `p_type` VARCHAR(7))  BEGIN
SELECT
A.id,
A.code,
A.title,
A.value1
FROM pointnin_afc.configuration AS A
WHERE A.type=p_type AND A.status=1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_COUNTRIES` (IN `p_status` TINYINT(2))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery = CONCAT("");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.country_id,
A.iso,
A.name,
A.currency_code,
A.numcode,
A.phonecode,
A.zone_name,
A.status,
A.createdon
FROM pointnin_afc.country AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_COUNTRY` (IN `p_country_id` INT(11))  BEGIN
SELECT 
A.country_id,
A.iso,
A.name,
A.currency_code,
A.numcode,
A.phonecode,
A.zone_name,
A.status,
A.createdon
FROM pointnin_afc.country AS A
WHERE A.country_id=p_country_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_CURRENCY` (IN `p_status` TINYINT(2))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery = CONCAT("");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.currency_id,
A.name,
A.currency_code,
A.symbol_left,
A.symbol_right,
A.status
FROM pointnin_afc.currency AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.name ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_FASTEST_SELLING` (IN `p_route_id` INT(11), IN `p_stand_id` INT(11), IN `p_from_date` DATE, IN `p_to_date` DATE)  BEGIN

IF p_route_id IS NULL THEN
    SET @where1 = CONCAT(" WHERE B.route_id!=0");
ELSE
	SET @where1 = CONCAT(" WHERE B.route_id='",p_route_id,"'");
END IF;

IF p_stand_id IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
	SET @where2 = CONCAT(" AND B.stand_id='",p_stand_id,"'");
END IF;

IF p_from_date IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
    SET @where3 = CONCAT(" AND B.service_date >='",p_from_date,"' AND B.service_date <='",p_to_date,"'");    
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @aSQLQuery1 = "
SELECT x.*, y.* FROM
(
SELECT
COUNT(A.sale_item_id) as sale_rows,
A.product_id,
(SELECT J.product_name FROM pointnin_afc.product as J WHERE J.product_id=A.product_id) as product_name,
A.attribute_value_id,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title,
SUM(A.qty) as order_qty,
SUM(A.price) as order_price
FROM pointnin_afc.sale_items AS A
LEFT JOIN pointnin_afc.sale AS B ON B.sale_id=A.sale_id";

SET @aSQLQuery2 = CONCAT(@aSQLQuery1,@where);
SET @aFinalSQLQuery = CONCAT(@aSQLQuery2,' GROUP BY A.product_id, A.attribute_value_id ) x');

SET @bSQLQuery1 = " JOIN (
SELECT
A.product_id,
A.attribute_value_id,
COUNT(A.sri_id) as return_rows,
SUM(A.qty) as return_qty,
SUM(A.price) as return_price
FROM pointnin_afc.sale_return_items AS A
LEFT JOIN pointnin_afc.sale_return AS B ON B.sale_return_id=A.sale_return_id";

SET @bSQLQuery2 = CONCAT(@bSQLQuery1,@where);
SET @bFinalSQLQuery = CONCAT(@bSQLQuery2,' GROUP BY A.product_id, A.attribute_value_id ) y ON x.product_id=y.product_id AND x.attribute_value_id=y.attribute_value_id');

SET @FinalSQLQuery = CONCAT(@aFinalSQLQuery,@bFinalSQLQuery);

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_LOCATION` (IN `p_location_id` INT(11))  BEGIN
SELECT 
A.location_id,
A.country_id,
A.city_id,
A.location_name,
A.address,
A.latitude,
A.longitude,
A.route_id,
A.status,
A.createdby,
A.modifiedby,
A.createdon,
A.modifiedon,
B.name as country_name,
C.city_name
FROM pointnin_afc.location AS A
LEFT JOIN pointnin_afc.country AS B ON B.country_id=A.country_id
LEFT JOIN pointnin_afc.city AS C ON C.city_id=A.city_id
WHERE A.location_id=p_location_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_LOCATIONS` (IN `p_status` TINYINT(2), IN `p_route_id` INT(11), IN `p_city_id` INT(11), IN `p_search` VARCHAR(250), IN `p_limit_from` INT(11), IN `p_limit_to` INT(11))  BEGIN

SET @d_limit_from = p_limit_from;
SET @d_limit_to = p_limit_to;

IF p_route_id IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.location_id IS NOT NULL");
ELSE
	SET @where1 = CONCAT(" WHERE A.route_id='",p_route_id,"'");
END IF;

IF p_city_id IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
	SET @where2 = CONCAT(" AND A.city_id='",p_city_id,"'");
END IF;

IF p_status IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
	SET @where3 = CONCAT(" AND A.status='",p_status,"'");
END IF;

IF p_search IS NULL THEN
    SET @where4 = CONCAT("");
ELSE
	SET @where4 = CONCAT(" AND (A.location_name LIKE '",p_search,"')");
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);
SET @where = CONCAT(@where,@where4);

SET @SQLQuery = "
SELECT 
A.location_id,
A.country_id,
A.city_id,
A.location_name,
A.address,
A.status,
A.createdby,
A.modifiedby,
A.createdon,
A.modifiedon,
B.name as country_name,
C.city_name,
D.name as route_name
FROM pointnin_afc.location AS A
LEFT JOIN pointnin_afc.country AS B ON B.country_id=A.country_id
LEFT JOIN pointnin_afc.city AS C ON C.city_id=A.city_id
LEFT JOIN pointnin_afc.route AS D ON D.route_id=A.route_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC LIMIT ?, ?');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE STMT USING @d_limit_from, @d_limit_to;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_LOCATIONS_ROWS` (IN `p_status` TINYINT(2), IN `p_route_id` INT(11), IN `p_city_id` INT(11), IN `p_search` VARCHAR(250))  BEGIN

IF p_route_id IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.location_id IS NOT NULL");
ELSE
	SET @where1 = CONCAT(" WHERE A.route_id='",p_route_id,"'");
END IF;

IF p_city_id IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
	SET @where2 = CONCAT(" AND A.city_id='",p_city_id,"'");
END IF;

IF p_status IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
	SET @where3 = CONCAT(" AND A.status='",p_status,"'");
END IF;

IF p_search IS NULL THEN
    SET @where4 = CONCAT("");
ELSE
	SET @where4 = CONCAT(" AND (A.location_name LIKE '",p_search,"')");
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);
SET @where = CONCAT(@where,@where4);

SET @SQLQuery = "
SELECT 
A.location_id
FROM pointnin_afc.location AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,'');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_LOCATION_ROOT` (IN `p_status` TINYINT(2))  BEGIN
SELECT 
A.location_id,
A.route_id,
A.country_id,
A.city_id,
A.location_name,
B.city_name,
C.name as country_name
FROM pointnin_afc.location AS A
INNER JOIN pointnin_afc.city AS B ON B.city_id=A.city_id
INNER JOIN pointnin_afc.country AS C ON C.country_id=A.country_id
WHERE A.status=p_status AND B.status=p_status AND C.status=p_status
ORDER BY A.location_name ASC;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_OVERALL_PERFORMANCE` (IN `p_route_id` INT(11), IN `p_fromdate` DATE, IN `p_todate` DATE, IN `p_fromdatetime` DATETIME, IN `p_todatetime` DATETIME)  BEGIN

SET @d_fromdate = p_fromdate;
SET @d_todate = p_todate;
SET @d_fromdatetime = p_fromdatetime;
SET @d_todatetime = p_todatetime;

IF p_route_id IS NULL THEN
    SET @where = CONCAT(" WHERE A.status=1");
ELSE
	SET @where = CONCAT(" WHERE A.status=1 AND A.route_id='",p_route_id,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.route_id,
A.name,
(SELECT COUNT(L.id) FROM pointnin_afc.stand_remove as L WHERE L.route_id=A.route_id AND (L.createdon>=@d_fromdatetime AND L.createdon<=@d_todatetime)) as removed_stand,
(SELECT COUNT(N.id) FROM pointnin_afc.stand_history as N WHERE N.route_id=A.route_id AND (N.createdon>=@d_fromdatetime AND N.createdon<=@d_todatetime)) as new_stand,
(SELECT COUNT(O.stand_id) FROM pointnin_afc.stand as O WHERE O.route_id=A.route_id) as total_stand,
(SELECT CONCAT_WS('-',AVG(Q.order_amount),AVG(Q.sale_amount),AVG(Q.return_amount)) FROM pointnin_afc.receipt as Q WHERE Q.route_id=A.route_id AND (Q.createdon>=@d_fromdatetime AND Q.createdon<=@d_todatetime)) as avg_amount,
(SELECT CONCAT_WS('-',SUM(R.order_amount),SUM(R.sale_amount),SUM(R.return_amount)) FROM pointnin_afc.receipt as R WHERE R.route_id=A.route_id AND (R.createdon>=@d_fromdatetime AND R.createdon<=@d_todatetime)) as sum_amount
FROM pointnin_afc.route AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.name ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_PRODUCT` (IN `p_product_id` INT(11))  BEGIN
SELECT 
A.product_id,
A.warehouse_id,
A.category_id,
A.product_name,
A.configuration,
A.short_desc,
A.status,
A.createdon,
A.modifiedon,
B.category_name
FROM pointnin_afc.product AS A
LEFT JOIN pointnin_afc.category AS B ON B.category_id=A.category_id
WHERE A.product_id=p_product_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_PRODUCTS` (IN `p_status` TINYINT(2), IN `p_category_id` INT(11))  BEGIN

IF p_category_id IS NULL THEN
    SET @whereQuery1 = CONCAT(" WHERE A.product_id!=0");
ELSE
	SET @whereQuery1 = CONCAT(" WHERE A.category_id='",p_category_id,"'");
END IF;

IF p_status IS NULL THEN
    SET @whereQuery2 = CONCAT("");
ELSE
	SET @whereQuery2 = CONCAT(" AND A.status='",p_status,"' AND B.status='",p_status,"' AND C.status='",p_status,"' AND D.status='",p_status,"'");
END IF;

SET @whereQuery = CONCAT(@whereQuery1,@whereQuery2);

SET @SQLQuery = "
SELECT 
A.product_id,
A.warehouse_id,
A.category_id,
A.product_name,
A.configuration,
A.short_desc,
A.status,
A.createdon,
A.modifiedon,
B.name as warehouse_name,
C.category_name
FROM pointnin_afc.product AS A
LEFT JOIN pointnin_afc.warehouse AS B ON B.warehouse_id=A.warehouse_id
LEFT JOIN pointnin_afc.category AS C ON C.category_id=A.category_id";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_PRODUCTS_ATTR_ONLY` (IN `p_status` TINYINT(2), IN `p_category_id` INT(11))  BEGIN

IF p_category_id IS NULL THEN
    SET @whereQuery1 = CONCAT(" WHERE A.product_id!=0");
ELSE
	SET @whereQuery1 = CONCAT(" WHERE A.category_id='",p_category_id,"'");
END IF;

IF p_status IS NULL THEN
    SET @whereQuery2 = CONCAT("");
ELSE
	SET @whereQuery2 = CONCAT(" AND A.status='",p_status,"'");
END IF;

SET @whereQuery = CONCAT(@whereQuery1,@whereQuery2);

SET @SQLQuery = "
SELECT 
A.product_id,
A.product_name,
B.attribute_value_id,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=B.attribute_value_id) as attribute_title
FROM pointnin_afc.product AS A
LEFT JOIN pointnin_afc.product_price AS B ON B.product_id=A.product_id";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.product_name ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_PRODUCTS_ONLY` (IN `p_status` TINYINT(2), IN `p_category_id` INT(11))  BEGIN

IF p_category_id IS NULL THEN
    SET @whereQuery1 = CONCAT(" WHERE A.product_id!=0");
ELSE
	SET @whereQuery1 = CONCAT(" WHERE A.category_id='",p_category_id,"'");
END IF;

IF p_status IS NULL THEN
    SET @whereQuery2 = CONCAT("");
ELSE
	SET @whereQuery2 = CONCAT(" AND A.status='",p_status,"'");
END IF;

SET @whereQuery = CONCAT(@whereQuery1,@whereQuery2);

SET @SQLQuery = "
SELECT 
A.product_id,
A.product_name
FROM pointnin_afc.product AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.product_name ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_PRODUCTS_REQUEST` (IN `p_up_id` CHAR(36))  BEGIN

SELECT 
A.upd_id,
A.up_id,
A.user_id,
A.warehouse_id,
A.product_id,
A.attribute_value_id,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title,
A.qty,
A.requested_qty,
A.price,
A.status,
B.product_name,
C.barcode
FROM pointnin_afc.user_products_details AS A
LEFT JOIN pointnin_afc.product AS B ON B.product_id=A.product_id
LEFT JOIN pointnin_afc.product_price AS C ON C.product_id=A.product_id AND C.attribute_value_id=A.attribute_value_id
WHERE A.up_id=p_up_id;

END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_PRODUCTS_REQUESTS` (IN `p_status` TINYINT(2), IN `p_type` TINYINT(2), IN `p_fromdate` DATETIME, IN `p_todate` DATETIME)  BEGIN

IF p_status IS NULL THEN
    SET @where1 = CONCAT(" WHERE 1");
ELSE
	SET @where1 = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

IF p_type IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
	SET @where2 = CONCAT(" AND A.type='",p_type,"'");
END IF;

IF p_fromdate IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
    SET @where3 = CONCAT(" AND A.createdon >='",p_fromdate,"' AND A.createdon <='",p_todate,"'");    
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @SQLQuery = "
SELECT 
A.up_id,
A.type,
A.total_qty,
A.status,
A.createdon,
B.firstname,
B.lastname,
B.timezone
FROM pointnin_afc.user_products AS A
LEFT JOIN pointnin_afc.users AS B ON B.user_id=A.user_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_PRODUCTS_REQUESTS_ITEM` (IN `p_up_id` CHAR(36))  BEGIN

SELECT 
A.up_id,
A.type,
A.total_qty,
A.status,
A.createdon,
B.firstname,
B.lastname,
B.timezone
FROM pointnin_afc.user_products AS A
LEFT JOIN pointnin_afc.users AS B ON B.user_id=A.user_id
WHERE A.up_id=p_up_id;

END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_PRODUCTS_REQUEST_ONLY` (IN `p_up_id` CHAR(36))  BEGIN

SELECT 
A.upd_id,
A.up_id,
A.user_id,
A.warehouse_id,
A.product_id,
A.attribute_value_id,
A.qty,
A.price
FROM pointnin_afc.user_products_details AS A
WHERE A.up_id=p_up_id AND A.status=0;

END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_PRODUCT_PRICES` (IN `p_product_id` INT(11))  BEGIN
SELECT 
A.product_price_id,
A.warehouse_id,
A.product_id,
A.attribute_value_id,
A.name,
A.price,
A.tax,
A.weight,
A.barcode,
B.value,
B.title as attribute_title,
B.number as attribute_number
FROM pointnin_afc.product_price AS A
INNER JOIN pointnin_afc.attribute_value AS B ON B.attribute_value_id=A.attribute_value_id
WHERE A.product_id=p_product_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_PURCHASE` (IN `p_purchase_id` INT(11))  BEGIN

SELECT 
A.purchase_id,
A.order_code,
A.supplier_id,
A.product_id,
A.units,
A.unit_price,
A.sales_price,
A.bulk_price,
A.bagging_price,
A.config_id,
A.packing_id,
A.purchase_date,
A.description,
A.status,
A.createdon,
A.modifiedon,
B.product_name,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title
FROM pointnin_afc.purchase AS A
LEFT JOIN pointnin_afc.product AS B ON B.product_id=A.product_id
WHERE A.purchase_id=p_purchase_id LIMIT 1;

END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_PURCHASES` (IN `p_status` TINYINT(2))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery = CONCAT("");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.purchase_id,
A.order_code,
A.product_id,
A.units,
A.unit_price,
A.sales_price,
A.bulk_price,
A.bagging_price,
A.config_id,
A.packing_id,
A.status,
A.createdon,
A.modifiedon,
B.product_name,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title
FROM pointnin_afc.purchase AS A
LEFT JOIN pointnin_afc.product AS B ON B.product_id=A.product_id";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_RECEIPTS` (IN `p_status` TINYINT(2), IN `p_warehouse_id` INT(11), IN `p_fromdate` DATE, IN `p_todate` DATE)  BEGIN

SET @d_fromdate = p_fromdate;
SET @d_todate = p_todate;

IF p_status IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.user_id!=0");
ELSE
	SET @where1 = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

IF p_warehouse_id IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
    SET @where2 = CONCAT(" AND A.warehouse_id='",p_warehouse_id,"'");
END IF;

IF p_fromdate IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
    SET @where3 = CONCAT(" AND A.service_date >='",p_fromdate,"' AND A.service_date <='",p_todate,"'");    
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @SQLQuery = "
SELECT 
A.order_amount,
A.sale_amount,
A.return_amount,
A.pay_type,
A.chequeno,
A.bankname,
A.chequedate,
A.narration,
A.honesty_rate,
A.service_date,
A.createdon,
(SELECT M.name FROM pointnin_afc.route as M WHERE M.route_id=A.route_id) as route_name,
B.name as company_name,
C.location_name,
D.barcode,
E.firstname,
E.lastname,
E.timezone
FROM pointnin_afc.receipt AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=A.location_id
LEFT JOIN pointnin_afc.stand AS D ON D.stand_id=A.stand_id
LEFT JOIN pointnin_afc.users AS E ON E.user_id=A.user_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.service_date DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_ROUTE` (IN `p_route_id` INT(11))  BEGIN
SELECT 
A.route_id,
A.name,
A.status
FROM pointnin_afc.route AS A
WHERE A.route_id=p_route_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_ROUTES` (IN `p_status` TINYINT(2))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery = CONCAT("");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.route_id,
A.name,
A.status,
A.trash,
A.createdon,
A.modifiedon
FROM pointnin_afc.route AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_ROUTES_ONLY` (IN `p_status` TINYINT(2))  BEGIN

SELECT 
A.route_id,
A.name
FROM pointnin_afc.route AS A
WHERE A.status=p_status
ORDER BY A.name ASC;

END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_SALES` (IN `p_status` TINYINT(2), IN `p_warehouse_id` INT(11), IN `p_fromdate` DATE, IN `p_todate` DATE)  BEGIN

IF p_status IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.company_id IS NOT NULL");
ELSE
	SET @where1 = CONCAT(" WHERE A.company_id IS NOT NULL AND A.status='",p_status,"'");
END IF;

IF p_warehouse_id IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
    SET @where2 = CONCAT(" AND A.warehouse_id='",p_warehouse_id,"'");
END IF;

IF p_fromdate IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
    SET @where3 = CONCAT(" AND A.service_date >='",p_fromdate,"' AND A.service_date <='",p_todate,"'");    
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @SQLQuery = "
SELECT 
A.sale_id,
A.type,
A.mode,
A.chipboxes,
A.total_qty,
A.total_amount,
A.service_date,
A.createdon,
(SELECT M.name FROM pointnin_afc.route as M WHERE M.route_id=A.route_id) as route_name,
B.name as company_name,
C.location_name,
D.barcode,
E.firstname,
E.lastname,
E.timezone
FROM pointnin_afc.sale AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=A.location_id
LEFT JOIN pointnin_afc.stand AS D ON D.stand_id=A.stand_id
LEFT JOIN pointnin_afc.users AS E ON E.user_id=A.user_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.service_date DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_SALES_ITEMS` (IN `p_status` TINYINT(2), IN `p_warehouse_id` INT(11), IN `p_fromdate` DATE, IN `p_todate` DATE)  BEGIN

SET @d_fromdate = p_fromdate;
SET @d_todate = p_todate;

IF p_status IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.user_id!=0");
ELSE
	SET @where1 = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

IF p_warehouse_id IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
    SET @where2 = CONCAT(" AND A.warehouse_id='",p_warehouse_id,"'");
END IF;

IF p_fromdate IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
    SET @where3 = CONCAT(" AND A.service_date >='",p_fromdate,"' AND A.service_date <='",p_todate,"'");    
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @SQLQuery = "
SELECT 
A.sale_id,
A.type,
A.mode,
A.chipboxes,
A.total_qty,
A.total_amount,
A.service_date,
(SELECT M.name FROM pointnin_afc.route as M WHERE M.route_id=A.route_id) as route_name,
B.name as company_name,
C.location_name,
D.barcode,
E.firstname,
E.lastname
FROM pointnin_afc.sale_items AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=A.location_id
LEFT JOIN pointnin_afc.stand AS D ON D.stand_id=A.stand_id
LEFT JOIN pointnin_afc.users AS E ON E.user_id=A.user_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.service_date DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_SALES_RETURNS` (IN `p_status` TINYINT(2), IN `p_warehouse_id` INT(11), IN `p_fromdate` DATE, IN `p_todate` DATE)  BEGIN

IF p_status IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.user_id!=0");
ELSE
	SET @where1 = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

IF p_warehouse_id IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
    SET @where2 = CONCAT(" AND A.warehouse_id='",p_warehouse_id,"'");
END IF;

IF p_fromdate IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
    SET @where3 = CONCAT(" AND A.service_date >='",p_fromdate,"' AND A.service_date <='",p_todate,"'");    
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @SQLQuery = "
SELECT 
A.sale_return_id,
A.total_qty,
A.total_amount,
A.service_date,
A.createdon,
(SELECT M.name FROM pointnin_afc.route as M WHERE M.route_id=A.route_id) as route_name,
B.name as company_name,
C.location_name,
D.barcode,
E.firstname,
E.lastname,
E.timezone
FROM pointnin_afc.sale_return AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=A.location_id
LEFT JOIN pointnin_afc.stand AS D ON D.stand_id=A.stand_id
LEFT JOIN pointnin_afc.users AS E ON E.user_id=A.user_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.service_date DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_SALES_RETURN_ITEMS` (IN `p_status` TINYINT(2), IN `p_sale_return_id` CHAR(36))  BEGIN

IF p_status IS NULL THEN
    SET @where = CONCAT(" WHERE A.sale_return_id='",p_sale_return_id,"'");
ELSE
	SET @where = CONCAT(" WHERE A.sale_return_id='",p_sale_return_id,"' AND A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.sri_id,
A.product_id,
A.attribute_value_id,
A.qty,
A.price,
A.status,
B.product_name,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title,
(SELECT M.barcode FROM pointnin_afc.product_price as M WHERE M.product_id=A.product_id AND M.attribute_value_id=A.attribute_value_id) as barcode
FROM pointnin_afc.sale_return_items AS A
LEFT JOIN pointnin_afc.product AS B ON B.product_id=A.product_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_SALES_RETURN_VIEW` (IN `p_sale_return_id` CHAR(36))  BEGIN
SELECT 
A.sale_return_id,
A.total_qty,
A.total_amount,
A.service_date,
A.createdon,
(SELECT M.name FROM pointnin_afc.route as M WHERE M.route_id=A.route_id) as route_name,
B.name as company_name,
C.location_name,
D.barcode,
E.firstname,
E.lastname,
E.timezone
FROM pointnin_afc.sale_return AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=A.location_id
LEFT JOIN pointnin_afc.stand AS D ON D.stand_id=A.stand_id
LEFT JOIN pointnin_afc.users AS E ON E.user_id=A.user_id
WHERE A.sale_return_id=p_sale_return_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_SALE_ITEMS` (IN `p_status` TINYINT(2), IN `p_sale_id` CHAR(36))  BEGIN

IF p_status IS NULL THEN
    SET @where = CONCAT(" WHERE A.sale_id='",p_sale_id,"'");
ELSE
	SET @where = CONCAT(" WHERE A.sale_id='",p_sale_id,"' AND A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.sale_item_id,
A.product_id,
A.attribute_value_id,
A.qty,
A.price,
A.status,
B.product_name,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title,
(SELECT M.barcode FROM pointnin_afc.product_price as M WHERE M.product_id=A.product_id AND M.attribute_value_id=A.attribute_value_id) as barcode
FROM pointnin_afc.sale_items AS A
LEFT JOIN pointnin_afc.product AS B ON B.product_id=A.product_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_SALE_VIEW` (IN `p_sale_id` CHAR(36))  BEGIN
SELECT 
A.sale_id,
A.type,
A.mode,
A.chipboxes,
A.total_qty,
A.total_amount,
A.service_date,
A.createdon,
(SELECT M.name FROM pointnin_afc.route as M WHERE M.route_id=A.route_id) as route_name,
B.name as company_name,
C.location_name,
D.barcode,
E.firstname,
E.lastname,
E.timezone
FROM pointnin_afc.sale AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=A.location_id
LEFT JOIN pointnin_afc.stand AS D ON D.stand_id=A.stand_id
LEFT JOIN pointnin_afc.users AS E ON E.user_id=A.user_id
WHERE A.sale_id=p_sale_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_SERVICE_ROUTINE` (IN `p_status` TINYINT(2), IN `p_fromdate` DATE, IN `p_todate` DATE)  BEGIN

SET @d_fromdate = p_fromdate;
SET @d_todate = p_todate;

IF p_status IS NULL THEN
    SET @where = CONCAT(" WHERE A.usage_status=1 AND A.company_id IS NOT NULL");
ELSE
	SET @where = CONCAT(" WHERE A.status='",p_status,"' AND A.usage_status=1 AND A.company_id IS NOT NULL");
END IF;

SET @SQLQuery = "
SELECT 
A.stand_id,
A.order_amount,
A.company_id,
A.location_id,
(SELECT SUM(L.amount) FROM pointnin_afc.user_expenses as L WHERE L.company_id=A.company_id AND L.location_id=A.location_id AND (L.service_date>=@d_fromdate AND L.service_date<=@d_todate)) as servicing,
(SELECT CONCAT_WS('-',SUM(J.order_amount),SUM(J.sale_amount),SUM(J.return_amount)) FROM pointnin_afc.receipt as J WHERE J.company_id=A.company_id AND J.location_id=A.location_id AND (J.service_date>=@d_fromdate AND J.service_date<=@d_todate)) as receipt
FROM pointnin_afc.stand AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,"");

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_SERVICE_ROUTINE_ONLY` (IN `p_status` TINYINT(2), IN `p_fromrange` INT(11), IN `p_torange` INT(11))  BEGIN

IF p_status IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.usage_status=1 AND A.company_id IS NOT NULL");
ELSE
	SET @where1 = CONCAT(" WHERE A.status='",p_status,"' AND A.usage_status=1 AND A.company_id IS NOT NULL");
END IF;

IF p_torange IS NULL THEN
    SET @where2 = CONCAT(" AND A.order_amount>'",p_fromrange,"'");
ELSEIF p_fromrange IS NULL THEN
	SET @where2 = CONCAT(" AND A.order_amount<='",p_torange,"'");
ELSE
	SET @where2 = CONCAT(" AND (A.order_amount>'",p_fromrange,"' AND A.order_amount<='",p_torange,"')");
END IF;
SET @where = CONCAT(@where1,@where2);

SET @SQLQuery = "
SELECT 
A.stand_id,
A.order_amount,
A.company_id,
A.location_id
FROM pointnin_afc.stand AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,"");

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_SERVICE_ROUTINE_REPORTS` (IN `p_type` TINYINT(2), IN `p_status` TINYINT(2), IN `p_from_amount` DOUBLE, IN `p_to_amount` DOUBLE)  BEGIN

SET @where1 = CONCAT(" WHERE A.usage_status=1 AND A.company_id IS NOT NULL");

IF p_type=1 THEN
    SET @where2 = CONCAT(" AND A.order_amount>'",p_from_amount,"'");
ELSEIF p_type=2 THEN
	SET @where2 = CONCAT(" AND A.order_amount<'",p_from_amount,"'");
ELSE
	SET @where2 = CONCAT(" AND (A.order_amount>'",p_from_amount,"' AND A.order_amount<'",p_to_amount,"')");
END IF;

IF p_status IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
	SET @where3 = CONCAT(" AND A.status='",p_status,"'");
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @SQLQuery = "
SELECT 
A.stand_id,
A.barcode,
A.order_amount,
A.company_id,
A.location_id,
B.name as company_name,
C.name as route_name
FROM pointnin_afc.stand AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.route AS C ON C.route_id=A.route_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,"");

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_SERVICE_UNABLE_REASON` (IN `p_status` TINYINT(2), IN `p_type` TINYINT(2), IN `p_fromdate` DATETIME, IN `p_todate` DATETIME)  BEGIN

IF p_status IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.user_id !=0");
ELSE
	SET @where1 = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

IF p_type IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
	SET @where2 = CONCAT(" AND A.type='",p_type,"'");
END IF;

IF p_fromdate IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
    SET @where3 = CONCAT(" AND A.createdon >='",p_fromdate,"' AND A.createdon <='",p_todate,"'");    
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @SQLQuery = "
SELECT 
A.id,
A.type,
A.user_id,
A.route_id,
(SELECT M.name FROM pointnin_afc.route as M WHERE M.route_id=A.route_id) as route_name,
A.company_id,
A.location_id,
A.stand_id,
A.notes,
A.status,
A.createdon,
B.name as company_name,
C.location_name,
D.name as stand_name,
D.barcode,
E.firstname,
E.lastname
FROM pointnin_afc.stands_service AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=A.location_id
LEFT JOIN pointnin_afc.stand AS D ON D.stand_id=A.stand_id
LEFT JOIN pointnin_afc.users AS E ON E.user_id=A.user_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_SLAB` (IN `p_id` INT(2))  BEGIN
SELECT 
A.id,
A.type,
A.name,
A.description,
A.start_time,
A.end_time,
A.status,
A.trash,
A.createdon,
A.modifiedon
FROM pointnin_afc.slab AS A
WHERE A.id=p_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_SLABS` (IN `p_status` TINYINT(2))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery = CONCAT("");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.id,
A.type,
A.name,
A.description,
A.start_time,
A.end_time,
A.status,
A.trash,
A.createdon,
A.modifiedon
FROM pointnin_afc.slab AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.name ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_SPECIAL_REQUESTS` (IN `p_status` TINYINT(2), IN `p_type` TINYINT(2), IN `p_fromdate` DATETIME, IN `p_todate` DATETIME)  BEGIN

IF p_status IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.user_id !=0");
ELSE
	SET @where1 = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

IF p_type IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
	SET @where2 = CONCAT(" AND A.type='",p_type,"'");
END IF;

IF p_fromdate IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
    SET @where3 = CONCAT(" AND A.createdon >='",p_fromdate,"' AND A.createdon <='",p_todate,"'");    
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @SQLQuery = "
SELECT 
A.id,
A.type,
A.user_id,
A.route_id,
(SELECT M.name FROM pointnin_afc.route as M WHERE M.route_id=A.route_id) as route_name,
A.company_id,
A.location_id,
A.stand_id,
A.notes,
A.status,
A.createdon,
B.name as company_name,
C.location_name,
D.name as stand_name,
D.barcode,
E.firstname,
E.lastname,
E.timezone
FROM pointnin_afc.special_request AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=A.location_id
LEFT JOIN pointnin_afc.stand AS D ON D.stand_id=A.stand_id
LEFT JOIN pointnin_afc.users AS E ON E.user_id=A.user_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_STAND` (IN `p_stand_id` INT(11))  BEGIN

SELECT
A.stand_id,
(SELECT COUNT(S.stand_id) FROM pointnin_afc.user_routes as S WHERE S.stand_id=A.stand_id AND S.status=1) as usage_count,
A.name,
A.code,
A.barcode,
A.stand_type_id,
A.from_warehouse_id,
A.to_warehouse_id,
A.company_id,
A.location_id,
A.route_id,
A.service_notes,
A.placedon,
A.removedon,
A.status,
A.createdby,
A.createdon,
A.modifiedon
FROM pointnin_afc.stand AS A
WHERE A.stand_id=p_stand_id;

END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_STANDS` (IN `p_status` TINYINT(2), IN `p_route_id` INT(11), IN `p_search` VARCHAR(250), IN `p_limit_from` INT(11), IN `p_limit_to` INT(11))  BEGIN

SET @d_limit_from = p_limit_from;
SET @d_limit_to = p_limit_to;

IF p_status IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.stand_id IS NOT NULL");
ELSE
	SET @where1 = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

IF p_route_id IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
	SET @where2 = CONCAT(" AND A.route_id='",p_route_id,"'");
END IF;

IF p_search IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
	SET @where3 = CONCAT(" AND (A.barcode LIKE '",p_search,"' OR B.name LIKE '",p_search,"' OR C.location_name LIKE '",p_search,"')");
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @SQLQuery = "
SELECT
A.stand_id,
(SELECT COUNT(S.stand_id) FROM pointnin_afc.user_routes as S WHERE S.stand_id=A.stand_id AND S.status=1) as usage_count,
A.name,
A.barcode,
(SELECT J.capacity FROM pointnin_afc.stand_type as J WHERE J.stand_type_id=A.stand_type_id) as capacity,
A.company_id,
A.location_id,
A.service_notes,
A.placedon,
A.removedon,
A.usage_status,
A.fulfil_status,
A.status,
A.createdon,
B.name as company_name,
C.location_name,
D.name as route_name
FROM pointnin_afc.stand AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=A.location_id
LEFT JOIN pointnin_afc.route AS D ON D.route_id=A.route_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC LIMIT ?, ?');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE STMT USING @d_limit_from, @d_limit_to;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_STANDS_BY_ROUTE` (IN `p_status` TINYINT(2), IN `p_route_id` INT(11))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery = CONCAT(" WHERE A.status='",p_status,"' AND A.usage_status=0 AND A.route_id='",p_route_id,"'");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.usage_status=0 AND A.route_id='",p_route_id,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.stand_id,
A.route_id,
A.location_id,
A.company_id,
A.name as stand_name,
A.barcode,
A.usage_status,
A.position,
B.name as company_name,
C.location_name
FROM pointnin_afc.stand AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=A.location_id";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.position ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_STANDS_BY_SEARCH` (IN `p_status` TINYINT(2), IN `p_keyword` VARCHAR(100))  BEGIN

SET @whereQuery = CONCAT(" WHERE (A.name LIKE '",p_keyword,"' || A.barcode LIKE '",p_keyword,"') AND A.status='",p_status,"' AND A.usage_status=0");

SET @SQLQuery = "
SELECT 
A.stand_id,
A.route_id,
(SELECT H.name FROM pointnin_afc.route as H WHERE H.route_id=A.route_id) as route_name,
A.location_id,
A.company_id,
A.name as stand_name,
A.barcode,
A.usage_status,
B.name as company_name,
C.location_name
FROM pointnin_afc.stand AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=A.location_id";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.name ASC LIMIT 100');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_STANDS_BY_SEARCH_ONLY` (IN `p_keyword` VARCHAR(100))  BEGIN

SET @whereQuery = CONCAT(" WHERE (A.name LIKE '",p_keyword,"' || A.barcode LIKE '",p_keyword,"')");

SET @SQLQuery = "
SELECT 
A.stand_id,
A.route_id,
(SELECT H.name FROM pointnin_afc.route as H WHERE H.route_id=A.route_id) as route_name,
A.location_id,
A.company_id,
A.name as stand_name,
A.barcode,
B.name as company_name,
C.location_name
FROM pointnin_afc.stand AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=A.location_id";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.name ASC LIMIT 100');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_STANDS_BY_STAND` (IN `p_status` TINYINT(2), IN `p_stand_id` INT(11))  BEGIN

SET @whereQuery = CONCAT(" WHERE A.status='",p_status,"' AND A.usage_status=0 AND A.stand_id='",p_stand_id,"'");

SET @SQLQuery = "
SELECT 
A.stand_id,
A.route_id,
(SELECT H.name FROM pointnin_afc.route as H WHERE H.route_id=A.route_id) as route_name,
A.location_id,
A.company_id,
A.name as stand_name,
A.barcode,
A.usage_status,
A.status,
A.position,
B.name as company_name,
C.location_name
FROM pointnin_afc.stand AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=A.location_id";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,'');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_STANDS_REQUESTS` (IN `p_status` TINYINT(2), IN `p_type` TINYINT(2), IN `p_fromdate` DATETIME, IN `p_todate` DATETIME)  BEGIN

IF p_status IS NULL THEN
    SET @where1 = CONCAT(" WHERE 1");
ELSE
	SET @where1 = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

IF p_type IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
	SET @where2 = CONCAT(" AND A.type='",p_type,"'");
END IF;

IF p_fromdate IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
    SET @where3 = CONCAT(" AND A.createdon >='",p_fromdate,"' AND A.createdon <='",p_todate,"'");    
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @SQLQuery = "
SELECT 
A.us_id,
A.type,
A.user_id,
A.status,
A.createdon,
B.usd_id,
B.stand_type,
C.firstname,
C.lastname,
C.timezone,
D.name AS stand_type_name,
E.barcode
FROM pointnin_afc.user_stands AS A
LEFT JOIN pointnin_afc.user_stands_details AS B ON B.us_id=A.us_id
LEFT JOIN pointnin_afc.users AS C ON C.user_id=A.user_id
LEFT JOIN pointnin_afc.stand_type AS D ON D.stand_type_id=B.stand_type
LEFT JOIN pointnin_afc.stand AS E ON E.stand_id=B.stand_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_STANDS_ROWS` (IN `p_status` TINYINT(2), IN `p_route_id` INT(11), IN `p_search` VARCHAR(250))  BEGIN

IF p_status IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.stand_id IS NOT NULL");
ELSE
	SET @where1 = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

IF p_route_id IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
	SET @where2 = CONCAT(" AND A.route_id='",p_route_id,"'");
END IF;

IF p_search IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
	SET @where3 = CONCAT(" AND (A.barcode LIKE '",p_search,"' OR B.name LIKE '",p_search,"' OR C.location_name LIKE '",p_search,"')");
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @SQLQuery = "
SELECT
A.stand_id
FROM pointnin_afc.stand AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=A.location_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,'');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_STANDTYPE` (IN `p_id` INT(11))  BEGIN

SELECT 
A.stand_type_id,
A.name,
A.description,
A.capacity,
A.status
FROM pointnin_afc.stand_type AS A
WHERE A.stand_type_id=p_id;

END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_STANDTYPES` (IN `p_status` TINYINT(2))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery = CONCAT("");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.stand_type_id,
A.name,
A.description,
A.capacity,
A.status,
A.trash,
A.createdon,
A.modifiedon
FROM pointnin_afc.stand_type AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_STAND_PRODUCTS_STOCKS` (IN `p_stand_id` INT(11))  BEGIN
SELECT
A.id,
A.stand_id,
A.product_id,
A.attribute_value_id,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title,
(SELECT M.barcode FROM pointnin_afc.product_price as M WHERE M.product_id=A.product_id AND M.attribute_value_id=A.attribute_value_id) as barcode,
A.qty,
B.product_name
FROM pointnin_afc.stand_products_stock AS A
LEFT JOIN pointnin_afc.product AS B ON B.product_id=A.product_id
WHERE A.stand_id=p_stand_id AND A.status=1 AND A.qty>0;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_STOCKS` (IN `p_status` TINYINT(2), IN `p_warehouse_id` INT(11))  BEGIN

IF p_warehouse_id IS NULL THEN
    SET @where = CONCAT(" WHERE A.warehouse_id!=0");
ELSE
	SET @where = CONCAT(" WHERE A.warehouse_id='",p_warehouse_id,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.warehouse_id,
A.product_id,
A.attribute_value_id,
A.qty,
B.name as warehouse_name,
C.product_name,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title,
(SELECT M.barcode FROM pointnin_afc.product_price as M WHERE M.product_id=A.product_id AND M.attribute_value_id=A.attribute_value_id) as barcode
FROM pointnin_afc.warehouse_products_stock AS A
LEFT JOIN pointnin_afc.warehouse AS B ON B.warehouse_id=A.warehouse_id
LEFT JOIN pointnin_afc.product AS C ON C.product_id=A.product_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY B.name ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_STOCKS_BY_STAND` (IN `p_status` TINYINT(2), IN `p_stand_id` INT(11))  BEGIN

IF p_stand_id IS NULL THEN
    SET @where = CONCAT(" WHERE A.stand_id IS NOT NULL");
ELSE
	SET @where = CONCAT(" WHERE A.stand_id='",p_stand_id,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.product_id,
A.attribute_value_id,
SUM(A.qty) as qty,
B.product_name,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title,
(SELECT M.barcode FROM pointnin_afc.product_price as M WHERE M.product_id=A.product_id AND M.attribute_value_id=A.attribute_value_id) as barcode
FROM pointnin_afc.stand_products_stock AS A
LEFT JOIN pointnin_afc.product AS B ON B.product_id=A.product_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' GROUP BY A.product_id, A.attribute_value_id ORDER BY B.product_name ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_STOCKS_BY_USER` (IN `p_status` TINYINT(2), IN `p_user_id` INT(11))  BEGIN

IF p_user_id IS NULL THEN
    SET @where = CONCAT(" WHERE A.user_id IS NOT NULL");
ELSE
	SET @where = CONCAT(" WHERE A.user_id='",p_user_id,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.user_id,
A.product_id,
A.attribute_value_id,
A.qty,
B.firstname,
B.lastname,
C.product_name,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title,
(SELECT M.barcode FROM pointnin_afc.product_price as M WHERE M.product_id=A.product_id AND M.attribute_value_id=A.attribute_value_id) as barcode
FROM pointnin_afc.user_products_stock AS A
LEFT JOIN pointnin_afc.users AS B ON B.user_id=A.user_id
LEFT JOIN pointnin_afc.product AS C ON C.product_id=A.product_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY B.firstname ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_STOCK_TRANSFERS` (IN `p_status` TINYINT(2))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery = CONCAT("");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT
A.stock_transfer_id,
A.code,
A.units,
A.transfer_date,
A.description,
A.status,
A.createdon,
A.modifiedon,
B.product_name,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title
FROM pointnin_afc.stock_transfer AS A
LEFT JOIN pointnin_afc.product AS B ON B.product_id=A.product_id";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_SUPPLIER` (IN `p_id` INT(11))  BEGIN

SELECT 
A.supplier_id,
A.name,
A.phone,
A.email,
A.address,
A.location_id,
A.description,
A.status
FROM pointnin_afc.supplier AS A
WHERE A.supplier_id=p_id;

END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_SUPPLIERS` (IN `p_status` TINYINT(2))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery = CONCAT("");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.supplier_id,
A.name,
A.phone,
A.email,
A.address,
A.location_id,
A.description,
A.status,
B.location_name
FROM pointnin_afc.supplier AS A
LEFT JOIN pointnin_afc.location AS B ON B.location_id=A.location_id";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_SUPPLIERS_ONLY` (IN `p_status` TINYINT(2))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery = CONCAT("");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.supplier_id,
A.name
FROM pointnin_afc.supplier AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.name ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_TIMEZONE` (IN `p_status` TINYINT(2))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery = CONCAT("");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.zone_id,
A.iso,
A.zone_name,
A.status
FROM pointnin_afc.zone AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.zone_name ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_USER` (IN `p_user_id` INT(11))  BEGIN
SELECT 
A.user_id,
A.warehouse_id,
A.route_id,
A.username,
A.password,
A.empcode,
A.email,
A.mobile,
A.firstname,
A.lastname,
A.status,
A.device,
A.role,
A.registered_type,
A.profile_image,
A.profile_image_type,
A.wh_distance,
A.veh_id,
A.wage_km,
A.wage_hour,
A.wage_per_stand,
A.wage_new_stand,
A.commission,
A.imei,
A.gcmkey,
A.version_update,
A.lastaccess,
A.slab_id
FROM pointnin_afc.users AS A
WHERE A.user_id=p_user_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_USERS` (IN `p_status` TINYINT(2), IN `p_role` TINYINT(2), IN `p_warehouse_id` INT(11))  BEGIN

IF p_role IS NULL THEN
    SET @whereQuery1 = CONCAT(" WHERE A.user_id!=0");
ELSE
    SET @whereQuery1 = CONCAT(" WHERE A.role='",p_role,"'");
END IF;

IF p_status IS NULL THEN
    SET @whereQuery2 = CONCAT("");
ELSE
	SET @whereQuery2 = CONCAT(" AND A.status='",p_status,"'");
END IF;

IF p_warehouse_id IS NULL THEN
    SET @whereQuery3 = CONCAT("");
ELSE
    SET @whereQuery3 = CONCAT(" AND A.warehouse_id='",p_warehouse_id,"'");
END IF;

SET @whereQuery = CONCAT(@whereQuery1,@whereQuery2);
SET @whereQuery = CONCAT(@whereQuery,@whereQuery3);

SET @SQLQuery = "
SELECT 
A.user_id,
A.warehouse_id,
(SELECT L.name FROM pointnin_afc.warehouse as L WHERE L.warehouse_id=A.warehouse_id) as warehouse_name,
A.route_id,
(SELECT M.name FROM pointnin_afc.route as M WHERE M.route_id=A.route_id) as route_name,
A.username,
A.email,
A.mobile,
A.firstname,
A.lastname,
A.role,
A.status,
A.role,
A.registered_type,
A.profile_image,
A.profile_image_type,
A.imei,
A.gcmkey,
A.lastaccess,
A.version,
A.version_update
FROM pointnin_afc.users AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_USERS_BY_ROLE` (IN `p_status` TINYINT(2), IN `p_role` TINYINT(2), IN `p_warehouse_id` INT(11))  BEGIN
SELECT 
A.user_id,
A.firstname,
A.lastname,
A.role
FROM pointnin_afc.users AS A
WHERE A.warehouse_id=p_warehouse_id AND A.status=p_status AND A.role=p_role
ORDER BY A.firstname ASC;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_USERS_ONLY` (IN `p_status` TINYINT(2), IN `p_role` TINYINT(2))  BEGIN

IF p_role IS NULL THEN
    SET @whereQuery1 = CONCAT(" WHERE A.user_id!=0");
ELSE
    SET @whereQuery1 = CONCAT(" WHERE A.role='",p_role,"'");
END IF;

IF p_status IS NULL THEN
    SET @whereQuery2 = CONCAT("");
ELSE
	SET @whereQuery2 = CONCAT(" AND A.status='",p_status,"'");
END IF;

SET @whereQuery = CONCAT(@whereQuery1,@whereQuery2);

SET @SQLQuery = "
SELECT 
A.user_id,
A.firstname,
A.lastname,
A.role
FROM pointnin_afc.users AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.firstname ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_USER_ACTIVITIES` (IN `p_status` TINYINT(2), IN `p_user_id` INT(11), IN `p_fromdate` DATE, IN `p_todate` DATE)  BEGIN

SET @d_fromdate = p_fromdate;
SET @d_todate = p_todate;

IF p_status IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.activity_id!=0");
ELSE
	SET @where1 = CONCAT(" WHERE A.status='",p_status,"' AND B.status='",p_status,"'");
END IF;

IF p_user_id IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
    SET @where2 = CONCAT(" AND A.user_id='",p_user_id,"'");
END IF;

IF p_fromdate IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
    SET @where3 = CONCAT(" AND A.service_date >='",p_fromdate,"' AND A.service_date <='",p_todate,"'");    
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @SQLQuery = "
SELECT 
A.activity_id,
A.user_id,
A.service_date,
A.start_time,
A.end_time,
A.startkmtime,
(SELECT COUNT(L.id) FROM pointnin_afc.user_stands_service as L WHERE L.user_id=A.user_id AND L.service_date=A.service_date) as total_stand,
(SELECT SUM(TIME_TO_SEC(M.duration)) FROM pointnin_afc.sale as M WHERE M.user_id=A.user_id AND (M.service_date>=@d_fromdate AND M.service_date<=@d_todate)) as total_duration,
A.duration,
A.totalworkhours,
A.totalkm,
A.startkm,
A.endkm,
A.breakhours,
A.new_stand,
A.remove_stand,
A.checkout,
A.checkin_visited,
B.firstname,
B.lastname,
B.role,
B.timezone
FROM pointnin_afc.activity AS A
LEFT JOIN pointnin_afc.users AS B ON B.user_id=A.user_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_USER_CATEGORY` (IN `p_status` TINYINT(2), IN `p_warehouse_id` INT(11), IN `p_user_id` INT(11))  BEGIN
SELECT 
B.category_id,
B.category_name,
(SELECT COUNT(PR.product_id) FROM pointnin_afc.product AS PR LEFT JOIN pointnin_afc.product_price AS PP ON PP.product_id=PR.product_id WHERE PR.category_id=B.category_id AND PR.status=1 GROUP BY PR.category_id) as totalproducts
FROM pointnin_afc.users_category AS A
INNER JOIN pointnin_afc.category AS B ON B.category_id=A.category_id
WHERE A.warehouse_id=p_warehouse_id AND A.user_id=p_user_id AND B.status=p_status
ORDER BY B.category_name ASC;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_USER_DETAILS` (IN `p_user_id` INT(11))  BEGIN
SELECT
A.user_id,
A.warehouse_id,
(SELECT S.company_name FROM pointnin_afc.warehouse as S WHERE S.warehouse_id=A.warehouse_id) as company_name,
A.username,
A.email,
A.mobile,
A.firstname,
A.lastname,
A.brand_id,
(SELECT S.brand_name FROM pointnin_afc.brand as S WHERE S.brand_id=A.brand_id) as brand_name,
A.role,
A.fsm_user_id,
(SELECT S.firstname FROM pointnin_afc.users as S WHERE S.user_id=A.fsm_user_id) as fsm_name,
A.country_id,
A.city_id,
(SELECT S.city_name FROM pointnin_afc.city as S WHERE S.city_id=A.city_id) as city_name,
A.location_id,
(SELECT S.location_name FROM pointnin_afc.location as S WHERE S.location_id=A.location_id) as location_name,
A.retailer_id,
(SELECT S.retailer_name FROM pointnin_afc.retailer as S WHERE S.retailer_id=A.retailer_id) as retailer_name,
A.profile_image,
A.profile_image_type,
B.name as country_name,
B.currency_code,
B.currency_symbol,
B.zone_name
FROM pointnin_afc.users AS A
LEFT JOIN pointnin_afc.country AS B ON B.country_id=A.country_id
WHERE A.user_id=p_user_id AND A.status=1 LIMIT 1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_USER_STANDS_ROUTE` (IN `p_status` TINYINT(2), IN `p_user_id` INT(11), IN `p_route_id` INT(11))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery = CONCAT(" WHERE A.user_id='",p_user_id,"' AND A.route_id='",p_route_id,"' AND B.status=1");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.user_id='",p_user_id,"' AND A.route_id='",p_route_id,"' AND A.status='",p_status,"' AND B.status=1");
END IF;

SET @SQLQuery = "
SELECT 
A.user_routes_id,
A.user_id,
A.stand_id,
A.route_id,
A.location_id,
A.company_id,
A.status,
A.position,
B.name as stand_name,
B.barcode,
B.status as stand_staus,
B.usage_status,
B.serviced_date,
B.serviced_every,
C.name as company_name,
D.location_name
FROM pointnin_afc.user_routes AS A
LEFT JOIN pointnin_afc.stand AS B ON B.stand_id=A.stand_id
LEFT JOIN pointnin_afc.company AS C ON C.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS D ON D.location_id=A.location_id";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.position ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_USER_STANDS_ROUTES` (IN `p_status` TINYINT(2), IN `p_user_id` INT(11))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery = CONCAT(" WHERE A.user_id='",p_user_id,"' AND B.status=1");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.user_id='",p_user_id,"' AND A.status='",p_status,"' AND B.status=1");
END IF;

SET @SQLQuery = "
SELECT 
A.user_routes_id,
A.user_id,
A.stand_id,
A.route_id,
(SELECT H.name FROM pointnin_afc.route as H WHERE H.route_id=A.route_id) as route_name,
A.location_id,
A.company_id,
A.status,
A.position,
B.name as stand_name,
B.barcode,
B.status as stand_staus,
B.usage_status,
B.serviced_date,
B.serviced_every,
C.name as company_name,
D.location_name
FROM pointnin_afc.user_routes AS A
LEFT JOIN pointnin_afc.stand AS B ON B.stand_id=A.stand_id
LEFT JOIN pointnin_afc.company AS C ON C.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS D ON D.location_id=A.location_id";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.position ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_VEHICLE` (IN `p_id` INT(11))  BEGIN

SELECT 
A.vehicle_id,
A.name,
A.user_id,
A.type,
A.capacity,
A.usage_status,
A.status,
A.trash,
A.createdon,
A.modifiedon
FROM pointnin_afc.vehicle AS A
WHERE A.vehicle_id=p_id;

END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_VEHICLES` (IN `p_status` TINYINT(2))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery = CONCAT("");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.vehicle_id,
A.name,
A.user_id,
A.type,
A.capacity,
A.usage_status,
A.status,
B.firstname,
B.lastname
FROM pointnin_afc.vehicle AS A
LEFT JOIN pointnin_afc.users AS B ON B.user_id=A.user_id";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_WAGES` (IN `p_status` TINYINT(2), IN `p_role` TINYINT(2), IN `p_warehouse_id` INT(11), IN `p_fromdate` DATE, IN `p_todate` DATE)  BEGIN

SET @d_fromdate = p_fromdate;
SET @d_todate = p_todate;

IF p_status IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.user_id!=0");
ELSE
	SET @where1 = CONCAT(" WHERE B.status='",p_status,"'");
END IF;

IF p_warehouse_id IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
    SET @where2 = CONCAT(" AND B.warehouse_id='",p_warehouse_id,"'");
END IF;

IF p_fromdate IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
    SET @where3 = CONCAT(" AND A.service_date >='",p_fromdate,"' AND A.service_date <='",p_todate,"'");    
END IF;

IF p_role IS NULL THEN
    SET @where4 = CONCAT("");
ELSE
	SET @where4 = CONCAT(" AND B.role='",p_role,"'");
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);
SET @where = CONCAT(@where,@where4);

SET @SQLQuery = "
SELECT 
A.user_id,
(SELECT K.wage_km FROM pointnin_afc.users as K WHERE K.user_id=A.user_id) as wage_km,
(SELECT COUNT(L.id) FROM pointnin_afc.user_stands_service as L WHERE L.user_id=A.user_id AND (L.service_date>=@d_fromdate AND L.service_date<=@d_todate)) as total_stand,
(SELECT SUM(M.amount) FROM pointnin_afc.user_expenses as M WHERE M.user_id=A.user_id AND (M.service_date>=@d_fromdate AND M.service_date<=@d_todate)) as total_amount,
(SELECT SUM(N.sale_amount) FROM pointnin_afc.receipt as N WHERE N.user_id=A.user_id AND (N.service_date>=@d_fromdate AND N.service_date<=@d_todate)) as sale_amount,
(SELECT (SUM(O.order_amount) - SUM(O.return_amount)) FROM pointnin_afc.receipt as O WHERE O.user_id=A.user_id AND (O.service_date>=@d_fromdate AND O.service_date<=@d_todate)) as order_amount,
(SELECT P.name FROM pointnin_afc.warehouse as P WHERE P.warehouse_id=B.warehouse_id) as warehouse_name,
(SELECT Q.name FROM pointnin_afc.route as Q WHERE Q.route_id=B.route_id) as route_name,
(SELECT SUM(R.total_amount) FROM pointnin_afc.collection as R WHERE R.user_id=A.user_id AND (R.service_date>=@d_fromdate AND R.service_date<=@d_todate)) as deposit_amount,
B.firstname,
B.lastname,
B.role,
SUM(A.totalkm) as totalkm,
SUM(A.remove_stand) as remove_stand,
SUM(A.new_stand) as new_stand,
SUM(TIME_TO_SEC(A.totalworkhours)) as totalworkhours,
SUM(TIME_TO_SEC(A.breakhours)) as breakhours,
SUM(TIME_TO_SEC(A.duration)) as duration
FROM pointnin_afc.activity AS A
LEFT JOIN pointnin_afc.users AS B ON B.user_id=A.user_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' GROUP BY A.user_id ORDER BY B.firstname ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_WAGES_COMPARISION` (IN `p_status` TINYINT(2), IN `p_warehouse_id` INT(11), IN `p_fromdate` DATE, IN `p_todate` DATE)  BEGIN

SET @d_fromdate = p_fromdate;
SET @d_todate = p_todate;

IF p_status IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.endkm!=0");
ELSE
	SET @where1 = CONCAT(" WHERE A.endkm!=0 AND B.status='",p_status,"'");
END IF;

IF p_warehouse_id IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
    SET @where2 = CONCAT(" AND B.warehouse_id='",p_warehouse_id,"'");
END IF;

IF p_fromdate IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
    SET @where3 = CONCAT(" AND A.service_date >='",p_fromdate,"' AND A.service_date <='",p_todate,"'");    
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @SQLQuery = "
SELECT 
A.user_id,
(SELECT SUM(TIME_TO_SEC(M.duration)) FROM pointnin_afc.sale as M WHERE M.user_id=A.user_id AND (M.service_date>=@d_fromdate AND M.service_date<=@d_todate)) as total_duration,
(SELECT L.name FROM pointnin_afc.warehouse as L WHERE L.warehouse_id=B.warehouse_id) as warehouse_name,
(SELECT M.name FROM pointnin_afc.route as M WHERE M.route_id=B.route_id) as route_name,
B.firstname,
B.lastname,
SUM(A.totalkm) as totalkm,
SUM(A.startkm) as startkm,
SUM(A.endkm) as endkm,
SUM(TIME_TO_SEC(A.totalworkhours)) as totalworkhours
FROM pointnin_afc.activity AS A
LEFT JOIN pointnin_afc.users AS B ON B.user_id=A.user_id";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' GROUP BY A.user_id ORDER BY B.firstname ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_WAREHOUSE` (IN `p_warehouse_id` INT(11))  BEGIN
SELECT 
A.warehouse_id,
A.name,
A.barcode,
A.description,
A.location_id,
A.status,
A.trash,
A.createdon,
A.modifiedon
FROM pointnin_afc.warehouse AS A
WHERE A.warehouse_id=p_warehouse_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_WAREHOUSES` (IN `p_status` TINYINT(2))  BEGIN

IF p_status IS NULL THEN
    SET @whereQuery = CONCAT("");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.warehouse_id,
A.name,
A.barcode,
A.description,
A.location_id,
(SELECT L.location_name FROM pointnin_afc.location as L WHERE L.location_id=A.location_id) as location_name,
A.status,
A.trash,
A.createdon,
A.modifiedon
FROM pointnin_afc.warehouse AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_WAREHOUSES_ONLY` (IN `p_status` TINYINT(2))  BEGIN

SELECT 
A.warehouse_id,
A.name
FROM pointnin_afc.warehouse AS A
WHERE A.status=p_status
ORDER BY A.name ASC;

END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_WAREHOUSE_PRODUCT_STOCKS` (IN `p_status` TINYINT(2), IN `p_product_id` INT(11), IN `p_attribute_value_id` INT(11))  BEGIN

SELECT
SUM(A.qty) AS stocks, 
A.warehouse_id,
B.name
FROM pointnin_afc.warehouse_products_stock AS A
LEFT JOIN pointnin_afc.warehouse AS B ON B.warehouse_id=A.warehouse_id
WHERE B.status=p_status AND A.product_id=p_product_id AND A.attribute_value_id=p_attribute_value_id
GROUP BY A.warehouse_id, A.product_id, A.attribute_value_id
ORDER BY B.name ASC;

END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `GET_WAREHOUSE_PRODUCT_STOCKS_VALIDATE` (IN `p_warehouse_id` INT(11), IN `p_product_id` INT(11), IN `p_attribute_value_id` INT(11))  BEGIN

SELECT
A.qty AS stocks, 
A.warehouse_id,
B.name
FROM pointnin_afc.warehouse_products_stock AS A
LEFT JOIN pointnin_afc.warehouse AS B ON B.warehouse_id=A.warehouse_id
WHERE A.warehouse_id=p_warehouse_id AND A.product_id=p_product_id AND A.attribute_value_id=p_attribute_value_id;

END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_ACTIVITIES` (IN `p_type` TINYINT(2), IN `p_user_id` INT(11), IN `p_code` INT(11), IN `p_notes` VARCHAR(255), OUT `p_id` INT(11))  BEGIN
	INSERT INTO pointnin_afc.activities
	(type,
	user_id,
	code,
	notes,
	service_date,
	status,
	createdby,
	modifiedby,
	createdon,
	modifiedon)
	VALUES
	(p_type,
	p_user_id,
	p_code,
	p_notes,
	NOW(),
	1,
	p_user_id,
	p_user_id,
	NOW(),
	NOW());
	SELECT LAST_INSERT_ID() INTO p_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_ACTIVITY` (IN `p_type` TINYINT(2), IN `p_user_id` INT(11), IN `p_service_date` DATE, IN `p_totalworkhours` TIME, IN `p_totalkm` DOUBLE, IN `p_startkm` DOUBLE, IN `p_endkm` DOUBLE, IN `p_breakhours` TIME, IN `p_vehicle_id` INT(11), IN `p_checkout` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE d_startkmtime DATETIME;
IF p_type=2 THEN
	SET d_startkmtime = NOW();
ELSE
	SET d_startkmtime = NULL;
END IF;
SELECT COUNT(activity_id) INTO IsFound FROM pointnin_afc.activity WHERE user_id=p_user_id AND service_date=p_service_date;
IF IsFound=0 THEN
	INSERT INTO pointnin_afc.activity
	(user_id,
	service_date,
	totalworkhours,
	totalkm,
	startkm,
	endkm,
	breakhours,
	vehicle_id,
	startkmtime,
	status,
	checkout,
	createdby,
	modifiedby,
	createdon,
	modifiedon)
	VALUES
	(p_user_id,
	p_service_date,
	p_totalworkhours,
	p_totalkm,
	p_startkm,
	p_endkm,
	p_breakhours,
	p_vehicle_id,
	d_startkmtime,
	1,
	p_checkout,
	p_user_id,
	p_user_id,
	NOW(),
	NOW());
	SELECT LAST_INSERT_ID() INTO p_id;
ELSE
	IF p_type=1 THEN
		UPDATE pointnin_afc.activity
		SET
		totalworkhours=p_totalworkhours,
		totalkm=p_totalkm,
		breakhours=p_breakhours,
		vehicle_id=p_vehicle_id,
		endkm=p_endkm,
		checkout=p_checkout
		WHERE user_id=p_user_id AND service_date=p_service_date;
	ELSE
		UPDATE pointnin_afc.activity
		SET
		startkm=p_startkm,
		vehicle_id=p_vehicle_id,
		startkmtime=NOW()
		WHERE user_id=p_user_id AND service_date=p_service_date;
	END IF;		
	SELECT 1 INTO p_id;
END IF;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_ACTIVITY_CHECKIN` (IN `p_user_id` INT(11), IN `p_service_date` DATE, OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);

SELECT COUNT(activity_id) INTO IsFound FROM pointnin_afc.activity WHERE user_id=p_user_id AND service_date=p_service_date;
IF IsFound=0 THEN
	INSERT INTO pointnin_afc.activity
	(user_id,
	service_date,
	status,
	checkin,
	checkin_visited,
	createdby,
	modifiedby,
	createdon,
	modifiedon)
	VALUES
	(p_user_id,
	p_service_date,
	1,
	1,
	NOW(),
	p_user_id,
	p_user_id,
	NOW(),
	NOW());
ELSE
	UPDATE pointnin_afc.activity
	SET
	checkin=1,
	checkin_visited=NOW(),
	modifiedon=NOW()
	WHERE user_id=p_user_id AND service_date=p_service_date AND checkin=0;
END IF;	
SELECT 1 INTO p_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_ACTIVITY_TIME` (IN `p_type` TINYINT(2), IN `p_user_id` INT(11), IN `p_service_date` DATE, OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE IsFound1 INT(1);
DECLARE i_time TIME;

SELECT COUNT(activity_id) INTO IsFound FROM pointnin_afc.activity WHERE user_id=p_user_id AND service_date=p_service_date;
IF IsFound=0 THEN
	INSERT INTO pointnin_afc.activity
	(user_id,
	service_date,
	start_time,
	status,
	createdby,
	modifiedby,
	createdon,
	modifiedon)
	VALUES
	(p_user_id,
	p_service_date,
	NOW(),
	1,
	p_user_id,
	p_user_id,
	NOW(),
	NOW());
END IF;	

IF p_type=1 THEN
	SELECT COUNT(activity_id) INTO IsFound1 FROM pointnin_afc.activity WHERE user_id=p_user_id AND service_date=p_service_date AND start_time IS NULL;
	IF IsFound1>0 THEN
		UPDATE pointnin_afc.activity
		SET
		start_time=NOW()
		WHERE user_id=p_user_id AND service_date=p_service_date;
		SELECT 1 INTO p_id;
	ELSE
		SELECT 0 INTO p_id;	
	END IF;
ELSE
	SELECT COUNT(activity_id), start_time INTO IsFound1, i_time FROM pointnin_afc.activity WHERE user_id=p_user_id AND service_date=p_service_date AND end_time IS NULL;
	IF IsFound1>0 THEN
		UPDATE pointnin_afc.activity
		SET
		end_time=NOW(),
		duration=SEC_TO_TIME(TIME_TO_SEC(NOW()) - TIME_TO_SEC(i_time))
		WHERE user_id=p_user_id AND service_date=p_service_date;
		SELECT 1 INTO p_id;
	ELSE
		SELECT 0 INTO p_id;	
	END IF;
END IF;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_COLLECTION` (IN `p_type` TINYINT(11), IN `p_user_id` INT(11), IN `p_sale_amount` DOUBLE, IN `p_total_amount` DOUBLE, IN `p_eftpos` DOUBLE, IN `p_eft` DOUBLE, IN `p_cheque` DOUBLE, IN `p_format1` DOUBLE, IN `p_format2` DOUBLE, IN `p_format3` DOUBLE, IN `p_format4` DOUBLE, IN `p_format5` DOUBLE, IN `p_format6` DOUBLE, IN `p_format7` DOUBLE, IN `p_branch_name` VARCHAR(155), IN `p_status` TINYINT(2), OUT `p_id` CHAR(36))  BEGIN
	DECLARE newUuid CHAR(36);
	SET newUuid = UUID();
	INSERT INTO pointnin_afc.collection
	(id,
	type,
	user_id,
	sale_amount,
	total_amount,
	eftpos,
	eft,
	cheque,
	format1,
	format2,
	format3,
	format4,
	format5,
	format6,
	format7,
	service_date,
	branch_name,
	status,
	createdby,
	modifiedby,
	createdon,
	modifiedon)
	VALUES
	(newUuid,
	p_type,
	p_user_id,
	p_sale_amount,
	p_total_amount,
	p_eftpos,
	p_eft,
	p_cheque,
	p_format1,
	p_format2,
	p_format3,
	p_format4,
	p_format5,
	p_format6,
	p_format7,
	NOW(),
	p_branch_name,
	p_status,
	p_user_id,
	p_user_id,
	NOW(),
	NOW());

	UPDATE pointnin_afc.receipt
	SET
	status=2,
	modifiedby=p_user_id,
	modifiedon=NOW()
	WHERE user_id=p_user_id;
	SELECT newUuid INTO p_id;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_COMPANY` (IN `p_name` VARCHAR(255), IN `p_location_name` VARCHAR(255), IN `p_address` VARCHAR(255), IN `p_route_id` INT(11), IN `p_country_id` INT(11), IN `p_city_id` INT(11), IN `p_phone` VARCHAR(15), IN `p_email` VARCHAR(150), IN `p_description` VARCHAR(255), IN `p_latitude` VARCHAR(15), IN `p_longitude` VARCHAR(15), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE IsFound1 INT(1);
DECLARE i_location_id INT(11);

SELECT COUNT(company_id) INTO IsFound FROM pointnin_afc.company WHERE name=p_name;
IF IsFound=0 THEN
  INSERT INTO pointnin_afc.company
  (name,
  phone,
  email,
  address,
  description,
  status,
  createdby,
  modifiedby,
  createdon,
  modifiedon
  )
  VALUES
  (p_name,
  p_phone,
  p_email,
  p_address,
  p_description,
  1,
  p_createdby,
  p_createdby,
  NOW(),
  NOW());
  SELECT LAST_INSERT_ID() INTO p_id;

  SELECT COUNT(location_id), location_id INTO IsFound1, i_location_id FROM pointnin_afc.location WHERE location_name=p_location_name AND country_id=p_country_id AND city_id=p_city_id;
  IF IsFound1=0 THEN
    INSERT INTO pointnin_afc.location
    (route_id,
    country_id,
    city_id,
    location_name,
    address,
    latitude,
    longitude,
    status,
    createdby,
    modifiedby,
    createdon,
    modifiedon)
    VALUES
    (p_route_id,
    p_country_id,
    p_city_id,
    p_location_name,
    p_address,
    p_latitude,
    p_longitude,
    1,
    p_createdby,
    p_createdby,
    NOW(),
    NOW());
    SELECT LAST_INSERT_ID() INTO i_location_id;
  END IF;  

  INSERT INTO pointnin_afc.company_location
  (company_id,
  location_id,
  route_id,
  createdby,
  createdon
  )
  VALUES
  (p_id,
  i_location_id,
  p_route_id,
  p_createdby,
  NOW());    
ELSE
  SELECT 0 INTO p_id;
END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_EXPENSES` (IN `p_user_id` INT(11), IN `p_company_id` INT(11), IN `p_location_id` INT(11), IN `p_amount` DOUBLE, IN `p_type` TINYINT(2), IN `p_service_date` DATE, OUT `p_id` CHAR(36))  BEGIN
	DECLARE IsFound INT(1);
	DECLARE i_id CHAR(36);
  DECLARE newUuid CHAR(36);
  SELECT COUNT(S.id), S.id INTO IsFound, i_id FROM pointnin_afc.user_expenses AS S WHERE S.user_id=p_user_id AND S.company_id=p_company_id AND S.location_id=p_location_id AND S.service_date=p_service_date;
  IF IsFound=0 THEN
		SET newUuid = UUID();
		INSERT INTO pointnin_afc.user_expenses
		(id,
		user_id,
		company_id,
		location_id,
		amount,
		type,
		service_date,
		status,
		createdby,
		modifiedby,
		createdon,
		modifiedon)
		VALUES
		(newUuid,
		p_user_id,
		p_company_id,
		p_location_id,
		p_amount,
		p_type,
		p_service_date,
		1,
		p_user_id,
		p_user_id,
		NOW(),
		NOW());
		SELECT newUuid INTO p_id;
	ELSE
		UPDATE pointnin_afc.user_expenses
		SET
		amount=p_amount,
		type=p_type,
		modifiedon=NOW()
		WHERE id=i_id;
		SELECT 1 INTO p_id;
	END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_RECEIPT` (OUT `p_id` CHAR(36), OUT `p_order_amount` DOUBLE, IN `p_user_id` INT(11), IN `p_warehouse_id` INT(11), IN `p_route_id` INT(11), IN `p_company_id` INT(11), IN `p_location_id` INT(11), IN `p_stand_id` INT(11), IN `p_sale_amount` DOUBLE, IN `p_return_amount` DOUBLE, IN `p_status` TINYINT(2), IN `p_latitude` VARCHAR(15), IN `p_longitude` VARCHAR(15))  BEGIN
  DECLARE newUuid CHAR(36);
  DECLARE i_order_amount DOUBLE;
  SET newUuid = UUID();
  SELECT S.order_amount INTO i_order_amount FROM pointnin_afc.stand AS S WHERE S.stand_id=p_stand_id;
  INSERT INTO pointnin_afc.receipt
  (receipt_id,
  user_id,
  warehouse_id,
  route_id,
  company_id,
  location_id,
  stand_id,
  order_amount,
  sale_amount,
  return_amount,
  service_date,
  status,
  createdby,
  modifiedby,
  createdon,
  modifiedon)
  VALUES
  (newUuid,
  p_user_id,
  p_warehouse_id,
  p_route_id,
  p_company_id,
  p_location_id,
  p_stand_id,
  i_order_amount,
  p_sale_amount,
  p_return_amount,
  NOW(),
  p_status,
  p_user_id,
  p_user_id,
  NOW(),
  NOW());
  
	INSERT INTO pointnin_afc.user_stands_service
	(user_id,
	stand_id,
	company_id,
	location_id,
	service_date,
	status,
	createdon,
	modifiedon)
	VALUES
	(p_user_id,
	p_stand_id,
	p_company_id,
	p_location_id,
	NOW(),
	1,
	NOW(),
	NOW());
	
	IF EXISTS (SELECT S.location_id FROM pointnin_afc.location AS S WHERE S.location_id=p_location_id AND S.latitude IS NULL) THEN
		UPDATE pointnin_afc.location
		SET
		latitude=p_latitude,
		longitude=p_longitude,
		modifiedon=NOW()
		WHERE location_id=p_location_id;
	END IF;	
  
  SELECT newUuid, i_order_amount INTO p_id, p_order_amount;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_SALE` (IN `p_type` TINYINT(2), IN `p_user_id` INT(11), IN `p_warehouse_id` INT(11), IN `p_route_id` INT(11), IN `p_company_id` INT(11), IN `p_location_id` INT(11), IN `p_stand_id` INT(11), IN `p_chipboxes` INT(11), IN `p_duration` TIME, IN `p_status` TINYINT(2), OUT `p_id` CHAR(36))  BEGIN
	DECLARE newUuid CHAR(36);
	SET newUuid = UUID();
	INSERT INTO pointnin_afc.sale
	(sale_id,
	type,
	mode,
	user_id,
	warehouse_id,
	route_id,
	company_id,
	location_id,
	stand_id,
	chipboxes,
	total_qty,
	total_amount,
	service_date,
	duration,
	status,
	createdby,
	modifiedby,
	createdon,
	modifiedon)
	VALUES
	(newUuid,
	p_type,
	p_type,
	p_user_id,
	p_warehouse_id,
	p_route_id,
	p_company_id,
	p_location_id,
	p_stand_id,
	p_chipboxes,
	0,
	0,
	NOW(),
	p_duration,
	p_status,
	p_user_id,
	p_user_id,
	NOW(),
	NOW());
  
	UPDATE pointnin_afc.stand
	SET
	serviced_date=NOW(),
	modifiedby=p_user_id,
	modifiedon=NOW()
	WHERE stand_id=p_stand_id;
	
	UPDATE pointnin_afc.user_routes
	SET
	checked=2,
	modifiedby=p_user_id,
	modifiedon=NOW()
	WHERE user_id=p_user_id AND stand_id=p_stand_id;	
  
	IF p_type=2 THEN
	INSERT INTO pointnin_afc.user_stands_service
	(user_id,
	stand_id,
	company_id,
	location_id,
	service_date,
	status,
	createdon,
	modifiedon)
	VALUES
	(p_user_id,
	p_stand_id,
	p_company_id,
	p_location_id,
	NOW(),
	1,
	NOW(),
	NOW());
	END IF;

	SELECT newUuid INTO p_id;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_SALE_DETAILS` (IN `p_sale_id` CHAR(36), IN `p_type` TINYINT(2), IN `p_warehouse_id` INT(11), IN `p_user_id` INT(11), IN `p_route_id` INT(11), IN `p_company_id` INT(11), IN `p_location_id` INT(11), IN `p_stand_id` INT(11), IN `p_product_id` INT(11), IN `p_attribute_value_id` INT(11), IN `p_qty` INT(11), IN `p_price` DOUBLE, IN `p_price_total` DOUBLE, IN `p_status` TINYINT(2), OUT `p_id` CHAR(36))  BEGIN
  DECLARE newUuid CHAR(36);
  DECLARE newUuid1 CHAR(36);
  DECLARE IsFound INT(1);

  IF p_type=1 THEN
    SELECT COUNT(S.id) INTO IsFound FROM pointnin_afc.user_products_stock AS S WHERE S.user_id=p_user_id AND S.product_id=p_product_id AND S.attribute_value_id=p_attribute_value_id AND S.qty >= p_qty;
  ELSE
    SELECT COUNT(S.id) INTO IsFound FROM pointnin_afc.warehouse_products_stock AS S WHERE S.warehouse_id=p_warehouse_id AND S.product_id=p_product_id AND S.attribute_value_id=p_attribute_value_id AND S.qty >= p_qty;
  END IF;

  IF IsFound>0 THEN
    SET newUuid = UUID();
    INSERT INTO pointnin_afc.sale_items
    (sale_item_id,
    sale_id,
    user_id,
    product_id,
    attribute_value_id,
    qty,
    price,
    status,
    createdby,
    modifiedby,
    createdon,
    modifiedon)
    VALUES
    (newUuid,
    p_sale_id,
    p_user_id,
    p_product_id,
    p_attribute_value_id,
    p_qty,
    p_price,
    p_status,
    p_user_id,
    p_user_id,
    NOW(),
    NOW());

    IF NOT EXISTS (SELECT S.id FROM pointnin_afc.stand_products_stock  AS S WHERE S.stand_id=p_stand_id AND S.product_id=p_product_id AND S.attribute_value_id=p_attribute_value_id) THEN
      INSERT INTO pointnin_afc.stand_products_stock
      (stand_id,
      product_id,
      attribute_value_id,
      qty,
      status,
      createdby,
      modifiedby,
      createdon,
      modifiedon)
      VALUES
      (p_stand_id,
      p_product_id,
      p_attribute_value_id,
      p_qty,
      p_status,
      p_user_id,
      p_user_id,
      NOW(),
      NOW());
    ELSE
      UPDATE pointnin_afc.stand_products_stock
      SET
      qty=qty+p_qty,
      modifiedby=p_user_id,
      modifiedon=NOW()
      WHERE stand_id=p_stand_id AND product_id=p_product_id AND attribute_value_id=p_attribute_value_id;
    END IF;
    
    UPDATE pointnin_afc.sale AS T SET T.total_qty=T.total_qty+p_qty,T.total_amount=T.total_amount+p_price_total WHERE T.sale_id=p_sale_id;
    UPDATE pointnin_afc.stand AS U SET U.order_amount=U.order_amount+p_price_total WHERE U.stand_id=p_stand_id;

    IF p_type=1 THEN
      UPDATE pointnin_afc.user_products_stock AS V 
      SET V.qty=V.qty-p_qty 
      WHERE V.user_id=p_user_id AND V.product_id=p_product_id AND V.attribute_value_id=p_attribute_value_id;
    ELSE
      UPDATE pointnin_afc.warehouse_products_stock AS V 
      SET V.qty=V.qty-p_qty
      WHERE V.warehouse_id=p_warehouse_id AND V.product_id=p_product_id AND V.attribute_value_id=p_attribute_value_id;      
    END IF;
    SELECT newUuid INTO p_id;
  ELSE
    SET newUuid1 = UUID();
    INSERT INTO pointnin_afc.sale_items_failed
    (id,
    user_id,
    sale_id,
    route_id,
    company_id,
    location_id,
    stand_id,
    product_id,
    attribute_value_id,
    qty,
    price,
    servicedate,
    status,
    createdon)
    VALUES
    (newUuid1,
    p_user_id,
    p_sale_id,
    p_route_id,
    p_company_id,
    p_location_id,
    p_stand_id,
    p_product_id,
    p_attribute_value_id,
    p_qty,
    p_price,
    NOW(),
    p_status,
    NOW());
    SELECT 0 INTO p_id;
  END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_SALE_RESTOCK` (IN `p_user_id` INT(11), IN `p_warehouse_id` INT(11), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` CHAR(36))  BEGIN
  DECLARE newUuid CHAR(36);
  SET newUuid = UUID();
  INSERT INTO pointnin_afc.sale_restock
  (sr_id,
  user_id,
  warehouse_id,
  service_date,
  status,
  createdby,
  createdon)
  VALUES
  (newUuid,
  p_user_id,
  p_warehouse_id,
  NOW(),
  p_status,
  p_createdby,
  NOW());
  SELECT newUuid INTO p_id;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_SALE_RESTOCK_DETAILS` (IN `p_user_id` INT(11), IN `p_warehouse_id` INT(11), IN `p_sr_id` CHAR(36), IN `p_product_id` INT(11), IN `p_attribute_value_id` INT(11), IN `p_qty` INT(11), IN `p_adjust_qty` INT(11), IN `p_price` DOUBLE, IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` CHAR(36))  BEGIN
	DECLARE newUuid CHAR(36);
	SET newUuid = UUID();
	INSERT INTO pointnin_afc.sale_restock_items
	(sri_id,
	sr_id,
	product_id,
	attribute_value_id,
	qty,
	adjust_qty,
	price,
	status,
	createdby,
	createdon)
	VALUES
	(newUuid,
	p_sr_id,
	p_product_id,
	p_attribute_value_id,
	p_qty,
	p_adjust_qty,
	p_price,
	p_status,
	p_createdby,
	NOW());
	UPDATE pointnin_afc.sale_return_items SET return_status=2, modifiedby=p_createdby WHERE user_id=p_user_id AND product_id=p_product_id AND attribute_value_id=p_attribute_value_id AND return_status=1;
	
	IF p_adjust_qty>0 THEN
		UPDATE pointnin_afc.warehouse_products_stock
		SET
		qty=qty+p_adjust_qty,
		modifiedby=p_createdby,
		modifiedon=NOW()
		WHERE warehouse_id=p_warehouse_id AND product_id=p_product_id AND attribute_value_id=p_attribute_value_id;
	END IF;

    SELECT newUuid INTO p_id;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_SALE_RETURN` (IN `p_receipt_id` CHAR(36), IN `p_user_id` INT(11), IN `p_warehouse_id` INT(11), IN `p_route_id` INT(11), IN `p_company_id` INT(11), IN `p_location_id` INT(11), IN `p_stand_id` INT(11), IN `p_chipboxes` INT(11), IN `p_type` TINYINT(2), IN `p_status` TINYINT(2), OUT `p_id` CHAR(36))  BEGIN
  DECLARE newUuid CHAR(36);
  SET newUuid = UUID();
  INSERT INTO pointnin_afc.sale_return
  (sale_return_id,
  receipt_id,
  user_id,
  warehouse_id,
  route_id,
  company_id,
  location_id,
  stand_id,
  chipboxes,
  total_qty,
  total_amount,
  service_date,
  type,
  status,
  createdby,
  modifiedby,
  createdon,
  modifiedon)
  VALUES
  (newUuid,
  p_receipt_id,
  p_user_id,
  p_warehouse_id,
  p_route_id,
  p_company_id,
  p_location_id,
  p_stand_id,
  p_chipboxes,
  0,
  0,
  NOW(),
  p_type,
  p_status,
  p_user_id,
  p_user_id,
  NOW(),
  NOW());
  SELECT newUuid INTO p_id;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_SALE_RETURN_DETAILS` (IN `p_sale_return_id` CHAR(36), IN `p_user_id` INT(11), IN `p_route_id` INT(11), IN `p_company_id` INT(11), IN `p_location_id` INT(11), IN `p_stand_id` INT(11), IN `p_product_id` INT(11), IN `p_attribute_value_id` INT(11), IN `p_qty` INT(11), IN `p_price` DOUBLE, IN `p_price_total` DOUBLE, IN `p_type` TINYINT(2), IN `p_status` TINYINT(2), OUT `p_id` CHAR(36))  BEGIN
  DECLARE newUuid CHAR(36);
  DECLARE newUuid1 CHAR(36);
  DECLARE IsFound INT(1);
  SELECT COUNT(S.id) INTO IsFound FROM pointnin_afc.stand_products_stock AS S WHERE S.stand_id=p_stand_id AND S.product_id=p_product_id AND S.attribute_value_id=p_attribute_value_id AND S.qty >= p_qty;
  IF IsFound>0 THEN
    SET newUuid = UUID();
    INSERT INTO pointnin_afc.sale_return_items
    (sri_id,
    sale_return_id,
    user_id,
    company_id,
    product_id,
    attribute_value_id,
    qty,
    price,
    type,
    status,
    createdby,
    modifiedby,
    createdon,
    modifiedon)
    VALUES
    (newUuid,
    p_sale_return_id,
    p_user_id,
    p_company_id,
    p_product_id,
    p_attribute_value_id,
    p_qty,
    p_price,
    p_type,
    p_status,
    p_user_id,
    p_user_id,
    NOW(),
    NOW());
    
    UPDATE pointnin_afc.sale_return AS T SET T.total_qty=T.total_qty+p_qty,T.total_amount=T.total_amount+p_price_total WHERE T.sale_return_id=p_sale_return_id;
	
	IF p_type=1 THEN
		UPDATE pointnin_afc.user_products_stock
		SET
		qty=qty+p_qty,
		modifiedby=p_user_id,
		modifiedon=NOW()
		WHERE user_id=p_user_id AND product_id=p_product_id AND attribute_value_id=p_attribute_value_id;
	END IF;
	
    SELECT newUuid INTO p_id;
  ELSE
    SET newUuid1 = UUID();
    INSERT INTO pointnin_afc.sale_return_failed
    (id,
    user_id,
    sale_return_id,
    route_id,
    company_id,
    location_id,
    stand_id,
    product_id,
    attribute_value_id,
    qty,
    price,
    servicedate,
    type,
    status,
    createdon)
    VALUES
    (newUuid1,
    p_user_id,
    p_sale_return_id,
    p_route_id,
    p_company_id,
    p_location_id,
    p_stand_id,
    p_product_id,
    p_attribute_value_id,
    p_qty,
    p_price,
    NOW(),
    p_type,
    p_status,
    NOW());
    SELECT 0 INTO p_id;
  END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_SPECIAL_REQUEST` (IN `p_type` TINYINT(2), IN `p_user_id` INT(11), IN `p_route_id` INT(11), IN `p_company_id` INT(11), IN `p_location_id` INT(11), IN `p_stand_id` INT(11), IN `p_notes` VARCHAR(255), IN `p_status` TINYINT(2), OUT `p_id` INT(11))  BEGIN
    INSERT INTO pointnin_afc.special_request
    (type,
    user_id,
    route_id,
    company_id,
    location_id,
	stand_id,
    notes,
    status,
    createdon,
	modifiedon)
    VALUES
    (p_type,
    p_user_id,
    p_route_id,
    p_company_id,
    p_location_id,
	p_stand_id,
    p_notes,
    p_status,
	NOW(),
    NOW());
    SELECT LAST_INSERT_ID() INTO p_id;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_STAND` (IN `p_barcode` VARCHAR(13), IN `p_stand_type_id` INT(11), IN `p_warehouse_id` INT(11), IN `p_route_id` INT(11), IN `p_serviced_every` INT(11), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR sqlexception
BEGIN
ROLLBACK;
END;
START TRANSACTION;
	SELECT COUNT(stand_id) INTO IsFound FROM pointnin_afc.stand WHERE barcode=p_barcode;
	IF IsFound=0 THEN
		INSERT INTO pointnin_afc.stand
		(name,
		barcode,
		stand_type_id,
		from_warehouse_id,
		to_warehouse_id,
		route_id,
		usage_status,
		fulfil_status,
		serviced_every,
		status,
		createdby,
		modifiedby,
		createdon,
		modifiedon)
		VALUES
		(p_barcode,
		p_barcode,
		p_stand_type_id,
		p_warehouse_id,
		p_warehouse_id,
		p_route_id,
		0,
		p_status,
		p_serviced_every,
		p_status,
		p_createdby,
		p_createdby,
		NOW(),
		NOW());
		SELECT LAST_INSERT_ID() INTO p_id;
	ELSE
		SELECT 0 INTO p_id;
	END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_STAND_SERVICE` (IN `p_user_id` INT(11), IN `p_stand_id` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE EXIT HANDLER FOR sqlexception
BEGIN
ROLLBACK;
END;
START TRANSACTION;
	IF NOT EXISTS (SELECT S.id FROM pointnin_afc.user_stands_service AS S WHERE S.user_id=p_user_id AND S.stand_id=p_stand_id) THEN
		INSERT INTO pointnin_afc.user_stands_service
		(user_id,
		stand_id,
		service_date,
		status,
		createdon,
		modifiedon)
		VALUES
		(p_user_id,
		p_stand_id,
		NOW(),
		1,
		NOW(),
		NOW());
	ELSE
		UPDATE pointnin_afc.user_stands_service
		SET
		service_date=NOW(),
		modifiedon=NOW()
		WHERE user_id=p_user_id AND stand_id=p_stand_id;
	END IF;
	SELECT 1 INTO p_id;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_STAND_SERVICE_REASON` (IN `p_type` TINYINT(2), IN `p_user_id` INT(11), IN `p_route_id` INT(11), IN `p_company_id` INT(11), IN `p_location_id` INT(11), IN `p_stand_id` INT(11), IN `p_notes` VARCHAR(255), IN `p_status` TINYINT(2), OUT `p_id` INT(11))  BEGIN
	INSERT INTO pointnin_afc.stands_service
	(type,
	user_id,
	route_id,
	company_id,
	location_id,
	stand_id,
	notes,
	status,
	createdby,
	modifiedby,
	createdon,
	modifiedon)
	VALUES
	(p_type,
	p_user_id,
	p_route_id,
	p_company_id,
	p_location_id,
	p_stand_id,
	p_notes,
	p_status,
	p_user_id,
	p_user_id,
	NOW(),
	NOW());
	
	UPDATE pointnin_afc.user_routes
	SET
	checked=3,
	modifiedby=p_user_id,
	modifiedon=NOW()
	WHERE user_id=p_user_id AND company_id=p_company_id AND location_id=p_location_id;
	
	SELECT LAST_INSERT_ID() INTO p_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_STOCK_RETURN` (IN `p_type` TINYINT(2), IN `p_from_warehouse_id` INT(11), IN `p_to_warehouse_id` INT(11), IN `p_user_id` INT(11), IN `p_description` VARCHAR(250), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
	INSERT INTO pointnin_afc.stock_return
	(type,
	from_warehouse_id,
	to_warehouse_id,
	user_id,
	transfer_date,
	description,
	status,
	createdby,
	createdon)
	VALUES
	(p_type,
	p_from_warehouse_id,
	p_to_warehouse_id,
	p_user_id,
	NOW(),
	p_description,
	1,
	p_createdby,
	NOW());
	SELECT LAST_INSERT_ID() INTO p_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_STOCK_RETURN_DETAILS` (IN `p_stock_return_id` INT(11), IN `p_user_id` INT(11), IN `p_to_warehouse_id` INT(11), IN `p_product_id` INT(11), IN `p_attribute_value_id` INT(11), IN `p_from_qty` INT(11), IN `p_qty` INT(11), IN `p_createdby` INT(11), OUT `p_id` INT(11))  BEGIN
DECLARE IsFound INT(1);
SELECT COUNT(S.id) INTO IsFound FROM pointnin_afc.user_products_stock AS S WHERE S.user_id=p_user_id AND S.product_id=p_product_id AND S.attribute_value_id=p_attribute_value_id AND S.qty >= p_qty;
IF IsFound>0 THEN
	INSERT INTO pointnin_afc.stock_return_details
	(stock_return_id,
	product_id,
	attribute_value_id,
	from_qty,
	qty,
	status,
	createdby,
	createdon)
	VALUES
	(p_stock_return_id,
	p_product_id,
	p_attribute_value_id,
	p_from_qty,
	p_qty,
	1,
	p_createdby,
	NOW());

	UPDATE pointnin_afc.user_products_stock
	SET
	qty=qty-p_qty,
	modifiedby=p_createdby,
	modifiedon=NOW()
	WHERE user_id=p_user_id AND product_id=p_product_id AND attribute_value_id=p_attribute_value_id;

	UPDATE pointnin_afc.warehouse_products_stock
	SET
	qty=qty+p_qty,
	modifiedby=p_createdby,
	modifiedon=NOW()
	WHERE warehouse_id=p_to_warehouse_id AND product_id=p_product_id AND attribute_value_id=p_attribute_value_id;
	
	UPDATE pointnin_afc.stock_return AS T SET T.total_qty=T.total_qty+p_qty WHERE T.stock_return_id=p_stock_return_id;
  
	SELECT LAST_INSERT_ID() INTO p_id;
ELSE
	SELECT 0 INTO p_id;
END IF;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_UPDATE_ATTANDENCE` (IN `p_user_id` INT(11), IN `p_type` TINYINT(2), IN `p_access` TINYINT(2), IN `p_punch_time` DATETIME, IN `p_lat` VARCHAR(70), IN `p_long` VARCHAR(70), IN `p_img` VARCHAR(50), OUT `p_id` CHAR(36))  BEGIN
DECLARE newUuid CHAR(36);
DECLARE i_attendance_id CHAR(36);
DECLARE IsFound INT(1);

IF p_access=1 THEN
	UPDATE pointnin_afc.attendance
	SET
	access=2,
	punch_out=p_punch_time,
	closed=1,
	modifiedby=p_user_id,
	modifiedon=NOW()
	WHERE user_id=p_user_id AND type=p_type AND access=1;

	SET newUuid = UUID();
	INSERT INTO pointnin_afc.attendance
	(attendance_id,
	user_id,
	type,
	access,
	punch_in,
	closed,
	in_lat,
	in_long,
	in_img,
	status,
	createdby,
	modifiedby,
	createdon,
	modifiedon)
	VALUES
	(newUuid,
	p_user_id,
	p_type,
	1,
	p_punch_time,
	1,
	p_lat,
	p_long,
	in_img,
	1,
	p_user_id,
	p_user_id,
	NOW(),
	NOW());
	SELECT newUuid INTO p_id;
ELSE
	SELECT COUNT(attendance_id),attendance_id INTO IsFound,i_attendance_id FROM pointnin_afc.attendance AS A WHERE A.user_id=p_user_id AND A.type=p_type AND A.access=1;
	IF IsFound>0 THEN
		UPDATE pointnin_afc.attendance
		SET
		access=2,
		punch_out=p_punch_time,
		closed=1,
		out_lat=p_lat,
		out_long=p_long,
		out_img=p_img,
		modifiedby=p_user_id,
		modifiedon=NOW()
		WHERE user_id=p_user_id AND type=p_type AND access=1;
		SELECT i_attendance_id INTO p_id;
	ELSE
		SELECT 0 INTO p_id;
	END IF;
END IF;
COMMIT;    
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_USER_PRODUCTS` (IN `p_type` TINYINT(2), IN `p_user_id` INT(11), IN `p_warehouse_id` INT(11), IN `p_total_stands` INT(11), IN `p_status` TINYINT(2), OUT `p_id` CHAR(36))  BEGIN
  DECLARE newUuid CHAR(36);
  SET newUuid = UUID();
  INSERT INTO pointnin_afc.user_products
  (up_id,
  type,
  user_id,
  warehouse_id,
  service_date,
  total_stands,
  total_qty,
  status,
  createdby,
  modifiedby,
  createdon,
  modifiedon)
  VALUES
  (newUuid,
  p_type,
  p_user_id,
  p_warehouse_id,
  NOW(),
  p_total_stands,
  0,
  p_status,
  p_user_id,
  p_user_id,
  NOW(),
  NOW());
  SELECT newUuid INTO p_id;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_USER_PRODUCTS_DETAILS` (IN `p_type` TINYINT(2), IN `p_up_id` CHAR(36), IN `p_user_id` INT(11), IN `p_warehouse_id` INT(11), IN `p_product_id` INT(11), IN `p_attribute_value_id` INT(11), IN `p_qty` INT(11), IN `p_price` DOUBLE, IN `p_status` TINYINT(2), OUT `p_id` CHAR(36))  BEGIN
  DECLARE newUuid CHAR(36);
  DECLARE newUuid1 CHAR(36);
  DECLARE IsFound INT(1);
  SELECT COUNT(S.id) INTO IsFound FROM pointnin_afc.warehouse_products_stock AS S WHERE S.warehouse_id=p_warehouse_id AND S.product_id=p_product_id AND S.attribute_value_id=p_attribute_value_id AND S.qty >= p_qty;
  IF IsFound>0 THEN
    SET newUuid = UUID();
    INSERT INTO pointnin_afc.user_products_details
    (upd_id,
    up_id,
    user_id,
    warehouse_id,
    product_id,
    attribute_value_id,
    qty,
    price,
    status,
    createdby,
    modifiedby,
    createdon,
    modifiedon)
    VALUES
    (newUuid,
    p_up_id,
    p_user_id,
    p_warehouse_id,
    p_product_id,
    p_attribute_value_id,
    p_qty,
    p_price,
    p_status,
    p_user_id,
    p_user_id,
    NOW(),
    NOW());
    
	IF p_type=1 THEN
		IF NOT EXISTS (SELECT S.id FROM pointnin_afc.user_products_stock AS S WHERE S.user_id=p_user_id AND S.product_id=p_product_id AND S.attribute_value_id=p_attribute_value_id) THEN
		  INSERT INTO pointnin_afc.user_products_stock
		  (user_id,
		  product_id,
		  attribute_value_id,
		  qty,
		  status,
		  createdby,
		  modifiedby,
		  createdon,
		  modifiedon)
		  VALUES
		  (p_user_id,
		  p_product_id,
		  p_attribute_value_id,
		  p_qty,
		  p_status,
		  p_user_id,
		  p_user_id,
		  NOW(),
		  NOW());
		ELSE
		  UPDATE pointnin_afc.user_products_stock
		  SET
		  qty=qty+p_qty,
		  modifiedby=p_user_id,
		  modifiedon=NOW()
		  WHERE user_id=p_user_id AND product_id=p_product_id AND attribute_value_id=p_attribute_value_id;
		END IF;
		UPDATE pointnin_afc.warehouse_products_stock AS V 
		SET V.qty=V.qty-p_qty
		WHERE V.warehouse_id=p_warehouse_id AND V.product_id=p_product_id AND V.attribute_value_id=p_attribute_value_id;
	END IF;
	UPDATE pointnin_afc.user_products AS T SET T.total_qty=T.total_qty+p_qty WHERE T.up_id=p_up_id;
  ELSE
    SET newUuid1 = UUID();
    INSERT INTO pointnin_afc.user_products_failed
    (id,
    user_id,
    up_id,
    warehouse_id,
    product_id,
    attribute_value_id,
    qty,
    price,
    servicedate,
    status,
    createdon)
    VALUES
    (newUuid1,
    p_user_id,
    p_up_id,
    p_warehouse_id,
    p_product_id,
    p_attribute_value_id,
    p_qty,
    p_price,
    NOW(),
    p_status,
    NOW());
    SELECT 0 INTO p_id;
  END IF;
  
  SELECT newUuid INTO p_id;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_USER_STANDS` (IN `p_type` TINYINT(2), IN `p_user_id` INT(11), IN `p_warehouse_id` INT(11), IN `p_total_stands` INT(11), IN `p_total_qty` INT(11), IN `p_notes` VARCHAR(250), IN `p_status` TINYINT(2), OUT `p_id` CHAR(36))  BEGIN
  DECLARE newUuid CHAR(36);
  SET newUuid = UUID();
  INSERT INTO pointnin_afc.user_stands
  (us_id,
  type,
  user_id,
  warehouse_id,
  service_date,
  total_stands,
  total_qty,
  notes,
  status,
  createdby,
  modifiedby,
  createdon,
  modifiedon)
  VALUES
  (newUuid,
  p_type,
  p_user_id,
  p_warehouse_id,
  NOW(),
  p_total_stands,
  p_total_qty,
  p_notes,
  p_status,
  p_user_id,
  p_user_id,
  NOW(),
  NOW());
  SELECT newUuid INTO p_id;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_USER_STANDS_DETAILS` (IN `p_us_id` CHAR(36), IN `p_type` TINYINT(2), IN `p_user_id` INT(11), IN `p_warehouse_id` INT(11), IN `p_barcode` VARCHAR(13), IN `p_qty` INT(11), IN `p_status` TINYINT(2), OUT `p_id` CHAR(36))  BEGIN
  DECLARE newUuid CHAR(36);
  DECLARE IsFound INT(1);
  DECLARE i_stand_id INT(11);

  IF p_type=1 THEN
    SELECT COUNT(S.stand_id), S.stand_id INTO IsFound, i_stand_id FROM pointnin_afc.stand AS S WHERE S.barcode = p_barcode AND S.allocated=0;
  ELSE
    SELECT COUNT(S.stand_id), S.stand_id INTO IsFound, i_stand_id FROM pointnin_afc.stand AS S WHERE S.barcode = p_barcode AND S.fulfil_status=1 AND S.allocated=0;
  END IF;

  IF IsFound>0 THEN
    SET newUuid = UUID();
    INSERT INTO pointnin_afc.user_stands_details
    (usd_id,
    us_id,
    user_id,
    warehouse_id,
    stand_id,
    qty,
    status,
    createdby,
    modifiedby,
    createdon,
    modifiedon)
    VALUES
    (newUuid,
    p_us_id,
    p_user_id,
    p_warehouse_id,
    i_stand_id,
    p_qty,
    p_status,
    p_user_id,
    p_user_id,
    NOW(),
    NOW());
    
    SELECT COUNT(S.id) INTO IsFound FROM pointnin_afc.user_stands_stock AS S WHERE S.user_id = p_user_id AND S.stand_id=i_stand_id;
    IF IsFound=0 THEN
      INSERT INTO pointnin_afc.user_stands_stock
      (user_id,
      stand_id,
      status,
      createdby,
      modifiedby,
      createdon,
      modifiedon)
      VALUES
      (p_user_id,
      i_stand_id,
      p_status,
      p_user_id,
      p_user_id,
      NOW(),
      NOW());
    ELSE
      UPDATE pointnin_afc.user_stands_stock
      SET
      status=1,
      modifiedby=p_user_id
      WHERE user_id=p_user_id AND stand_id=i_stand_id AND status=2;    
    END IF;

    IF p_type=2 THEN
      UPDATE pointnin_afc.stand
      SET
      fulfil_status=2,
	  allocated=1,
      modifiedby=p_user_id
      WHERE stand_id=i_stand_id AND fulfil_status=1;
	ELSE  
      UPDATE pointnin_afc.stand
      SET
      allocated=1,
      modifiedby=p_user_id
      WHERE stand_id=i_stand_id;
    END IF;

    SELECT newUuid INTO p_id;
  ELSE
    SELECT 0 INTO p_id;
  END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_CREATE_USER_STANDS_REQUEST` (IN `p_us_id` CHAR(36), IN `p_type` TINYINT(2), IN `p_user_id` INT(11), IN `p_warehouse_id` INT(11), IN `p_stand_type` INT(11), IN `p_status` TINYINT(2), OUT `p_id` CHAR(36))  BEGIN
	DECLARE newUuid CHAR(36);
	SET newUuid = UUID();
	INSERT INTO pointnin_afc.user_stands_details
	(usd_id,
	us_id,
	user_id,
	warehouse_id,
	stand_type,
	qty,
	status,
	createdby,
	modifiedby,
	createdon,
	modifiedon)
	VALUES
	(newUuid,
	p_us_id,
	p_user_id,
	p_warehouse_id,
	p_stand_type,
	1,
	p_status,
	p_user_id,
	p_user_id,
	NOW(),
	NOW());
	SELECT newUuid INTO p_id;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_ACTIVITY` (IN `p_type` TINYINT(11), IN `p_user_id` INT(11), IN `p_date` DATE)  BEGIN
	IF p_type=1 THEN
		SELECT
		A.service_date,
		A.totalworkhours,
		A.totalkm,
		A.startkm,
		A.endkm,
		A.breakhours,
		A.new_stand,
		A.remove_stand,
		A.checkout,
		(SELECT COUNT(L.id) FROM pointnin_afc.user_stands_service as L WHERE L.user_id=A.user_id AND L.service_date=A.service_date) as total_stand
		FROM pointnin_afc.activity AS A
		WHERE A.user_id=p_user_id AND A.service_date=p_date AND A.status=1;
	ELSE
		SELECT
		COUNT(A.id) as total_stand
		FROM pointnin_afc.user_stands_service AS A
		WHERE A.user_id=p_user_id AND A.service_date=p_date AND A.status=1;
	END IF;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_ATTANDENCE` (IN `p_user_id` INT(11), IN `p_type` TINYINT(2), IN `p_date` DATE, IN `p_limit` INT(11))  BEGIN
SELECT 
A.user_id,
A.punch_in,
A.punch_out,
A.in_img,
A.out_img,
A.access
FROM pointnin_afc.attendance AS A
WHERE A.user_id=p_user_id AND A.status=1 AND A.type=p_type AND A.punch_in >= p_date ORDER BY A.punch_in DESC LIMIT p_limit;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_ATTANDENCE_LAST` (IN `p_user_id` INT(11), IN `p_type` TINYINT(2))  BEGIN
SELECT 
A.punch_in,
A.in_img
FROM pointnin_afc.attendance AS A
WHERE A.user_id=p_user_id AND A.type=p_type AND A.access=1 LIMIT 1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_COMPANY_STANDS` (IN `p_company_id` INT(11), IN `p_location_id` INT(11))  BEGIN
SELECT 
A.stand_id,
(SELECT H.name FROM pointnin_afc.stand_type as H WHERE H.stand_type_id=A.stand_type_id) as stand_type_name,
A.name,
A.barcode
FROM pointnin_afc.stand AS A
WHERE A.status=1 AND A.company_id=p_company_id AND A.location_id=p_location_id
ORDER BY A.createdon DESC;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_CONFIG` (IN `p_type` VARCHAR(7))  BEGIN
SELECT
A.id,
A.code,
A.title,
A.value1
FROM pointnin_afc.configuration AS A
WHERE A.type=p_type AND A.mobile=1 AND A.status=1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_HONESTYRATE_UPTODATE` (IN `p_company_id` INT(11), IN `p_location_id` INT(11))  BEGIN
SELECT 
SUM(A.order_amount) as order_amount,
SUM(A.sale_amount) as sale_amount
FROM pointnin_afc.receipt AS A
WHERE A.company_id=p_company_id AND A.location_id=p_location_id
GROUP BY A.company_id,A.location_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_LAST_RECEIPT` (IN `p_type` TINYINT(2), IN `p_user_id` INT(11))  BEGIN
IF p_type=1 THEN
	SELECT 
	A.stand_id,
	SUM(A.order_amount) as order_amount,
	SUM(A.sale_amount) as sale_amount,
	B.barcode
	FROM pointnin_afc.receipt AS A
	LEFT JOIN pointnin_afc.stand AS B ON B.stand_id=A.stand_id
	WHERE A.status=1 AND A.user_id=p_user_id
	GROUP BY A.stand_id
	ORDER BY A.order_amount DESC;
ELSE
	SELECT 
	SUM(A.order_amount) as order_amount,
	SUM(A.sale_amount) as sale_amount
	FROM pointnin_afc.receipt AS A
	WHERE A.status=1 AND A.user_id=p_user_id
	GROUP BY A.user_id;
END IF;	
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_LOCATION_RECOMMEND` (IN `p_route_id` INT(11), IN `p_company_id` INT(11), IN `p_location_id` INT(11), IN `p_from_date` DATE, IN `p_to_date` DATE)  BEGIN
SELECT
COUNT(A.sale_item_id) as total_rows,
A.product_id,
A.attribute_value_id,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title,
SUM(A.qty) as order_qty,
SUM(A.price) as order_price,
(SELECT SUM(M.qty) FROM pointnin_afc.sale_return_items as M LEFT JOIN pointnin_afc.sale_return AS N ON N.sale_return_id=M.sale_return_id WHERE M.product_id=A.product_id AND M.attribute_value_id=A.attribute_value_id AND N.route_id=p_route_id AND N.company_id=p_company_id AND N.location_id=p_location_id) as return_qty,
(SELECT SUM(M.price) FROM pointnin_afc.sale_return_items as M LEFT JOIN pointnin_afc.sale_return AS N ON N.sale_return_id=M.sale_return_id WHERE M.product_id=A.product_id AND M.attribute_value_id=A.attribute_value_id AND N.route_id=p_route_id AND N.company_id=p_company_id AND N.location_id=p_location_id) as return_price,
C.product_name
FROM pointnin_afc.sale_items AS A
LEFT JOIN pointnin_afc.sale AS B ON B.sale_id=A.sale_id
LEFT JOIN pointnin_afc.product AS C ON C.product_id=A.product_id
WHERE B.route_id=p_route_id AND B.company_id=p_company_id AND B.location_id=p_location_id AND (B.service_date >= p_from_date AND B.service_date <=p_to_date)
GROUP BY A.product_id, A.attribute_value_id
ORDER BY C.product_name ASC;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_LOCATION_RECOMMEND_LAST_SERVICE` (IN `p_route_id` INT(11), IN `p_company_id` INT(11), IN `p_location_id` INT(11), IN `p_from_date` DATE, IN `p_to_date` DATE)  BEGIN

DECLARE d_sale_id CHAR(36);
SELECT sale_id INTO d_sale_id FROM pointnin_afc.sale AS S WHERE S.route_id=p_route_id AND S.company_id=p_company_id AND S.location_id=p_location_id ORDER BY S.createdon DESC LIMIT 1;


SELECT
A.product_id,
A.attribute_value_id,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title,
SUM(A.qty) as order_qty,
SUM(A.price) as order_price,
C.product_name,
C.category_id
FROM pointnin_afc.sale_items AS A
LEFT JOIN pointnin_afc.sale AS B ON B.sale_id=A.sale_id
LEFT JOIN pointnin_afc.product AS C ON C.product_id=A.product_id
WHERE A.sale_id=d_sale_id AND B.route_id=p_route_id AND B.company_id=p_company_id AND B.location_id=p_location_id
GROUP BY A.product_id, A.attribute_value_id
ORDER BY order_qty DESC;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_LOGIN` (IN `p_username` VARCHAR(50), IN `p_password` VARCHAR(150))  BEGIN
SELECT
A.user_id,
A.username,
A.email,
A.mobile,
A.firstname,
A.lastname,
A.role,
A.warehouse_id,
A.route_id,
(SELECT M.name FROM pointnin_afc.route as M WHERE M.route_id=A.route_id) as route_name,
A.profile_image,
A.profile_image_type,
A.wh_distance,
A.lastaccess,
B.name AS warehouse_name,
C.latitude,
C.longitude
FROM pointnin_afc.users AS A
LEFT JOIN pointnin_afc.warehouse AS B ON B.warehouse_id=A.warehouse_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=B.location_id
WHERE (A.username=p_username OR A.email=p_username OR A.mobile=p_username) AND A.password=p_password AND A.password !='' AND A.password IS NOT NULL AND A.status=1 LIMIT 1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_LOGIN_EMAIL` (IN `p_email` VARCHAR(150))  BEGIN
SELECT
A.user_id,
A.username,
A.email,
A.mobile,
A.firstname,
A.lastname,
A.role,
A.warehouse_id,
A.route_id,
(SELECT M.name FROM pointnin_afc.route as M WHERE M.route_id=A.route_id) as route_name,
A.profile_image,
A.profile_image_type,
A.wh_distance,
A.lastaccess,
B.name AS warehouse_name,
C.latitude,
C.longitude
FROM pointnin_afc.users AS A
LEFT JOIN pointnin_afc.warehouse AS B ON B.warehouse_id=A.warehouse_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=B.location_id
WHERE A.email=p_email LIMIT 1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_PRODUCTS_BARCODES` (IN `p_type` INT(11), IN `p_user_id` INT(11), IN `p_stand_id` INT(11), IN `p_warehouse_id` INT(11))  BEGIN
IF p_type=0 THEN
  SELECT
  A.product_price_id,
  A.product_id,
  A.attribute_value_id,
  (SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title,
  (SELECT M.qty FROM pointnin_afc.user_products_stock as M WHERE M.user_id=p_user_id AND M.product_id=A.product_id AND M.attribute_value_id=A.attribute_value_id LIMIT 1) as stock,
  A.barcode,
  A.price,
  B.product_name,
  B.category_id
  FROM pointnin_afc.product_price AS A
  LEFT JOIN pointnin_afc.product AS B ON B.product_id=A.product_id
  WHERE A.status=1
  ORDER BY B.product_name ASC;
ELSEIF p_type=1 THEN
  SELECT
  A.product_price_id,
  A.product_id,
  A.attribute_value_id,
  (SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title,
  (SELECT N.qty FROM pointnin_afc.stand_products_stock as N WHERE N.stand_id=p_stand_id AND N.product_id=A.product_id AND N.attribute_value_id=A.attribute_value_id LIMIT 1) as stock,
  A.barcode,
  A.price,
  B.product_name,
  B.category_id
  FROM pointnin_afc.product_price AS A
  LEFT JOIN pointnin_afc.product AS B ON B.product_id=A.product_id
  WHERE A.status=1
  ORDER BY B.product_name ASC;
ELSEIF p_type=3 THEN  
  SELECT
  A.product_price_id,
  A.product_id,
  A.attribute_value_id,
  (SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title,
  (SELECT N.qty FROM pointnin_afc.warehouse_products_stock as N WHERE N.warehouse_id=p_warehouse_id AND N.product_id=A.product_id AND N.attribute_value_id=A.attribute_value_id LIMIT 1) as stock,
  A.barcode,
  A.price,
  B.product_name,
  B.category_id
  FROM pointnin_afc.product_price AS A
  LEFT JOIN pointnin_afc.product AS B ON B.product_id=A.product_id
  WHERE A.status=1
  ORDER BY B.product_name ASC;
END IF;  
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_RECEIPT_RECENT` (IN `p_user_id` INT(11), IN `p_createdon` DATETIME)  BEGIN
SELECT
A.receipt_id,
A.sale_amount,
B.barcode,
C.name as company_name,
D.location_name
FROM pointnin_afc.receipt AS A
LEFT JOIN pointnin_afc.stand AS B ON B.stand_id=A.stand_id
LEFT JOIN pointnin_afc.company AS C ON C.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS D ON D.location_id=A.location_id
WHERE A.user_id=p_user_id AND A.createdon>=p_createdon
ORDER BY A.createdon DESC;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_ROUTES` (IN `p_role` TINYINT(2), IN `p_user_id` INT(11))  BEGIN
IF p_role=3 OR p_role=5 THEN
	SELECT 
	A.route_id,
	A.name
	FROM pointnin_afc.route AS A
	WHERE A.status=1
	ORDER BY A.name ASC;
ELSE
	SELECT 
	A.route_id,
	B.name
	FROM pointnin_afc.user_routes AS A
	LEFT JOIN pointnin_afc.route AS B ON B.route_id=A.route_id
	WHERE B.status=1 AND A.user_id=p_user_id
	GROUP BY A.route_id
	ORDER BY B.name ASC;	
END IF;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_ROUTE_LOCATION` (IN `p_route_id` INT(11))  BEGIN
SELECT
A.company_id,
A.location_id,
A.route_id,
(SELECT COUNT(H.stand_id) FROM pointnin_afc.stand as H WHERE H.company_id=A.company_id AND H.location_id AND A.location_id) as std,
B.name as company_name,
B.phone,
B.email,
B.address,
C.location_name,
C.address as loc_address,
C.latitude,
C.longitude,
C.image
FROM pointnin_afc.company_location AS A
INNER JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
INNER JOIN pointnin_afc.location AS C ON C.location_id=A.location_id
WHERE A.route_id=p_route_id AND B.status=1 AND C.status=1
ORDER BY B.createdon DESC;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_ROUTE_LOCATION_STANDS` (IN `p_route_id` INT(11))  BEGIN
SELECT
A.company_id,
A.location_id,
A.route_id,
B.name as company_name,
B.phone,
B.email,
B.address,
C.location_name,
C.address as loc_address,
C.latitude,
C.longitude,
C.image,
D.position,
D.placedon,
COUNT(D.stand_id) as std
FROM pointnin_afc.company_location AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=A.location_id
LEFT JOIN pointnin_afc.stand AS D ON D.company_id=A.company_id AND D.location_id=A.location_id
WHERE A.route_id=p_route_id AND B.status=1 AND C.status=1
GROUP BY A.company_id,A.location_id HAVING COUNT(D.stand_id) > 0
ORDER BY D.position ASC, D.placedon DESC;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_ROUTE_RECOMMEND` (IN `p_route_id` INT(11), IN `p_from_date` DATE, IN `p_to_date` DATE)  BEGIN
SELECT
COUNT(A.sale_item_id) as total_rows,
A.product_id,
A.attribute_value_id,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title,
SUM(A.qty) as order_qty,
SUM(A.price) as order_price,
(SELECT SUM(M.qty) FROM pointnin_afc.sale_return_items as M LEFT JOIN pointnin_afc.sale_return AS N ON N.sale_return_id=M.sale_return_id WHERE M.product_id=A.product_id AND M.attribute_value_id=A.attribute_value_id AND N.route_id=p_route_id) as return_qty,
(SELECT SUM(M.price) FROM pointnin_afc.sale_return_items as M LEFT JOIN pointnin_afc.sale_return AS N ON N.sale_return_id=M.sale_return_id WHERE M.product_id=A.product_id AND M.attribute_value_id=A.attribute_value_id AND N.route_id=p_route_id) as return_price,
C.product_name
FROM pointnin_afc.sale_items AS A
LEFT JOIN pointnin_afc.sale AS B ON B.sale_id=A.sale_id
LEFT JOIN pointnin_afc.product AS C ON C.product_id=A.product_id
WHERE B.route_id=p_route_id AND (B.service_date >= p_from_date AND B.service_date <=p_to_date)
GROUP BY A.product_id, A.attribute_value_id
ORDER BY C.product_name ASC;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_SALE_RETURN_ITEMS` (IN `p_user_id` INT(11), IN `p_createdby` INT(11))  BEGIN

SELECT
A.user_id,
A.product_id,
A.attribute_value_id,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title,
SUM(A.qty) AS qty,
B.product_name,
C.barcode,
C.price
FROM pointnin_afc.sale_return_items AS A
LEFT JOIN pointnin_afc.product AS B ON B.product_id=A.product_id
LEFT JOIN pointnin_afc.product_price AS C ON C.product_id=A.product_id AND C.attribute_value_id=A.attribute_value_id
WHERE A.user_id=p_user_id AND A.type=2 AND A.return_status=1
GROUP BY A.product_id,A.attribute_value_id
ORDER BY B.product_name;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_SPECIAL_REQUESTS` (IN `p_pagetype` TINYINT(2), IN `p_user_id` INT(11), IN `p_company_id` INT(11), IN `p_location_id` INT(11))  BEGIN

IF p_pagetype=1 THEN
    SET @whereQuery = CONCAT(" WHERE A.user_id='",p_user_id,"' AND A.company_id='",p_company_id,"' AND A.location_id='",p_location_id,"' AND A.status=2");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.type=1 AND A.user_id='",p_user_id,"' AND A.status=2");
END IF;

SET @SQLQuery = "
SELECT 
A.id,
A.type,
(SELECT M.name FROM pointnin_afc.route as M WHERE M.route_id=A.route_id) as route_name,
A.notes,
A.status,
B.name as company_name,
C.location_name
FROM pointnin_afc.special_request AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=A.location_id";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_STANDS_BARCODES` (IN `p_type` INT(11), IN `p_warehouse_id` INT(11))  BEGIN

SET @whereQuery1 = CONCAT(" WHERE A.status=1 AND A.allocated=0 AND A.from_warehouse_id='",p_warehouse_id,"'");
IF p_type=1 THEN
    SET @whereQuery2 = CONCAT(" AND A.fulfil_status=0 AND A.usage_status=0");
ELSE
	SET @whereQuery2 = CONCAT(" AND A.fulfil_status=1");
END IF;

SET @SQLQuery = "
SELECT 
A.stand_id,
A.barcode
FROM pointnin_afc.stand AS A";

SET @whereQuery = CONCAT(@whereQuery1,@whereQuery2);

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);

PREPARE stmt FROM @SQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_STAND_BARCODE` (IN `p_type` TINYINT(2), IN `p_user_id` INT(11), IN `p_company_id` INT(11), IN `p_barcode` VARCHAR(13))  BEGIN
IF p_type=1 THEN
	SELECT
	A.stand_id,
	A.name,
	A.barcode
	FROM pointnin_afc.stand AS A
	LEFT JOIN pointnin_afc.user_routes AS B ON B.stand_id=A.stand_id
	WHERE B.user_id=p_user_id AND B.company_id=p_company_id AND A.barcode=p_barcode AND B.status=1;
ELSE
	SELECT
	A.stand_id,
	A.name,
	A.barcode
	FROM pointnin_afc.stand AS A
	LEFT JOIN pointnin_afc.user_stands_stock AS B ON B.stand_id=A.stand_id
	WHERE B.user_id=p_user_id AND B.status=1
	LIMIT 1;
END IF;	
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_STAND_PRODUCTS_STOCK` (IN `p_stand_id` INT(11))  BEGIN
SELECT
A.id,
A.product_id,
A.attribute_value_id,
A.qty as stock
FROM pointnin_afc.stand_products_stock AS A
WHERE A.stand_id=p_stand_id AND A.status=1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_STAND_PRODUCTS_STOCKS` (IN `p_stand_id` INT(11))  BEGIN
SELECT
A.id,
A.stand_id,
A.product_id,
A.attribute_value_id,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title,
(SELECT M.barcode FROM pointnin_afc.product_price as M WHERE M.product_id=A.product_id AND M.attribute_value_id=A.attribute_value_id) as barcode,
A.qty,
B.product_name
FROM pointnin_afc.stand_products_stock AS A
LEFT JOIN pointnin_afc.product AS B ON B.product_id=A.product_id
WHERE A.stand_id=p_stand_id AND A.status=1 AND A.qty>0
ORDER BY A.qty DESC;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_STAND_TYPES` (IN `p_status` TINYINT(11))  BEGIN
SELECT
A.stand_type_id,
A.name
FROM pointnin_afc.stand_type AS A
WHERE A.status=1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_USERS` (IN `p_role` TINYINT(2), IN `p_warehouse_id` INT(11))  BEGIN
SELECT
A.user_id,
A.username,
A.firstname,
A.lastname
FROM pointnin_afc.users AS A
WHERE A.role=p_role AND A.warehouse_id=p_warehouse_id AND A.status=1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_USER_DEPOSITED_DAY` (IN `p_user_id` INT(11), IN `p_service_date` DATE)  BEGIN
SELECT
SUM(A.total_amount) as total_amount
FROM pointnin_afc.collection AS A
WHERE A.user_id=p_user_id AND A.service_date=p_service_date;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_USER_EXPENSES_DAY` (IN `p_user_id` INT(11), IN `p_service_date` DATE)  BEGIN
SELECT
SUM(A.amount) as total_amount
FROM pointnin_afc.user_expenses AS A
WHERE A.user_id=p_user_id AND A.service_date=p_service_date;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_USER_PRODUCTS_STOCK` (IN `p_user_id` INT(11))  BEGIN
SELECT
A.id,
A.user_id,
A.product_id,
A.attribute_value_id,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title,
(SELECT M.barcode FROM pointnin_afc.product_price as M WHERE M.product_id=A.product_id AND M.attribute_value_id=A.attribute_value_id) as barcode,
A.qty,
B.product_name
FROM pointnin_afc.user_products_stock AS A
LEFT JOIN pointnin_afc.product AS B ON B.product_id=A.product_id
WHERE A.user_id=p_user_id AND A.status=1
ORDER BY B.product_name ASC;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_USER_ROUTES` (IN `p_user_id` INT(11))  BEGIN
SELECT
A.user_id,
A.route_id,
B.name as route_name
FROM pointnin_afc.user_route AS A
LEFT JOIN pointnin_afc.route AS B ON B.route_id=A.route_id
WHERE A.user_id=p_user_id AND B.status=1
ORDER BY B.name ASC;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_USER_ROUTE_COMPANIES` (IN `p_user_id` INT(11), IN `p_route_id` INT(11))  BEGIN
SELECT 
A.route_id,
(SELECT H.name FROM pointnin_afc.route as H WHERE H.route_id=A.route_id) as route_name,
A.location_id,
A.company_id,
A.status,
A.checked,
A.modifiedon,
COUNT(A.stand_id) as std,
B.name as company_name,
B.phone,
B.email,
B.address,
C.location_id,
C.location_name,
C.address as loc_address,
C.image,
C.latitude,
C.longitude,
D.serviced_date,
SUM(D.order_amount) as total_order_amount,
D.position
FROM pointnin_afc.user_routes AS A
LEFT JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
LEFT JOIN pointnin_afc.location AS C ON C.location_id=A.location_id
LEFT JOIN pointnin_afc.stand AS D ON D.stand_id=A.stand_id
WHERE A.route_id=p_route_id AND A.user_id=p_user_id AND A.status=1 AND ((D.serviced_date <= CURDATE() - INTERVAL D.serviced_every DAY) OR D.serviced_date = CURDATE() OR D.serviced_date IS NULL)
GROUP BY A.location_id, A.company_id
ORDER BY A.position ASC;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_USER_ROUTE_LOCATION` (IN `p_user_id` INT(11), IN `p_route_id` INT(11))  BEGIN
SELECT
A.company_id,
A.location_id,
A.route_id,
(SELECT COUNT(H.stand_id) FROM pointnin_afc.stand as H WHERE H.company_id=A.company_id AND H.location_id AND A.location_id) as std,
B.name as company_name,
B.phone,
B.email,
B.address,
C.location_name,
C.address as loc_address,
C.latitude,
C.longitude,
C.image
FROM pointnin_afc.company_location AS A
INNER JOIN pointnin_afc.company AS B ON B.company_id=A.company_id
INNER JOIN pointnin_afc.location AS C ON C.location_id=A.location_id
LEFT JOIN pointnin_afc.user_routes AS D ON D.company_id=A.company_id AND D.location_id=A.location_id
WHERE B.createdby=p_user_id AND A.route_id=p_route_id AND B.status=1 AND C.status=1 AND D.company_id IS NULL
ORDER BY B.createdon DESC;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_USER_SERVICED_LOCATIONS` (IN `p_user_id` INT(11), IN `p_date` DATE)  BEGIN
	SELECT
	A.company_id,
	A.location_id,
	COUNT(A.stand_id) as service_stands,
	(SELECT L.amount FROM pointnin_afc.user_expenses as L WHERE L.company_id=A.company_id AND L.location_id=A.location_id AND L.service_date=A.service_date LIMIT 1) as amount,
	(SELECT L.type FROM pointnin_afc.user_expenses as L WHERE L.company_id=A.company_id AND L.location_id=A.location_id AND L.service_date=A.service_date LIMIT 1) as type,
	B.barcode,
	C.name as company_name,
	D.location_name
	FROM pointnin_afc.user_stands_service AS A
	LEFT JOIN pointnin_afc.stand AS B ON B.stand_id=A.stand_id
	LEFT JOIN pointnin_afc.company AS C ON C.company_id=A.company_id
	LEFT JOIN pointnin_afc.location AS D ON D.location_id=A.location_id
	WHERE A.user_id=p_user_id AND A.service_date=p_date AND A.status=1
	GROUP BY A.company_id,A.location_id;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_USER_STANDS_STOCK` (IN `p_user_id` INT(11))  BEGIN
SELECT
A.id,
A.stand_id,
B.name,
B.barcode,
B.route_id,
(SELECT L.name FROM pointnin_afc.route as L WHERE L.route_id=B.route_id) as route_name
FROM pointnin_afc.user_stands_stock AS A
LEFT JOIN pointnin_afc.stand AS B ON B.stand_id=A.stand_id
WHERE A.user_id=p_user_id AND A.status=1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_VALIDATE_STANDS` (IN `p_barcode` VARCHAR(13))  BEGIN
	SELECT
	A.stand_id,
	A.name,
	A.barcode
	FROM pointnin_afc.stand AS A
	WHERE A.barcode=p_barcode;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_VEHICLES` (IN `p_user_id` INT(11))  BEGIN
SELECT
A.vehicle_id,
A.name,
A.capacity
FROM pointnin_afc.vehicle AS A
WHERE A.user_id IN(p_user_id, 1) AND A.status=1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_VEHICLE_CHECK` (IN `p_user_id` INT(11), IN `p_vehicle_id` INT(11))  BEGIN
SELECT
A.vehicle_id,
A.name
FROM pointnin_afc.vehicle AS A
WHERE A.user_id=p_user_id AND A.type=1 AND A.usage_status=1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_GET_WH_PRODUCTS_STOCK` (IN `p_warehouse_id` INT(11))  BEGIN
SELECT
A.id,
A.product_id,
A.attribute_value_id,
(SELECT L.value FROM pointnin_afc.attribute_value as L WHERE L.attribute_value_id=A.attribute_value_id) as attribute_title,
(SELECT M.barcode FROM pointnin_afc.product_price as M WHERE M.product_id=A.product_id AND M.attribute_value_id=A.attribute_value_id) as barcode,
A.qty,
B.product_name
FROM pointnin_afc.warehouse_products_stock AS A
LEFT JOIN pointnin_afc.product AS B ON B.product_id=A.product_id
WHERE A.warehouse_id=p_warehouse_id AND A.status=1
ORDER BY B.product_name ASC;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_UPDATE_ACTIVITY_STAND` (IN `p_type` TINYINT(2), IN `p_user_id` INT(11), IN `p_service_date` DATE, OUT `p_spstatus` INT(11))  BEGIN
	IF p_type=1 THEN
		UPDATE pointnin_afc.activity
		SET
		new_stand=new_stand+1,
		modifiedon=NOW()
		WHERE user_id=p_user_id AND service_date=p_service_date;
	ELSE
		UPDATE pointnin_afc.activity
		SET
		remove_stand=remove_stand+1,
		modifiedon=NOW()
		WHERE user_id=p_user_id AND service_date=p_service_date;
	END IF;
    SET p_spstatus=1;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_UPDATE_ACTIVITY_STAND_V1` (IN `p_type` TINYINT(2), IN `p_user_id` INT(11), IN `p_total_stand` INT(11), IN `p_service_date` DATE, OUT `p_spstatus` INT(11))  BEGIN
	IF p_type=1 THEN
		UPDATE pointnin_afc.activity
		SET
		new_stand=new_stand+p_total_stand,
		modifiedon=NOW()
		WHERE user_id=p_user_id AND service_date=p_service_date;
	ELSE
		UPDATE pointnin_afc.activity
		SET
		remove_stand=remove_stand+p_total_stand,
		modifiedon=NOW()
		WHERE user_id=p_user_id AND service_date=p_service_date;
	END IF;
    SET p_spstatus=1;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_UPDATE_FORGOT_PASSWORD` (IN `p_email` VARCHAR(150), IN `p_forgot_otp` VARCHAR(10), OUT `p_spstatus` INT(11))  BEGIN
DECLARE IsFound INT(1);
SELECT COUNT(S.user_id) INTO IsFound FROM pointnin_afc.users AS S WHERE S.email = p_email AND S.status=1;
IF IsFound=1 THEN
    UPDATE pointnin_afc.users
    SET
    forgot_otp=p_forgot_otp
    WHERE email=p_email;
    SET p_spstatus=1;
ELSE
	SET p_spstatus=0;
END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_UPDATE_PREVIOUS_ORDER` (IN `p_stand_id` INT(11), OUT `p_spstatus` INT(11))  BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
SET p_spstatus=0;
ROLLBACK;
END;
START TRANSACTION;
	UPDATE pointnin_afc.stand
	SET
	order_amount=0
	WHERE stand_id=p_stand_id;

	IF EXISTS (SELECT S.id FROM pointnin_afc.stand_products_stock AS S WHERE S.stand_id=p_stand_id) THEN
		UPDATE pointnin_afc.stand_products_stock
		SET
		qty=0,
		modifiedon=NOW()
		WHERE stand_id=p_stand_id;
	END IF;  

  SET p_spstatus=1;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_UPDATE_RECEIPT_RECENT` (IN `p_receipt_id` CHAR(36), IN `p_sale_amount` DOUBLE, IN `p_user_id` INT(11), OUT `p_spstatus` INT(11))  BEGIN
	UPDATE pointnin_afc.receipt
	SET
	sale_amount=p_sale_amount,
	modifiedby=p_user_id,
	modifiedon=NOW()
	WHERE receipt_id=p_receipt_id;
	SET p_spstatus=1;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_UPDATE_REMOVE_STAND` (IN `p_user_id` INT(11), IN `p_route_id` INT(11), IN `p_company_id` INT(11), IN `p_location_id` INT(11), IN `p_stand_id` INT(11), IN `p_notes` VARCHAR(255), OUT `p_spstatus` INT(11))  BEGIN
    UPDATE pointnin_afc.stand
    SET
    company_id=NULL,
    location_id=NULL,
    route_id=NULL,
    order_amount=0,
    service_notes=p_notes,
    removedon=NOW(),
    status=0,
    usage_status=0,
    fulfil_status=0,
	allocated=0,
    modifiedby=p_user_id,
    modifiedon=NOW()
    WHERE stand_id=p_stand_id;
    
    UPDATE pointnin_afc.user_routes
    SET
    status=0,
    modifiedby=p_user_id,
    modifiedon=NOW()
    WHERE stand_id=p_stand_id AND user_id=p_user_id;

    INSERT INTO pointnin_afc.stand_remove
    (user_id,
    route_id,
    company_id,
    location_id,
    stand_id,
    notes,
    status,
    createdon)
    VALUES
    (p_user_id,
    p_route_id,
    p_company_id,
    p_location_id,
    p_stand_id,
    p_notes,
    1,
    NOW());
    
    SET p_spstatus=1;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_UPDATE_RESET_PASSWORD` (IN `p_email` VARCHAR(150), IN `p_password` VARCHAR(150), IN `p_forgot_otp` VARCHAR(10), OUT `p_spstatus` INT(11))  BEGIN
DECLARE IsFound INT(1);
SELECT COUNT(S.user_id) INTO IsFound FROM pointnin_afc.users AS S WHERE S.email = p_email AND S.forgot_otp = p_forgot_otp AND S.status=1;
IF IsFound=1 THEN
    UPDATE pointnin_afc.users
    SET
    password=p_password
    WHERE email=p_email;
    SET p_spstatus=1;
ELSE
	SET p_spstatus=0;
END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_UPDATE_SPECIAL_REQUEST` (IN `p_id` INT(11), IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
START TRANSACTION;
  SELECT COUNT(id) INTO IsFound FROM pointnin_afc.special_request WHERE id=p_id AND status=p_status;
  IF IsFound=0 THEN
    UPDATE pointnin_afc.special_request
    SET
    status=p_status,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE id=p_id;
    SET p_spstatus=1;
  ELSE
    SET p_spstatus=0;
  END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_UPDATE_STAND_COMPANY` (IN `p_stand_id` INT(11), IN `p_route_id` INT(11), IN `p_company_id` INT(11), IN `p_location_id` INT(11), IN `p_user_id` INT(11), OUT `p_spstatus` INT(11))  BEGIN
DECLARE IsFound INT(1);
	UPDATE pointnin_afc.stand
	SET
	company_id=p_company_id,
	location_id=p_location_id,
	route_id=p_route_id,
	allocated=2,
	placedon=NOW(),
	serviced_date=NOW(),
	modifiedby=p_user_id,
	modifiedon=NOW()
	WHERE stand_id=p_stand_id;

	UPDATE pointnin_afc.user_stands_stock
	SET
	status=2,
	modifiedby=p_user_id,
	modifiedon=NOW()
	WHERE stand_id=p_stand_id AND user_id=p_user_id AND status=1;
	
	IF NOT EXISTS (SELECT S.user_routes_id FROM pointnin_afc.user_routes AS S WHERE S.stand_id=p_stand_id AND S.user_id=p_user_id) THEN
		INSERT INTO pointnin_afc.user_routes
		(user_id,
		stand_id,
		route_id,
		location_id,
		company_id,
		status,
		createdby,
		modifiedby,
		createdon,
		modifiedon)
		VALUES
		(p_user_id,
		p_stand_id,
		p_route_id,
		p_location_id,
		p_company_id,
		1,
		p_user_id,
		p_user_id,
		NOW(),
		NOW());
	ELSE
      UPDATE pointnin_afc.user_routes
      SET
      status=1,
      modifiedby=p_user_id,
      modifiedon=NOW()
      WHERE S.stand_id=p_stand_id AND S.user_id=p_user_id;
	END IF;
	
	SET p_spstatus=1;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_UPDATE_STAND_COMPANY_SALE` (IN `p_barcode` VARCHAR(13), IN `p_company_id` INT(11), IN `p_location_id` INT(11), IN `p_user_id` INT(11), IN `p_position` INT(11), OUT `p_spstatus` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE IsFound1 INT(1);
DECLARE IsFound2 INT(1);
DECLARE i_stand_id INT(11);
SELECT COUNT(S.stand_id), S.stand_id INTO IsFound, i_stand_id FROM pointnin_afc.stand AS S WHERE S.barcode = p_barcode;
IF IsFound=1 THEN
	SELECT COUNT(S.id) INTO IsFound1 FROM pointnin_afc.user_stands_stock AS S WHERE S.stand_id=i_stand_id AND S.user_id=p_user_id;
	IF IsFound1>0 THEN
		SELECT COUNT(S.id) INTO IsFound2 FROM pointnin_afc.user_stands_stock AS S WHERE S.stand_id=i_stand_id AND S.user_id=p_user_id AND S.status=1;
		IF IsFound2>0 THEN
			UPDATE pointnin_afc.sale
			SET
			company_id=p_company_id,
			location_id=p_location_id,
			modifiedby=p_user_id,
			modifiedon=NOW()
			WHERE stand_id=i_stand_id AND company_id IS NULL AND location_id IS NULL;

			UPDATE pointnin_afc.stand
			SET
			company_id=p_company_id,
			location_id=p_location_id,
			allocated=2,
			position=p_position,
			placedon=NOW(),
			serviced_date=NOW(),
			modifiedby=p_user_id,
			modifiedon=NOW()
			WHERE stand_id=i_stand_id AND fulfil_status=2;

			UPDATE pointnin_afc.user_stands_stock
			SET
			status=2,
			modifiedby=p_user_id,
			modifiedon=NOW()
			WHERE stand_id=i_stand_id AND user_id=p_user_id AND status=1;
			
			INSERT INTO pointnin_afc.user_stands_service
			(user_id,
			stand_id,
			company_id,
			location_id,
			service_date,
			status,
			createdon,
			modifiedon)
			VALUES
			(p_user_id,
			i_stand_id,
			p_company_id,
			p_location_id,
			NOW(),
			1,
			NOW(),
			NOW());
			
			SET p_spstatus=1;
		ELSE
			SET p_spstatus=0;
		END IF;
	ELSE
		SET p_spstatus=3;
	END IF;	  
ELSE
	SET p_spstatus=2;
END IF;	  
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_UPDATE_STAND_COMPANY_SALE_1` (IN `p_serviced_every` INT(11), IN `p_barcode` VARCHAR(13), IN `p_company_id` INT(11), IN `p_route_id` INT(11), IN `p_location_id` INT(11), IN `p_user_id` INT(11), IN `p_position` INT(11), OUT `p_spstatus` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE IsFound1 INT(1);
DECLARE IsFound2 INT(1);
DECLARE IsFound3 INT(1);
DECLARE i_stand_id INT(11);
DECLARE i_assigned_to_user_id INT(11);
SELECT COUNT(S.stand_id), S.stand_id INTO IsFound, i_stand_id FROM pointnin_afc.stand AS S WHERE S.barcode = p_barcode;
IF IsFound=1 THEN
	SELECT COUNT(S.stand_id) INTO IsFound3 FROM pointnin_afc.stand AS S WHERE S.barcode = p_barcode AND S.route_id = p_route_id;
	IF IsFound3=1 THEN
		SELECT COUNT(S.id) INTO IsFound1 FROM pointnin_afc.user_stands_stock AS S WHERE S.stand_id=i_stand_id AND S.user_id=p_user_id;
		IF IsFound1>0 THEN
			SELECT COUNT(S.id) INTO IsFound2 FROM pointnin_afc.user_stands_stock AS S WHERE S.stand_id=i_stand_id AND S.user_id=p_user_id AND S.status=1;
			IF IsFound2>0 THEN
				UPDATE pointnin_afc.sale
				SET
				company_id=p_company_id,
				location_id=p_location_id,
				modifiedby=p_user_id,
				modifiedon=NOW()
				WHERE stand_id=i_stand_id AND company_id IS NULL AND location_id IS NULL;

				UPDATE pointnin_afc.stand
				SET
				company_id=p_company_id,
				location_id=p_location_id,
				allocated=2,
				position=p_position,
				placedon=NOW(),
				serviced_date=NOW(),
				modifiedby=p_user_id,
				modifiedon=NOW()
				WHERE stand_id=i_stand_id AND fulfil_status=2;

				UPDATE pointnin_afc.user_stands_stock
				SET
				status=2,
				modifiedby=p_user_id,
				modifiedon=NOW()
				WHERE stand_id=i_stand_id AND user_id=p_user_id AND status=1;
				
				INSERT INTO pointnin_afc.user_stands_service
				(user_id,
				stand_id,
				company_id,
				location_id,
				service_date,
				status,
				createdon,
				modifiedon)
				VALUES
				(p_user_id,
				i_stand_id,
				p_company_id,
				p_location_id,
				NOW(),
				1,
				NOW(),
				NOW());
				
				INSERT INTO pointnin_afc.stand_history
				(type,
				user_id,
				route_id,
				company_id,
				location_id,
				stand_id,
				status,
				createdby,
				createdon)
				VALUES
				(1,
				p_user_id,
				p_route_id,
				p_company_id,
				p_location_id,
				i_stand_id,
				1,
				p_user_id,
				NOW());					
				
				SELECT R.user_id INTO i_assigned_to_user_id FROM pointnin_afc.user_route AS R WHERE R.route_id = p_route_id LIMIT 1;
				IF i_assigned_to_user_id IS NOT NULL THEN
					INSERT INTO pointnin_afc.user_routes
					(user_id,
					stand_id,
					route_id,
					location_id,
					company_id,
					status,
					position,
					createdby,
					modifiedby,
					createdon,
					modifiedon)
					VALUES
					(i_assigned_to_user_id,
					i_stand_id,
					p_route_id,
					p_location_id,
					p_company_id,
					1,
					p_position,
					p_user_id,
					p_user_id,
					NOW(),
					NOW());
					UPDATE pointnin_afc.stand SET usage_status=1, serviced_every=p_serviced_every, modifiedby=p_user_id, modifiedon=NOW() WHERE stand_id=i_stand_id;
				END IF;				
				
				SET p_spstatus=1;
			ELSE
				SET p_spstatus=0;
			END IF;
		ELSE
			SET p_spstatus=3;
		END IF;
	ELSE
		SET p_spstatus=6;
	END IF;
ELSE
	SET p_spstatus=2;
END IF;	  
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_UPDATE_STAND_COMPANY_SALE_CREATE` (IN `p_serviced_every` INT(11), IN `p_barcode` VARCHAR(13), IN `p_companyname` VARCHAR(255), IN `p_location_name` VARCHAR(255), IN `p_address` VARCHAR(255), IN `p_route_id` INT(11), IN `p_country_id` INT(11), IN `p_city_id` INT(11), IN `p_phone` VARCHAR(15), IN `p_email` VARCHAR(150), IN `p_description` VARCHAR(255), IN `p_latitude` VARCHAR(15), IN `p_longitude` VARCHAR(15), IN `p_user_id` INT(11), IN `p_position` INT(11), OUT `p_spstatus` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE IsFound1 INT(1);
DECLARE IsFound2 INT(1);
DECLARE IsFound3 INT(1);
DECLARE IsFound4 INT(1);
DECLARE IsFound5 INT(1);
DECLARE i_stand_id INT(11);
DECLARE i_company_id INT(11);
DECLARE i_location_id INT(11);
DECLARE i_assigned_to_user_id INT(11);
SELECT COUNT(S.stand_id), S.stand_id INTO IsFound, i_stand_id FROM pointnin_afc.stand AS S WHERE S.barcode = p_barcode;
IF IsFound=1 THEN
	SELECT COUNT(S.stand_id) INTO IsFound5 FROM pointnin_afc.stand AS S WHERE S.barcode = p_barcode AND S.route_id = p_route_id;
	IF IsFound5=1 THEN
		SELECT COUNT(S.id) INTO IsFound1 FROM pointnin_afc.user_stands_stock AS S WHERE S.stand_id=i_stand_id AND S.user_id=p_user_id;
		IF IsFound1>0 THEN
			SELECT COUNT(S.id) INTO IsFound2 FROM pointnin_afc.user_stands_stock AS S WHERE S.stand_id=i_stand_id AND S.user_id=p_user_id AND S.status=1;
			IF IsFound2>0 THEN
				SELECT COUNT(company_id), company_id INTO IsFound3, i_company_id FROM pointnin_afc.company WHERE name=p_companyname;
				IF IsFound3=0 THEN
					INSERT INTO pointnin_afc.company
					(name,
					phone,
					email,
					address,
					description,
					status,
					createdby,
					modifiedby,
					createdon,
					modifiedon)
					VALUES
					(p_companyname,
					p_phone,
					p_email,
					p_address,
					p_description,
					1,
					p_user_id,
					p_user_id,
					NOW(),
					NOW());
					SELECT LAST_INSERT_ID() INTO i_company_id;

					SELECT COUNT(location_id), location_id INTO IsFound4, i_location_id FROM pointnin_afc.location WHERE location_name=p_location_name AND country_id=p_country_id AND city_id=p_city_id;
					IF IsFound4=0 THEN
						INSERT INTO pointnin_afc.location
						(route_id,
						country_id,
						city_id,
						location_name,
						address,
						latitude,
						longitude,
						status,
						createdby,
						modifiedby,
						createdon,
						modifiedon)
						VALUES
						(p_route_id,
						p_country_id,
						p_city_id,
						p_location_name,
						p_address,
						p_latitude,
						p_longitude,
						1,
						p_user_id,
						p_user_id,
						NOW(),
						NOW());
						SELECT LAST_INSERT_ID() INTO i_location_id;
					END IF;  

					INSERT INTO pointnin_afc.company_location
					(company_id,
					location_id,
					route_id,
					createdby,
					createdon)
					VALUES
					(i_company_id,
					i_location_id,
					p_route_id,
					p_user_id,
					NOW());			
				
					UPDATE pointnin_afc.sale
					SET
					company_id=i_company_id,
					location_id=i_location_id,
					modifiedby=p_user_id,
					modifiedon=NOW()
					WHERE stand_id=i_stand_id AND company_id IS NULL AND location_id IS NULL;

					UPDATE pointnin_afc.stand
					SET
					company_id=i_company_id,
					location_id=i_location_id,
					allocated=2,
					position=p_position,
					placedon=NOW(),
					serviced_date=NOW(),
					modifiedby=p_user_id,
					modifiedon=NOW()
					WHERE stand_id=i_stand_id AND fulfil_status=2;

					UPDATE pointnin_afc.user_stands_stock
					SET
					status=2,
					modifiedby=p_user_id,
					modifiedon=NOW()
					WHERE stand_id=i_stand_id AND user_id=p_user_id AND status=1;
					
					INSERT INTO pointnin_afc.user_stands_service
					(user_id,
					stand_id,
					company_id,
					location_id,
					service_date,
					status,
					createdon,
					modifiedon)
					VALUES
					(p_user_id,
					i_stand_id,
					i_company_id,
					i_location_id,
					NOW(),
					1,
					NOW(),
					NOW());
					
					INSERT INTO pointnin_afc.stand_history
					(type,
					user_id,
					route_id,
					company_id,
					location_id,
					stand_id,
					status,
					createdby,
					createdon)
					VALUES
					(1,
					p_user_id,
					p_route_id,
					i_company_id,
					i_location_id,
					i_stand_id,
					1,
					p_user_id,
					NOW());					
					
					SELECT R.user_id INTO i_assigned_to_user_id FROM pointnin_afc.user_route AS R WHERE R.route_id = p_route_id LIMIT 1;
					IF i_assigned_to_user_id IS NOT NULL THEN
						INSERT INTO pointnin_afc.user_routes
						(user_id,
						stand_id,
						route_id,
						location_id,
						company_id,
						status,
						position,
						createdby,
						modifiedby,
						createdon,
						modifiedon)
						VALUES
						(i_assigned_to_user_id,
						i_stand_id,
						p_route_id,
						i_location_id,
						i_company_id,
						1,
						p_position,
						p_user_id,
						p_user_id,
						NOW(),
						NOW());
						UPDATE pointnin_afc.stand SET usage_status=1, serviced_every=p_serviced_every, modifiedby=p_user_id, modifiedon=NOW() WHERE stand_id=i_stand_id;
					END IF;				
					
					SET p_spstatus=1;
				ELSE
					SET p_spstatus=6;
				END IF;				
			ELSE
				SET p_spstatus=0;
			END IF;
		ELSE
			SET p_spstatus=3;
		END IF;	 
	ELSE
		SET p_spstatus=7;
	END IF;		
ELSE
	SET p_spstatus=2;
END IF;	  
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_UPDATE_STAND_LOCATION_POSITION` (IN `p_position` INT(11), IN `p_route_id` INT(11), IN `p_location_id` INT(11), IN `p_company_id` INT(11), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
	UPDATE pointnin_afc.user_routes
	SET
	position=p_position,
	modifiedby=p_modifiedby
	WHERE route_id=p_route_id AND location_id=p_location_id AND company_id=p_company_id;
	
	UPDATE pointnin_afc.stand
	SET
	position=p_position,
	modifiedby=p_modifiedby
	WHERE route_id=p_route_id AND location_id=p_location_id AND company_id=p_company_id;
	SET p_spstatus=1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_UPDATE_STAND_TAKE` (IN `p_stand_id` INT(11), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(11))  BEGIN

  UPDATE pointnin_afc.stand
  SET
  fulfil_status=2,
  modifiedby=p_modifiedby
  WHERE stand_id=p_stand_id;

  SET p_spstatus=1;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_UPDATE_USER_TIMEZONE` (IN `p_user_id` INT(11), IN `p_timezone` VARCHAR(100), OUT `p_spstatus` INT(11))  BEGIN
    UPDATE pointnin_afc.users
    SET
    timezone=p_timezone,
    modifiedon=NOW()
    WHERE user_id=p_user_id;
    SET p_spstatus=1;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_UPDATE_VEHICLE_CHECK` (IN `p_type` TINYINT(2), IN `p_user_id` INT(11), IN `p_vehicle_id` INT(11), OUT `p_spstatus` INT(11))  BEGIN
	IF p_type=1 THEN
		IF EXISTS (SELECT S.vehicle_id FROM pointnin_afc.vehicle AS S WHERE S.vehicle_id=p_vehicle_id AND S.user_id!=p_user_id AND S.type=1 AND S.usage_status=1) THEN
			SET p_spstatus=0;
		ELSE
			UPDATE pointnin_afc.vehicle
			SET
			usage_status=0
			WHERE user_id=p_user_id;
			
			UPDATE pointnin_afc.vehicle
			SET
			user_id=p_user_id,
			usage_status=1,
			modifiedby=p_user_id,
			modifiedon=NOW()
			WHERE vehicle_id=p_vehicle_id;
			SET p_spstatus=1;
		END IF;
	ELSE
		UPDATE pointnin_afc.vehicle
		SET
		user_id=1,
		usage_status=0,
		modifiedby=p_user_id,
		modifiedon=NOW()
		WHERE user_id=p_user_id AND type=1;
		SET p_spstatus=1;
	END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `MOB_VALIDATE_USER_SYNC` (IN `p_user_id` INT(11))  BEGIN
SELECT
A.user_id,
A.sync
FROM pointnin_afc.users AS A
WHERE A.user_id=p_user_id AND A.sync=1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_ATTRIBUTE_VALUE` (IN `p_attribute_value_id` INT(11), IN `p_attribute_id` INT(11), IN `p_value` VARCHAR(50), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
    SELECT COUNT(attribute_value_id) INTO IsFound FROM pointnin_afc.attribute_value WHERE value=p_value AND attribute_value_id!=p_attribute_value_id;
    IF IsFound=0 THEN
        UPDATE pointnin_afc.attribute_value
        SET
        value=p_value,
        status=p_status,
        createdby=p_createdby,
        modifiedon=NOW()
        WHERE attribute_value_id=p_attribute_value_id;
    	SET p_spstatus=1;
    ELSE
        SET p_spstatus=0;
    END IF;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_AUTO_PUNCH_OUT` (IN `p_attendance_id` CHAR(36), IN `p_punchout_time` DATETIME, OUT `p_spstatus` INT(2))  BEGIN
UPDATE pointnin_afc.attendance
SET
punch_out=p_punchout_time,
access=2,
closed=2,
modifiedon=NOW()
WHERE attendance_id=p_attendance_id;
SET p_spstatus=1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_CATEGORY` (IN `p_warehouse_id` INT(11), IN `p_category_id` INT(11), IN `p_category_name` VARCHAR(150), IN `p_category_desc` VARCHAR(255), IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
SET p_spstatus=0;
ROLLBACK;
END;
START TRANSACTION;
    SELECT COUNT(category_id) INTO IsFound FROM pointnin_afc.category WHERE category_name=p_category_name AND category_id!=p_category_id;
    IF IsFound=0 THEN
        UPDATE pointnin_afc.category
        SET
        category_name=p_category_name,
        category_desc=p_category_desc,
        status=p_status,
        modifiedby=p_modifiedby,
        modifiedon=NOW()
        WHERE category_id=p_category_id;
    	SET p_spstatus=1;
    ELSE
        SET p_spstatus=0;
    END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_CITY` (IN `p_city_id` INT(11), IN `p_country_id` INT(11), IN `p_state_id` INT(11), IN `p_city_name` VARCHAR(200), IN `p_latitude` FLOAT(10,6), IN `p_longitude` FLOAT(10,6), IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR sqlexception
BEGIN
SET p_spstatus=0;
ROLLBACK;
END;
START TRANSACTION;
    SELECT COUNT(city_id) INTO IsFound FROM pointnin_afc.city WHERE (city_name=p_city_name AND country_id=p_country_id AND city_id!=p_city_id);
    IF IsFound=0 THEN
        UPDATE pointnin_afc.city
        SET
        country_id=p_country_id,
        state_id=p_state_id,
        city_name=p_city_name,
        latitude=p_latitude,
        longitude=p_longitude,
        status=p_status,
        modifiedon=NOW()
        WHERE city_id=p_city_id;
    	SET p_spstatus=1;
    ELSE
        SET p_spstatus=0;
    END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_COMPANY` (IN `p_company_id` INT(11), IN `p_name` VARCHAR(255), IN `p_phone` VARCHAR(15), IN `p_email` VARCHAR(150), IN `p_address` VARCHAR(255), IN `p_description` VARCHAR(255), IN `p_image` VARCHAR(100), IN `p_outstandingamount` DOUBLE, IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
SET p_spstatus=0;
ROLLBACK;
END;
START TRANSACTION;
  SELECT COUNT(company_id) INTO IsFound FROM pointnin_afc.company WHERE name=p_name AND company_id!=p_company_id;
  IF IsFound=0 THEN
    UPDATE pointnin_afc.company
    SET
    name=p_name,
    phone=p_phone,
    email=p_email,
    address=p_address,
    description=p_description,
    image=p_image,
    outstandingamount=p_outstandingamount,
    status=p_status,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE company_id=p_company_id;
    SET p_spstatus=1;
  ELSE
    SET p_spstatus=0;
  END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_COUNTRY` (IN `p_country_id` INT(11), IN `p_iso` CHAR(2), IN `p_name` VARCHAR(80), IN `p_currency_code` CHAR(3), IN `p_phonecode` INT(5), IN `p_zone_name` VARCHAR(35), IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR sqlexception
BEGIN
SET p_spstatus=0;
ROLLBACK;
END;
START TRANSACTION;
    SELECT COUNT(country_id) INTO IsFound FROM pointnin_afc.country WHERE name=p_name AND country_id!=p_country_id;
    IF IsFound=0 THEN
        UPDATE pointnin_afc.country
        SET
        iso=p_iso,
        name=p_name,
        currency_code=p_currency_code,
        phonecode=p_phonecode,
        zone_name=p_zone_name,
        status=p_status,
        modifiedon=NOW()
        WHERE country_id=p_country_id;
    	SET p_spstatus=1;
    ELSE
        SET p_spstatus=0;
    END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_LOCATION` (IN `p_location_id` INT(11), IN `p_country_id` INT(11), IN `p_city_id` INT(11), IN `p_route_id` INT(11), IN `p_location_name` VARCHAR(150), IN `p_address` VARCHAR(255), IN `p_latitude` VARCHAR(15), IN `p_longitude` VARCHAR(15), IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
SET p_spstatus=0;
ROLLBACK;
END;
START TRANSACTION;
	SELECT COUNT(location_id) INTO IsFound FROM pointnin_afc.location WHERE (location_name=p_location_name AND country_id=p_country_id AND city_id=p_city_id AND location_id!=p_location_id);
	IF IsFound=0 THEN
        UPDATE pointnin_afc.location
        SET
        country_id=p_country_id,
        city_id=p_city_id,
        route_id=p_route_id,
        location_name=p_location_name,
        address=p_address,
        latitude=p_latitude,
        longitude=p_longitude,
        status=p_status,
        modifiedby=p_modifiedby,
        modifiedon=NOW()
        WHERE location_id=p_location_id;
    	SET p_spstatus=1;
	ELSE
		SET p_spstatus=0;
	END IF;
COMMIT;    
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_PRODUCT` (IN `p_product_id` BIGINT(11), IN `p_warehouse_id` INT(11), IN `p_category_id` INT(11), IN `p_product_name` VARCHAR(255), IN `p_configuration` VARCHAR(255), IN `p_short_desc` VARCHAR(255), IN `p_qty` DOUBLE, IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(11))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
SET p_spstatus=0;
ROLLBACK;
END;
START TRANSACTION;
    SELECT COUNT(product_id) INTO IsFound FROM pointnin_afc.product WHERE product_name=p_product_name AND product_id!=p_product_id;
    IF IsFound=0 THEN
        UPDATE pointnin_afc.product
        SET
        warehouse_id=p_warehouse_id,
        category_id=p_category_id,
        product_name=p_product_name,
        configuration=p_configuration,
        short_desc=p_short_desc,
        qty=p_qty,
        status=p_status,
        modifiedby=p_modifiedby,
        modifiedon=NOW()
        WHERE product_id=p_product_id;
    	SET p_spstatus=1;
    ELSE
        SET p_spstatus=0;
    END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_PRODUCT_REQUEST` (IN `p_up_id` CHAR(36), IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
START TRANSACTION;
  SELECT COUNT(up_id) INTO IsFound FROM pointnin_afc.user_products WHERE up_id=p_up_id AND status=p_status;
  IF IsFound=0 THEN
    UPDATE pointnin_afc.user_products
    SET
    status=p_status,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE up_id=p_up_id;
	
    SET p_spstatus=1;
  ELSE
    SET p_spstatus=0;
  END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_PRODUCT_REQUEST_ITEM` (IN `p_up_id` CHAR(36), IN `p_upd_id` CHAR(36), IN `p_actualqty` INT(11), IN `p_adjustqty` INT(11), IN `p_requested_qty` INT(11), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
    UPDATE pointnin_afc.user_products_details
    SET
    qty=p_adjustqty,
	requested_qty=p_requested_qty,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE upd_id=p_upd_id;
	
	UPDATE pointnin_afc.user_products
    SET
    total_qty=total_qty-p_actualqty,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE up_id=p_up_id;
	
	UPDATE pointnin_afc.user_products
    SET
    total_qty=total_qty+p_adjustqty,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE up_id=p_up_id;
	
    SET p_spstatus=1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_PURCHASE` (IN `p_purchase_id` INT(11), IN `p_order_code` VARCHAR(50), IN `p_supplier_id` INT(11), IN `p_unit_price` DOUBLE, IN `p_sales_price` DOUBLE, IN `p_bulk_price` DOUBLE, IN `p_bagging_price` DOUBLE, IN `p_config_id` INT(11), IN `p_packing_id` INT(11), IN `p_purchase_date` DATE, IN `p_description` VARCHAR(250), IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
  SELECT COUNT(purchase_id) INTO IsFound FROM pointnin_afc.purchase WHERE order_code=p_order_code AND purchase_id != p_purchase_id;
  IF IsFound=0 THEN
    UPDATE pointnin_afc.purchase
    SET
    order_code=p_order_code,
    supplier_id=p_supplier_id,
    unit_price=p_unit_price,
    sales_price=p_sales_price,
    bulk_price=p_bulk_price,
    bagging_price=p_bagging_price,
    config_id=p_config_id,
	packing_id=p_packing_id,
	purchase_date=p_purchase_date,
	description=p_description,
    status=p_status,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE purchase_id=p_purchase_id;
    SET p_spstatus=1;
  ELSE
    SET p_spstatus=0;
  END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_ROUTE` (IN `p_route_id` INT(11), IN `p_name` VARCHAR(150), IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
SET p_spstatus=0;
ROLLBACK;
END;
START TRANSACTION;
  SELECT COUNT(route_id) INTO IsFound FROM pointnin_afc.route WHERE name=p_name AND route_id!=p_route_id;
  IF IsFound=0 THEN
    UPDATE pointnin_afc.route
    SET
    name=p_name,
    status=p_status,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE route_id=p_route_id;
    SET p_spstatus=1;
  ELSE
    SET p_spstatus=0;
  END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_SERVICE_ROUTINE` (IN `p_stand_id` INT(11), IN `p_serviced_every` INT(11), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
START TRANSACTION;
    UPDATE pointnin_afc.stand
    SET
    serviced_every=p_serviced_every,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE stand_id=p_stand_id;
    SET p_spstatus=1;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_SERVICE_ROUTINE_CONFIG` (IN `p_code` INT(11), IN `p_serviced_every` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
START TRANSACTION;
    UPDATE pointnin_afc.configuration
    SET
    value1=p_serviced_every
    WHERE code=p_code AND type='SER_ROU';
    SET p_spstatus=1;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_SLAB` (IN `p_id` INT(11), IN `p_name` VARCHAR(150), IN `p_description` VARCHAR(150), IN `p_start_time` TIME, IN `p_end_time` TIME, IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
SELECT COUNT(id) INTO IsFound FROM pointnin_afc.slab WHERE id != p_id AND start_time=p_start_time AND end_time=p_end_time;
IF IsFound=0 THEN
    UPDATE pointnin_afc.slab
    SET
    name=p_name,
    description=p_description,
    start_time=p_start_time,
    end_time=p_end_time,
    status=p_status,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE id=p_id;
    SET p_spstatus=1;
ELSE
    SET p_spstatus=0;
END IF;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_SPECIAL_REQUEST` (IN `p_id` INT(11), IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
START TRANSACTION;
  SELECT COUNT(id) INTO IsFound FROM pointnin_afc.special_request WHERE id=p_id AND status=p_status;
  IF IsFound=0 THEN
    UPDATE pointnin_afc.special_request
    SET
    status=p_status,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE id=p_id;
    SET p_spstatus=1;
  ELSE
    SET p_spstatus=0;
  END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_STAND` (IN `p_stand_id` INT(11), IN `p_name` VARCHAR(255), IN `p_code` VARCHAR(100), IN `p_barcode` VARCHAR(13), IN `p_stand_type_id` INT(11), IN `p_from_warehouse_id` INT(11), IN `p_to_warehouse_id` INT(11), IN `p_company_id` INT(11), IN `p_location_id` INT(11), IN `p_route_id` INT(11), IN `p_service_notes` VARCHAR(255), IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
SET p_spstatus=0;
ROLLBACK;
END;
START TRANSACTION;
  SELECT COUNT(stand_id) INTO IsFound FROM pointnin_afc.stand WHERE name=p_name AND stand_id!=p_stand_id;
  IF IsFound=0 THEN
    UPDATE pointnin_afc.stand
    SET
    name=p_name,
    code=p_code,
    barcode=p_barcode,
    stand_type_id=p_stand_type_id,
    from_warehouse_id=p_from_warehouse_id,
    to_warehouse_id=p_to_warehouse_id,
    company_id=p_company_id,
    location_id=p_location_id,
    route_id=p_route_id,
    service_notes=p_service_notes,
    status=p_status,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE stand_id=p_stand_id;
    SET p_spstatus=1;
  ELSE
    SET p_spstatus=0;
  END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_STANDTYPE` (IN `p_stand_type_id` INT(11), IN `p_name` VARCHAR(150), IN `p_description` VARCHAR(255), IN `p_capacity` DOUBLE, IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
SET p_spstatus=0;
ROLLBACK;
END;
START TRANSACTION;
  SELECT COUNT(stand_type_id) INTO IsFound FROM pointnin_afc.stand_type WHERE name=p_name AND stand_type_id!=p_stand_type_id;
  IF IsFound=0 THEN
    UPDATE pointnin_afc.stand_type
    SET
    name=p_name,
    description=p_description,
    capacity=p_capacity,
    status=p_status,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE stand_type_id=p_stand_type_id;
    SET p_spstatus=1;
  ELSE
    SET p_spstatus=0;
  END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_STAND_REQUEST` (IN `p_us_id` CHAR(36), IN `p_barcode` VARCHAR(13), IN `p_status` TINYINT(2), IN `p_user_id` INT(11), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
DECLARE IsFound1 INT(1);
DECLARE IsFound2 INT(1);
DECLARE i_stand_id INT(11);
START TRANSACTION;
  SELECT COUNT(us_id) INTO IsFound FROM pointnin_afc.user_stands WHERE us_id=p_us_id AND status=p_status;
  IF IsFound=0 THEN
	SELECT COUNT(S.stand_id), S.stand_id INTO IsFound1, i_stand_id FROM pointnin_afc.stand AS S WHERE S.barcode = p_barcode;
	IF IsFound1>0 THEN
	SELECT COUNT(S.stand_id) INTO IsFound2 FROM pointnin_afc.stand AS S WHERE S.stand_id = i_stand_id AND S.usage_status=0 AND S.fulfil_status=0 AND S.allocated=0;
		IF IsFound2>0 THEN
			UPDATE pointnin_afc.user_stands
			SET
			status=p_status,
			modifiedby=p_modifiedby,
			modifiedon=NOW()
			WHERE us_id=p_us_id;
			
			UPDATE pointnin_afc.user_stands_details
			SET
			stand_id=i_stand_id,
			status=p_status,
			modifiedby=p_modifiedby,
			modifiedon=NOW()
			WHERE us_id=p_us_id;

			UPDATE pointnin_afc.stand
			SET
			allocated=1,
			modifiedby=p_user_id
			WHERE stand_id=i_stand_id;
		
			SELECT COUNT(S.id) INTO IsFound FROM pointnin_afc.user_stands_stock AS S WHERE S.user_id = p_user_id AND S.stand_id=i_stand_id;
			IF IsFound=0 THEN
			  INSERT INTO pointnin_afc.user_stands_stock
			  (user_id,
			  stand_id,
			  status,
			  createdby,
			  modifiedby,
			  createdon,
			  modifiedon)
			  VALUES
			  (p_user_id,
			  i_stand_id,
			  p_status,
			  p_user_id,
			  p_modifiedby,
			  NOW(),
			  NOW());
			ELSE
			  UPDATE pointnin_afc.user_stands_stock
			  SET
			  status=1,
			  modifiedby=p_modifiedby
			  WHERE user_id=p_user_id AND stand_id=i_stand_id AND status=2;    
			END IF;
			SELECT 1 INTO p_spstatus;
		ELSE
			SELECT 2 INTO p_spstatus;
		END IF;
	ELSE
		SELECT 3 INTO p_spstatus;
	END IF;	
  ELSE
    SELECT 0 INTO p_spstatus;
  END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_SUPPLIER` (IN `p_supplier_id` INT(11), IN `p_name` VARCHAR(100), IN `p_phone` VARCHAR(15), IN `p_email` VARCHAR(150), IN `p_address` VARCHAR(255), IN `p_location_id` INT(11), IN `p_description` VARCHAR(255), IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
SET p_spstatus=0;
ROLLBACK;
END;
START TRANSACTION;
  SELECT COUNT(supplier_id) INTO IsFound FROM pointnin_afc.supplier WHERE name=p_name AND supplier_id!=p_supplier_id;
  IF IsFound=0 THEN
    UPDATE pointnin_afc.supplier
    SET
    name=p_name,
    phone=p_phone,
    email=p_email,
    address=p_address,
    description=p_description,
    location_id=p_location_id,
    status=p_status,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE supplier_id=p_supplier_id;
    SET p_spstatus=1;
  ELSE
    SET p_spstatus=0;
  END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_USER` (IN `p_user_id` INT(11), IN `p_warehouse_id` INT(11), IN `p_route_id` INT(11), IN `p_password` VARCHAR(150), IN `p_empcode` INT(11), IN `p_email` VARCHAR(150), IN `p_mobile` VARCHAR(12), IN `p_firstname` VARCHAR(150), IN `p_lastname` VARCHAR(150), IN `p_status` TINYINT(2), IN `p_device` TINYINT(2), IN `p_role` TINYINT(2), IN `p_registered_type` TINYINT(2), IN `p_profile_image` VARCHAR(255), IN `p_profile_image_type` TINYINT(2), IN `p_wh_distance` DOUBLE, IN `p_veh_id` INT(11), IN `p_wage_km` DOUBLE, IN `p_wage_hour` DOUBLE, IN `p_wage_per_stand` DOUBLE, IN `p_wage_new_stand` DOUBLE, IN `p_commission` DOUBLE, IN `p_imei` VARCHAR(255), IN `p_gcmkey` TEXT, IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
SELECT COUNT(user_id) INTO IsFound FROM pointnin_afc.users WHERE email = p_email AND user_id != p_user_id;
IF IsFound=0 THEN
  UPDATE pointnin_afc.users
  SET
  password=p_password,
  empcode=p_empcode,
  email=p_email,
  mobile=p_mobile,
  email=p_email,
  firstname=p_firstname,
  lastname=p_lastname,
  status=p_status,
  device=p_device,
  role=p_role,
  registered_type=p_registered_type,
  profile_image=p_profile_image,
  profile_image_type=p_profile_image_type,
  wh_distance=p_wh_distance,
  veh_id=p_veh_id,
  wage_km=p_wage_km,
  wage_hour=p_wage_hour,
  wage_per_stand=p_wage_per_stand,
  wage_new_stand=p_wage_new_stand,
  commission=p_commission,
  warehouse_id=p_warehouse_id,
  route_id=p_route_id,
  imei=p_imei,
  gcmkey=p_gcmkey,
  modifiedby=p_modifiedby,
  modifiedon=NOW()
  WHERE user_id=p_user_id;
  SET p_spstatus=1;
ELSE
  SET p_spstatus=0;
END IF;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_USER_MAPPING` (IN `p_user_id` INT(11), IN `p_brand_id` INT(11), IN `p_fsm_user_id` INT(11), IN `p_country_id` INT(11), IN `p_city_id` INT(11), IN `p_location_id` INT(11), IN `p_retailer_id` INT(11), IN `p_slab_id` INT(11), IN `p_ir` TINYINT(2), IN `p_rlc` INT(11), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
    UPDATE pointnin_afc.users
    SET
    brand_id=p_brand_id,
    fsm_user_id=p_fsm_user_id,
    country_id=p_country_id,
    city_id=p_city_id,
    location_id=p_location_id,
    retailer_id=p_retailer_id,
    slab_id=p_slab_id,
    ir=p_ir,
    rlc=p_rlc,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE user_id=p_user_id;
    
    SET p_spstatus=1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_USER_STANDS_ROUTE` (IN `p_user_routes_id` INT(11), IN `p_stand_id` INT(11), IN `p_fromstatus` TINYINT(2), IN `p_tostatus` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
  SET p_spstatus=0;
  SELECT COUNT(user_routes_id) INTO IsFound FROM pointnin_afc.user_routes WHERE user_routes_id=p_user_routes_id AND status=p_fromstatus;
  IF IsFound>0 THEN
    UPDATE pointnin_afc.user_routes
    SET
    status=p_tostatus,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE user_routes_id=p_user_routes_id;
    
    UPDATE pointnin_afc.stand SET usage_status=p_tostatus, modifiedby=p_modifiedby, modifiedon=NOW() WHERE stand_id=p_stand_id;
    SET p_spstatus=1;
  ELSE
    SET p_spstatus=0;
  END IF;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_USER_STANDS_ROUTES` (IN `p_user_routes_id` INT(11), IN `p_stand_id` INT(11), IN `p_fromstatus` TINYINT(2), IN `p_tostatus` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
  SET p_spstatus=0;
  SELECT COUNT(user_routes_id) INTO IsFound FROM pointnin_afc.user_routes WHERE user_routes_id=p_user_routes_id AND status=p_fromstatus;
  IF IsFound>0 THEN
    UPDATE pointnin_afc.user_routes
    SET
    status=p_tostatus,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE user_routes_id=p_user_routes_id;
    
    UPDATE pointnin_afc.stand SET usage_status=p_tostatus, modifiedby=p_modifiedby, modifiedon=NOW() WHERE stand_id=p_stand_id;
    SET p_spstatus=1;
  ELSE
    SET p_spstatus=0;
  END IF;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_USER_STANDS_ROUTES_POSITION` (IN `p_position` INT(11), IN `p_user_id` INT(11), IN `p_route_id` INT(11), IN `p_location_id` INT(11), IN `p_company_id` INT(11), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
	UPDATE pointnin_afc.user_routes
	SET
	position=p_position,
	modifiedby=p_modifiedby,
	modifiedon=NOW()
	WHERE user_id=p_user_id AND route_id=p_route_id AND location_id=p_location_id AND company_id=p_company_id;
	
	UPDATE pointnin_afc.stand
	SET
	position=p_position,
	modifiedby=p_modifiedby,
	modifiedon=NOW()
	WHERE route_id=p_route_id AND location_id=p_location_id AND company_id=p_company_id;
	SET p_spstatus=1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_USER_STAND_SERVICE_ON` (IN `p_stand_id` INT(11), IN `p_serviced_date` DATETIME, IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
    UPDATE pointnin_afc.stand
    SET
	serviced_date=p_serviced_date,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE stand_id=p_stand_id;
	
    SET p_spstatus=1;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_VEHICLE` (IN `p_vehicle_id` INT(11), IN `p_name` VARCHAR(100), IN `p_user_id` INT(11), IN `p_type` TINYINT(2), IN `p_capacity` INT(11), IN `p_usage_status` TINYINT(2), IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
  SELECT COUNT(vehicle_id) INTO IsFound FROM pointnin_afc.vehicle WHERE name=p_name AND vehicle_id!=p_vehicle_id;
  IF IsFound=0 THEN
    UPDATE pointnin_afc.vehicle
    SET
    name=p_name,
    user_id=p_user_id,
    type=p_type,
    capacity=p_capacity,
    usage_status=p_usage_status,
    status=p_status,
    modifiedby=p_modifiedby,
    modifiedon=NOW()
    WHERE vehicle_id=p_vehicle_id;
    SET p_spstatus=1;
  ELSE
    SET p_spstatus=0;
  END IF;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `UPDATE_WAREHOUSE` (IN `p_warehouse_id` INT(11), IN `p_name` VARCHAR(150), IN `p_barcode` VARCHAR(8), IN `p_description` VARCHAR(255), IN `p_location_id` INT(11), IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))  BEGIN
DECLARE IsFound INT(1);
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
SET p_spstatus=0;
ROLLBACK;
END;
START TRANSACTION;
    SELECT COUNT(warehouse_id) INTO IsFound FROM pointnin_afc.warehouse WHERE name=p_name AND warehouse_id!=p_warehouse_id;
    IF IsFound=0 THEN
        UPDATE pointnin_afc.warehouse
        SET
        name=p_name,
		barcode=p_barcode,
        description=p_description,
        location_id=p_location_id,
        status=p_status,
        modifiedby=p_modifiedby,
        modifiedon=NOW()
        WHERE warehouse_id=p_warehouse_id;
    	SET p_spstatus=1;
    ELSE
        SET p_spstatus=0;
    END IF;
COMMIT;
END$$

CREATE DEFINER=`pointnine9`@`localhost` PROCEDURE `VALIDATE_USER` (IN `p_username` VARCHAR(50), IN `p_password` VARCHAR(255))  BEGIN
SELECT
A.user_id,
A.warehouse_id,
A.username,
A.email,
A.mobile,
A.firstname,
A.lastname,
A.role,
A.profile_image,
A.profile_image_type
FROM pointnin_afc.users AS A
WHERE A.username=p_username AND A.password=p_password AND A.password !='' AND A.password IS NOT NULL AND A.status=1;
END$$

DELIMITER ;