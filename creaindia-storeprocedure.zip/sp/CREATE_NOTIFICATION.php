DELIMITER $$
CREATE PROCEDURE `CREATE_NOTIFICATION`(IN `p_type` TINYINT(2), IN `p_title` VARCHAR(255), IN `p_url` VARCHAR(255), IN `p_reference_id` INT(11), IN `p_value_1` VARCHAR(255), IN `p_value_2` VARCHAR(255), IN `p_value_3` VARCHAR(255), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))
BEGIN
	INSERT INTO creaindia.notification
	(type,
	title,
	url,
	reference_id,
	value_1,
	value_2,
	value_3,
	status,
	createdby,
	createdon)
	VALUES
	(p_type,
	p_title,
	p_url,
	p_reference_id,
	p_value_1,
	p_value_2,
	p_value_3,
	p_status,
	p_createdby,
	NOW());
	SELECT LAST_INSERT_ID() INTO p_id;
END$$
DELIMITER ;