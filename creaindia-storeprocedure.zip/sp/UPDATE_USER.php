DELIMITER $$
CREATE PROCEDURE `UPDATE_USER`(IN `p_user_id` INT(11), IN `p_validity_end` DATE, IN `p_validity_period` INT(11), IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))
BEGIN
  UPDATE creaindia.users
  SET
  validity_end=p_validity_end,
  validity_period=p_validity_period,
  status=p_status,
  modifiedby=p_modifiedby,
  modifiedon=NOW()
  WHERE user_id=p_user_id;
  SET p_spstatus=1;
END$$
DELIMITER ;