DELIMITER $$
CREATE PROCEDURE `UPDATE_NOTIFICATION_VISITED`(IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))
BEGIN
  UPDATE creaindia.notification
  SET
  visited=1,
  modifiedby=p_modifiedby,
  modifiedon=NOW()
  WHERE visited=0;
  SET p_spstatus=1;
END$$
DELIMITER ;