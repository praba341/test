DELIMITER $$
CREATE PROCEDURE `GET_PROPERTIES_SEARCH`(IN `p_property_type` VARCHAR(100), IN `p_location_id` INT(11), IN `p_type_id` INT(11), IN `p_bhk` DOUBLE, IN `p_price_from` DOUBLE, IN `p_price_to` DOUBLE, IN `p_limit_from` INT(11), IN `p_limit_to` INT(11))
BEGIN
SET @d_limit_from = p_limit_from;
SET @d_limit_to = p_limit_to;
IF p_location_id IS NULL THEN
    SET @where1 = CONCAT(" WHERE FIND_IN_SET(A.property_type, '",p_property_type,"')");
ELSE
	SET @where1 = CONCAT(" WHERE FIND_IN_SET(A.property_type, '",p_property_type,"') AND A.location='",p_location_id,"'");
END IF;

IF p_type_id IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
	SET @where2 = CONCAT(" AND A.type_id='",p_type_id,"'");
END IF;

IF p_price_from IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
	SET @where3 = CONCAT(" AND (A.price >='",p_price_from,"') AND (A.price <='",p_price_to,"')");
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @SQLQuery = "
SELECT 
A.id,
A.name,
A.user_id,
A.slugurl,
A.rera_number,
A.bhk,
A.price,
A.price_word,
A.comments,
A.image,
A.contact_number,
(SELECT U.location_name FROM crea.location as U WHERE U.location_id=A.location) as location_name,
A.zip,
(SELECT U.type_name FROM crea.property_type as U WHERE U.type_id=A.type_id) as type_name,
(SELECT U.type_value_name FROM crea.property_type_values as U WHERE U.type_value_id=A.type_value_id) as type_value_name,
A.status
FROM crea.properties AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.name ASC LIMIT ?, ?');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE STMT USING @d_limit_from, @d_limit_to;
DEALLOCATE PREPARE stmt;
END$$
DELIMITER ;