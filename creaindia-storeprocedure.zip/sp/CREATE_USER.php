DELIMITER $$
CREATE PROCEDURE `CREATE_USER`(IN `p_username` VARCHAR(50), IN `p_password` VARCHAR(150), IN `p_pass` VARCHAR(255), IN `p_email` VARCHAR(150), IN `p_mobile` VARCHAR(12), IN `p_firstname` VARCHAR(150), IN `p_status` TINYINT(2), IN `p_role` TINYINT(2), IN `p_org` VARCHAR(150), IN `p_rera_number` VARCHAR(100), IN `p_register_type` TINYINT(2), IN `p_message` VARCHAR(255), IN `p_validity_start` DATE, IN `p_validity_end` DATE, OUT `p_id` INT(11))
BEGIN
DECLARE IsFound INT(1);
SELECT COUNT(user_id) INTO IsFound FROM creaindia.users WHERE username = p_username;
IF IsFound=0 THEN
    INSERT INTO creaindia.users
    (username,
    password,
	pass,
    email,
    mobile,
    firstname,
	org,
	rera_number,
	register_type,
	message,
    status,
    role,
	validity_start,
	validity_end,
    createdon,
    modifiedon)
    VALUES
    (p_username,
    p_password,
	p_pass,
    p_email,
    p_mobile,
    p_firstname,
	p_org,
	p_rera_number,
	p_register_type,
	p_message,
    p_status,
    p_role,
	p_validity_start,
	p_validity_end,
    NOW(),
    NOW());
    SELECT LAST_INSERT_ID() INTO p_id;
ELSE
    SELECT 0 INTO p_id;
END IF;
END$$
DELIMITER ;