DELIMITER $$
CREATE PROCEDURE `GET_PROPERTIES_DETAILS_EDIT`(IN `p_id` INT(11))
BEGIN

SELECT 
A.id,
A.property_type,
A.name,
A.user_id,
A.type,
A.slugurl,
A.rera_number,
A.bhk,
A.amenities,
A.price,
A.price_word,
A.area,
A.tolet,
A.floor,
A.parking,
A.delivery_date,
A.contact_number,
A.location,
A.zip,
A.image,
A.type_id,
A.type_value_id,
A.type_value_parent_id,
A.file1,
A.file2,
A.comments,
A.status,
A.createdby,
A.modifiedby,
A.createdon,
A.modifiedon
FROM crea.properties AS A
WHERE A.id=p_id;

END$$
DELIMITER ;