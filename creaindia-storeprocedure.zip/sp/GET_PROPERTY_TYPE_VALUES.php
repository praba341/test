DELIMITER $$
CREATE PROCEDURE `GET_PROPERTY_TYPE_VALUES`(IN `p_type_id` INT(11), IN `p_parent` INT(11))
BEGIN

IF p_type_id IS NULL THEN
    SET @whereQuery = CONCAT("");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.type_id='",p_type_id,"' AND A.parent='",p_parent,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.type_value_id,
A.type_value_name,
A.type_id
FROM crea.property_type_values AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.position ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$
DELIMITER ;