DELIMITER $$
CREATE PROCEDURE `GET_EVENT_DETAILS_HOME`(IN `p_status` TINYINT(2))
BEGIN

SELECT 
A.id,
A.name,
A.slugurl,
A.place,
A.datetime,
A.image,
A.file1,
A.description,
A.status
FROM crea.event AS A
WHERE A.status=p_status AND A.active_home=1 LIMIT 1;

END$$
DELIMITER ;