DELIMITER $$
CREATE PROCEDURE `UPDATE_NOTIFY_REGISTER`(IN `p_id` INT(11), IN `p_user_id` INT(11), IN `p_from_status` TINYINT(2), IN `p_to_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))
BEGIN
DECLARE IsFound INT(1);
IF p_type=2 THEN
	SELECT COUNT(user_id) INTO IsFound FROM creaindia.users WHERE status=p_from_status AND user_id=p_user_id;
	IF IsFound>0 THEN
		UPDATE creaindia.users
		SET
		status=p_to_status,
		modifiedby=p_modifiedby,
		modifiedon=NOW()
		WHERE user_id=p_user_id;
		SET p_spstatus=1;
	ELSE
		SET p_spstatus=0;
	END IF;
END IF;
UPDATE creaindia.notification
SET
status=2,
modifiedby=p_modifiedby,
modifiedon=NOW()
WHERE id=p_id;  
END$$
DELIMITER ;