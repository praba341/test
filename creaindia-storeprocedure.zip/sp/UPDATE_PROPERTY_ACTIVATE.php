DELIMITER $$
CREATE PROCEDURE `UPDATE_PROPERTY_ACTIVATE`(IN `p_id` INT(11), IN `p_end_date` DATE, IN `p_activated` INT(11), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))
BEGIN
DECLARE IsFound INT(1);
SELECT COUNT(id) INTO IsFound FROM creaindia.properties WHERE activated=0 AND id=p_id;
IF IsFound>0 THEN
  UPDATE creaindia.properties
  SET
  end_date=p_end_date,
  activated=p_activated,
  modifiedby=p_modifiedby,
  modifiedon=NOW()
  WHERE id=p_id;
  SET p_spstatus=1;
ELSE
	SET p_spstatus=0;
END IF;	
END$$
DELIMITER ;