DELIMITER $$
CREATE PROCEDURE `GET_PROPERTIES_HANDLE_SEARCH`(IN `p_property_type` VARCHAR(100), IN `p_location_id` INT(11), IN `p_limit_from` INT(11), IN `p_limit_to` INT(11))
BEGIN
SET @d_limit_from = p_limit_from;
SET @d_limit_to = p_limit_to;
IF p_location_id IS NULL THEN
    SET @where = CONCAT(" WHERE FIND_IN_SET(A.property_type, '",p_property_type,"')");
ELSE
	SET @where = CONCAT(" WHERE FIND_IN_SET(A.property_type, '",p_property_type,"') AND A.location='",p_location_id,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.id,
A.name,
A.user_id,
A.slugurl,
A.rera_number,
A.bhk,
A.price,
A.price_word,
A.comments,
A.image,
A.contact_number,
(SELECT U.location_name FROM crea.location as U WHERE U.location_id=A.location) as location_name,
A.zip,
A.status
FROM crea.properties AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.name ASC LIMIT ?, ?');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE STMT USING @d_limit_from, @d_limit_to;
DEALLOCATE PREPARE stmt;
END$$
DELIMITER ;