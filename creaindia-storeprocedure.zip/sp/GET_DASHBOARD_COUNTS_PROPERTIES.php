DELIMITER $$
CREATE PROCEDURE `GET_DASHBOARD_COUNTS_PROPERTIES`(IN `p_type` TINYINT(2))
BEGIN

SELECT 
COUNT(id) as property_count,
(SELECT COUNT(M.id) FROM creaindia.properties as M WHERE M.property_type=1) as popular_count,
(SELECT COUNT(N.id) FROM creaindia.properties as N WHERE N.property_type=2) as available_count,
(SELECT COUNT(O.id) FROM creaindia.properties as O WHERE O.property_type=3) as requirement_count,
(SELECT COUNT(P.id) FROM creaindia.properties as P WHERE P.property_type=4) as premium_count
FROM creaindia.properties AS A;

END$$
DELIMITER ;