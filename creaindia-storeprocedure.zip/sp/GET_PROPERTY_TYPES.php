DELIMITER $$
CREATE PROCEDURE `GET_PROPERTY_TYPES`(IN `p_status` TINYINT(2))
BEGIN
SELECT 
A.type_id,
A.type_name
FROM crea.property_type AS A
WHERE A.status=p_status;
END$$
DELIMITER ;