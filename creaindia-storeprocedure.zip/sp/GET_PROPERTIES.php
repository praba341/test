DELIMITER $$
CREATE PROCEDURE `GET_PROPERTIES`(IN `p_user_id` INT(11), IN `p_type` TINYINT(2), IN `p_status` TINYINT(2))
BEGIN

IF p_status IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.id IS NOT NULL");
ELSE
	SET @where1 = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

IF p_type IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
	SET @where2 = CONCAT(" AND A.property_type='",p_type,"'");
END IF;

IF p_user_id IS NULL THEN
    SET @where3 = CONCAT("");
ELSE
	SET @where3 = CONCAT(" AND A.user_id='",p_user_id,"'");
END IF;

SET @where = CONCAT(@where1,@where2);
SET @where = CONCAT(@where,@where3);

SET @SQLQuery = "
SELECT 
A.id,
A.name,
A.user_id,
A.type,
A.property_type,
A.slugurl,
A.rera_number,
A.bhk,
A.price,
A.price_word,
A.comments,
A.image,
A.contact_number,
(SELECT U.type_name FROM creaindia.property_type as U WHERE U.type_id=A.type_id) as type_name,
(SELECT U.location_name FROM creaindia.location as U WHERE U.location_id=A.location) as location_name,
(SELECT U.firstname FROM creaindia.users as U WHERE U.user_id=A.user_id) as firstname,
A.zip,
A.start_date,
A.end_date,
A.activated,
A.status,
A.publish,
A.createdby,
A.modifiedby,
A.createdon,
A.modifiedon
FROM creaindia.properties AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$
DELIMITER ;