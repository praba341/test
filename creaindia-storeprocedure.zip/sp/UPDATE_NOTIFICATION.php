DELIMITER $$
CREATE PROCEDURE `UPDATE_NOTIFICATION`(IN `p_type` TINYINT(2), IN `p_id` INT(11), IN `p_reference_id` INT(11), IN `p_status` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))
BEGIN
DECLARE IsFound INT(1);
IF p_type=1 THEN
	UPDATE creaindia.properties
	SET
	publish=p_status,
	modifiedby=p_modifiedby,
	modifiedon=NOW()
	WHERE id=p_reference_id;
	SET p_spstatus=1;
ELSEIF p_type=2 THEN
	UPDATE creaindia.users
	SET
	status=p_status,
	modifiedby=p_modifiedby,
	modifiedon=NOW()
	WHERE user_id=p_reference_id;
	SET p_spstatus=1;
END IF;
UPDATE creaindia.notification
SET
status=2,
approved_status=p_status,
modifiedby=p_modifiedby,
modifiedon=NOW()
WHERE id=p_id;  
END$$
DELIMITER ;