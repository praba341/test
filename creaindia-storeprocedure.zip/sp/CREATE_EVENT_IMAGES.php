DELIMITER $$
CREATE PROCEDURE `CREATE_EVENT_IMAGES`(IN `p_type` TINYINT(2), IN `p_reference_id` INT(11), IN `p_name` VARCHAR(150), IN `p_image` VARCHAR(150), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))
BEGIN
  INSERT INTO crea.event_images
  (type,
  reference_id,
  name,
  image,
  status,
  createdby,
  modifiedby,
  createdon,
  modifiedon)
  VALUES
  (p_type,
  p_reference_id,
  p_name,
  p_image,
  p_status,
  p_createdby,
  p_createdby,
  NOW(),
  NOW());
  SELECT LAST_INSERT_ID() INTO p_id;
END$$
DELIMITER ;