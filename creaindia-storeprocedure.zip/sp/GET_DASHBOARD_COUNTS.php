DELIMITER $$
CREATE PROCEDURE `GET_DASHBOARD_COUNTS`(IN `p_type` TINYINT(2))
BEGIN

SELECT 
COUNT(id) as property_count,
(SELECT COUNT(M.user_id) FROM creaindia.users as M) as user_count,
(SELECT COUNT(N.id) FROM creaindia.event as N WHERE N.type=1) as event_count,
(SELECT COUNT(O.id) FROM creaindia.lead as O) as lead_count
FROM creaindia.properties AS A;

END$$
DELIMITER ;