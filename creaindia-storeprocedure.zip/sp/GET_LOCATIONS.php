DELIMITER $$
CREATE PROCEDURE `GET_LOCATIONS`(IN `p_status` TINYINT(2))
BEGIN

IF p_status IS NULL THEN
    SET @where = CONCAT("");
ELSE
	SET @where = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.location_id,
A.location_name
FROM crea.location AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.location_name ASC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$
DELIMITER ;