DELIMITER $$
CREATE PROCEDURE `GET_PROPERTY_IMAGES`(IN `p_reference_id` INT(11))
BEGIN

SELECT 
A.id,
A.name,
A.image
FROM crea.property_images AS A
WHERE A.reference_id=p_reference_id;

END$$
DELIMITER ;