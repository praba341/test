DELIMITER $$
CREATE PROCEDURE `CREATE_EVENT_ITEMS`(IN `p_type` TINYINT(2), IN `p_reference_id` INT(11), IN `p_title` VARCHAR(150), IN `p_value` VARCHAR(150), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))
BEGIN
  INSERT INTO crea.event_items
  (type,
  reference_id,
  title,
  value,
  status,
  createdby,
  createdon)
  VALUES
  (p_type,
  p_reference_id,
  p_title,
  p_value,
  p_status,
  p_createdby,
  NOW());
  SELECT LAST_INSERT_ID() INTO p_id;
END$$
DELIMITER ;