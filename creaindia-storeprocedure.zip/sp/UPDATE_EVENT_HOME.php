DELIMITER $$
CREATE PROCEDURE `UPDATE_EVENT_HOME`(IN `p_id` INT(11), IN `p_active_home` TINYINT(2), IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))
BEGIN
DECLARE IsFound INT(1);
SELECT COUNT(id) INTO IsFound FROM creaindia.event WHERE (active_home=0 OR active_home IS NULL) AND id=p_id;
IF IsFound>0 THEN
  UPDATE creaindia.event
  SET
  active_home=p_active_home,
  modifiedby=p_modifiedby,
  modifiedon=NOW()
  WHERE id=p_id;
  
  UPDATE creaindia.event
  SET
  active_home=0
  WHERE id!=p_id;
  SET p_spstatus=1;
ELSE
	SET p_spstatus=0;
END IF;	
END$$
DELIMITER ;