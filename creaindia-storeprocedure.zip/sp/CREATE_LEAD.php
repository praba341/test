DELIMITER $$
CREATE PROCEDURE `CREATE_LEAD`(IN `p_reference_id` INT(11), IN `p_name` VARCHAR(255), IN `p_mobile` VARCHAR(15), IN `p_email` VARCHAR(100), IN `p_location` VARCHAR(255), IN `p_comments` VARCHAR(255), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))
BEGIN
	INSERT INTO creaindia.lead
	(reference_id,
	name,
	mobile,
	email,
	location,
	comments,
	status,
	createdby,
	createdon)
	VALUES
	(p_reference_id,
	p_name,
	p_mobile,
	p_email,
	p_location,
	p_comments,
	p_status,
	p_createdby,
	NOW());
	SELECT LAST_INSERT_ID() INTO p_id;
END$$
DELIMITER ;