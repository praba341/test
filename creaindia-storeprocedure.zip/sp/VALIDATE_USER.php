DELIMITER $$
CREATE PROCEDURE `VALIDATE_USER`(IN `p_role` INT(11), IN `p_username` VARCHAR(50), IN `p_password` VARCHAR(255))
BEGIN
SELECT
A.user_id,
A.username,
A.email,
A.mobile,
A.firstname,
A.lastname,
A.role,
A.profile_image,
A.profile_image_type
FROM creaindia.users AS A
WHERE A.role = p_role AND A.username=p_username AND A.password=p_password AND A.password !='' AND A.password IS NOT NULL AND A.status=1;
END$$
DELIMITER ;