DELIMITER $$
CREATE PROCEDURE `CREATE_EVENT`(IN `p_type` TINYINT(2), IN `p_name` VARCHAR(150), IN `p_slugurl` VARCHAR(150), IN `p_place` VARCHAR(150), IN `p_datetime` DATETIME, IN `p_image` VARCHAR(100), IN `p_file1` VARCHAR(100), IN `p_description` VARCHAR(255), IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))
BEGIN
	INSERT INTO crea.event
	(type,
	name,
	slugurl,
	place,
	datetime,
	image,
	file1,
	description,
	status,
	createdby,
	createdon)
	VALUES
	(p_type,
	p_name,
	p_slugurl,
	p_place,
	p_datetime,
	p_image,
	p_file1,
	p_description,
	p_status,
	p_createdby,
	NOW());
	SELECT LAST_INSERT_ID() INTO p_id;
END$$
DELIMITER ;