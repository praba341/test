DELIMITER $$
CREATE PROCEDURE `GET_NOTIFICATIONS_NEW`(IN `p_limit` INT(11))
BEGIN
SELECT
A.id,
A.type,
A.title,
A.url,
A.reference_id,
A.value_1,
A.value_2,
A.value_3,
(SELECT U.firstname FROM creaindia.users as U WHERE U.user_id=A.createdby) as firstname,
A.status,
A.approved_status,
A.createdon,
A.modifiedon
FROM creaindia.notification AS A
WHERE A.visited=0
ORDER BY A.createdon DESC LIMIT p_limit;
END$$
DELIMITER ;