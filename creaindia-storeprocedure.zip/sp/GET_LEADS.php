DELIMITER $$
CREATE PROCEDURE `GET_LEADS`(IN `p_status` TINYINT(2))
BEGIN

IF p_status IS NULL THEN
    SET @where = CONCAT("");
ELSE
	SET @where = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT
A.id,
A.name,
A.mobile,
A.email,
A.location,
A.comments,
(SELECT U.firstname FROM creaindia.users as U WHERE U.user_id=A.createdby) as firstname,
(SELECT U.name FROM creaindia.properties as U WHERE U.id=A.reference_id) as property_name,
A.status,
A.createdon,
A.modifiedon
FROM creaindia.lead AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$
DELIMITER ;