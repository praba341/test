DELIMITER $$
CREATE PROCEDURE `GET_EVENTS`(IN `p_type` TINYINT(2), IN `p_status` TINYINT(2))
BEGIN

IF p_status IS NULL THEN
    SET @where = CONCAT(" WHERE A.type='",p_type,"'");
ELSE
	SET @where = CONCAT(" WHERE A.type='",p_type,"' AND A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.id,
A.name,
A.slugurl,
A.image,
A.file1,
A.description,
A.active_home,
A.status
FROM crea.event AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$
DELIMITER ;