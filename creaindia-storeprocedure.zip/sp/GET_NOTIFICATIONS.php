DELIMITER $$
CREATE PROCEDURE `GET_NOTIFICATIONS`(IN `p_type` TINYINT(2), IN `p_status` TINYINT(2))
BEGIN

IF p_status IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.id IS NOT NULL");
ELSE
	SET @where1 = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

IF p_type IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
	SET @where2 = CONCAT(" AND A.type='",p_type,"'");
END IF;
SET @where = CONCAT(@where1, @where2);

SET @SQLQuery = "
SELECT
A.id,
A.type,
A.title,
A.url,
A.reference_id,
A.value_1,
A.value_2,
A.value_3,
(SELECT U.firstname FROM creaindia.users as U WHERE U.user_id=A.createdby) as firstname,
A.status,
A.approved_status,
A.createdon,
A.modifiedon
FROM creaindia.notification AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$
DELIMITER ;