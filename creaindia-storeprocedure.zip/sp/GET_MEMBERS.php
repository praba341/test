DELIMITER $$
CREATE PROCEDURE `GET_MEMBERS`(IN `p_status` TINYINT(2), IN `p_role` TINYINT(2))
BEGIN

IF p_status IS NULL THEN
    SET @where1 = CONCAT(" WHERE A.user_id IS NOT NULL");
ELSE
	SET @where1 = CONCAT(" WHERE A.status='",p_status,"'");
END IF;

IF p_role IS NULL THEN
    SET @where2 = CONCAT("");
ELSE
	SET @where2 = CONCAT(" AND A.role='",p_role,"'");
END IF;
SET @where = CONCAT(@where1,@where2);

SET @SQLQuery = "
SELECT
A.user_id,
A.role,
A.username,
A.password,
A.email,
A.mobile,
A.firstname,
A.lastname,
A.org,
A.rera_number,
A.register_type,
A.validity_start,
A.validity_end,
A.validity_period,
A.last_renewal,
A.message,
A.status,
A.profile_image,
A.lastaccess,
A.createdon
FROM creaindia.users AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@where);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$
DELIMITER ;