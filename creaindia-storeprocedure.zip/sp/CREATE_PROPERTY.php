DELIMITER $$
CREATE PROCEDURE `CREATE_PROPERTY`(IN `p_user_id` INT(11), IN `p_property_type` INT(11), IN `p_name` VARCHAR(255), IN `p_type` VARCHAR(255), IN `p_slugurl` VARCHAR(150), IN `p_rera_number` VARCHAR(255), IN `p_bhk` VARCHAR(100), IN `p_amenities` VARCHAR(150), IN `p_price` DOUBLE, IN `p_price_word` VARCHAR(255), IN `p_area` VARCHAR(50), IN `p_tolet` VARCHAR(10), IN `p_floor` DOUBLE, IN `p_parking` DOUBLE, IN `p_delivery_date` DATE, IN `p_comments` VARCHAR(255), IN `p_contact_number` VARCHAR(150), IN `p_location` VARCHAR(150), IN `p_zip` VARCHAR(15), IN `p_image` VARCHAR(150), IN `p_type_id` INT(11), IN `p_type_value_id` INT(11), IN `p_type_value_parent_id` INT(11), IN `p_file1` VARCHAR(150), IN `p_file2` VARCHAR(150), IN `p_start_date` DATE, IN `p_end_date` DATE, IN `p_status` TINYINT(2), IN `p_createdby` INT(11), OUT `p_id` INT(11))
BEGIN

DECLARE i_location_id INT(11);
SELECT location_id INTO i_location_id FROM creaindia.location AS R WHERE R.location_name=p_location LIMIT 1;
IF i_location_id IS NULL THEN
  INSERT INTO creaindia.location
  (location_name,
  status,
  createdby,
  createdon)
  VALUES
  (p_location,
  1,
  p_createdby,
  NOW());
  SELECT LAST_INSERT_ID() INTO i_location_id;
END IF;

  INSERT INTO creaindia.properties
  (user_id,
  property_type,
  name,
  type,
  slugurl,
  rera_number,
  bhk,
  amenities,
  price,
  price_word,
  area,
  tolet,
  floor,
  parking,
  delivery_date,
  comments,
  contact_number,
  location,
  zip,
  image,
  type_id,
  type_value_id,
  type_value_parent_id,
  file1,
  file2,
  start_date,
  end_date,
  status,
  createdby,
  modifiedby,
  createdon,
  modifiedon)
  VALUES
  (p_user_id,
  p_property_type,
  p_name,
  p_type,
  p_slugurl,
  p_rera_number,
  p_bhk,
  p_amenities,
  p_price,
  p_price_word,
  p_area,
  p_tolet,
  p_floor,
  p_parking,
  p_delivery_date,
  p_comments,
  p_contact_number,
  i_location_id,
  p_zip,
  p_image,
  p_type_id,
  p_type_value_id,
  p_type_value_parent_id,
  p_file1,
  p_file2,
  p_start_date,
  p_end_date,
  p_status,
  p_createdby,
  p_createdby,
  NOW(),
  NOW());
  SELECT LAST_INSERT_ID() INTO p_id;
END$$
DELIMITER ;