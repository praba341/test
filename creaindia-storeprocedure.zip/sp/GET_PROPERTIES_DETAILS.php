DELIMITER $$
CREATE PROCEDURE `GET_PROPERTIES_DETAILS`(IN `p_id` INT(11))
BEGIN

SELECT 
A.id,
A.name,
A.user_id,
A.type,
A.slugurl,
A.rera_number,
A.bhk,
A.price,
A.price_word,
A.comments,
A.image,
A.contact_number,
(SELECT U.type_name FROM crea.property_type as U WHERE U.type_id=A.type_id) as type_name,
(SELECT U.location_name FROM crea.location as U WHERE U.location_id=A.location) as location_name,
A.zip,
A.status,
A.createdby,
A.modifiedby,
A.createdon,
A.modifiedon
FROM crea.properties AS A
WHERE A.id=p_id;

END$$
DELIMITER ;