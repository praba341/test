DELIMITER $$
CREATE PROCEDURE `GET_EVENT_ITEMS`(IN `p_id` INT(11))
BEGIN

SELECT 
A.id,
A.title,
A.value
FROM crea.event_items AS A
WHERE A.reference_id=p_id;

END$$
DELIMITER ;