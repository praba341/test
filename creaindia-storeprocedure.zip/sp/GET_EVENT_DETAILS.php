DELIMITER $$
CREATE PROCEDURE `GET_EVENT_DETAILS`(IN `p_id` INT(11))
BEGIN

SELECT 
A.id,
A.name,
A.slugurl,
A.place,
A.datetime,
A.image,
A.file1,
A.description,
A.status
FROM crea.event AS A
WHERE A.id=p_id;

END$$
DELIMITER ;