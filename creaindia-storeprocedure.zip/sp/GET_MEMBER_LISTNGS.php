DELIMITER $$
CREATE PROCEDURE `GET_MEMBER_LISTNGS`(IN `p_type` TINYINT(2), IN `p_status` TINYINT(2))
BEGIN

IF p_status IS NULL THEN
    SET @whereQuery = CONCAT(" WHERE A.property_type='",p_type,"'");
ELSE
	SET @whereQuery = CONCAT(" WHERE A.property_type='",p_type,"' AND A.status='",p_status,"'");
END IF;

SET @SQLQuery = "
SELECT 
A.id,
A.name,
A.user_id,
A.type,
A.slugurl,
A.rera_number,
A.bhk,
A.price,
A.price_word,
A.comments,
A.image,
A.contact_number,
(SELECT U.location_name FROM crea.location as U WHERE U.location_id=A.location) as location_name,
A.zip,
A.status
FROM crea.properties AS A";

SET @SQLQuery = CONCAT(@SQLQuery,@whereQuery);
SET @FinalSQLQuery = CONCAT(@SQLQuery,' ORDER BY A.createdon DESC LIMIT 40');

PREPARE stmt FROM @FinalSQLQuery;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$
DELIMITER ;