DELIMITER $$
CREATE PROCEDURE `GET_USER`(IN `p_user_id` INT(11))
BEGIN
SELECT
A.user_id,
A.username,
A.password,
A.email,
A.mobile,
A.firstname,
A.lastname,
A.role,
A.profile_image,
A.org,
A.message,
A.rera_number,
A.validity_start,
A.validity_end,
A.validity_period,
A.last_renewal,
A.status,
A.lastaccess,
A.createdon
FROM creaindia.users AS A
WHERE A.user_id=p_user_id;
END$$
DELIMITER ;