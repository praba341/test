DELIMITER $$
CREATE PROCEDURE `UPDATE_PROPERTY_OFFER_ACTIVATE`(IN `p_user_id` INT(11), IN `p_offer` TINYINT(2), IN `p_offer_date` DATE, IN `p_modifiedby` INT(11), OUT `p_spstatus` INT(2))
BEGIN
DECLARE IsFound INT(1);
SELECT COUNT(user_id) INTO IsFound FROM creaindia.users WHERE offer=0 AND user_id=p_user_id;
IF IsFound>0 THEN
  UPDATE creaindia.users
  SET
  offer=p_offer,
  offer_date=p_offer_date,
  modifiedby=p_modifiedby,
  modifiedon=NOW()
  WHERE user_id=p_user_id;
  SET p_spstatus=1;
ELSE
	SET p_spstatus=0;
END IF;	
END$$
DELIMITER ;